﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Crypto.Signers;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x0200005F RID: 95
	public static class HytaleTokens
	{
		// Token: 0x0600020E RID: 526 RVA: 0x00009A20 File Offset: 0x00007C20
		static HytaleTokens()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			HytaleTokens.S9eJJ2kBht = new Dictionary<HytaleScope, string>
			{
				{
					HytaleScope.Client,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2132757131 ^ -287411610 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c)
				},
				{
					HytaleScope.Server,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(326126308 >> 6 ^ 665860088 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3)
				},
				{
					HytaleScope.Editor,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -1303084837 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7)
				}
			};
			HytaleTokens.F8eJbTS8fF = HytaleTokens.Tyhba387sl(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(796731446 >> 3 ^ 864008821 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0));
		}

		// Token: 0x0600020F RID: 527 RVA: 0x00009AE0 File Offset: 0x00007CE0
		private static string lUSbRl7Feo(HytaleScope \u0020)
		{
			string result;
			if (!HytaleTokens.S9eJJ2kBht.TryGetValue(\u0020, out result))
			{
				return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--238918963 ^ 259146343 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_63317b19592040989f1b836b90b41752);
			}
			return result;
		}

		// Token: 0x06000210 RID: 528 RVA: 0x00009B20 File Offset: 0x00007D20
		public static HytaleTokens.HytaleAuthData Create(string username, string uuid, HytaleScope scope = HytaleScope.Client)
		{
			string u = HytaleTokens.lUSbRl7Feo(scope);
			return new HytaleTokens.HytaleAuthData
			{
				SessionToken = HytaleTokens.J1IbzKfxUh(HytaleTokens.F8eJbTS8fF, uuid, u),
				IdentifyToken = HytaleTokens.eBFJ8Zxgxg(HytaleTokens.F8eJbTS8fF, username, uuid, u)
			};
		}

		// Token: 0x06000211 RID: 529 RVA: 0x00009B60 File Offset: 0x00007D60
		private static HytaleTokens.yJc6d75IkLmPv9hIsd2 Tyhba387sl(string \u0020)
		{
			JObject jobject = JObject.Parse(\u0020);
			byte[] array = HytaleTokens.PfeJw6iv5u(jobject[yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1643288979 - 908650859 ^ 1132924809 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8)].ToString());
			HytaleTokens.yJc6d75IkLmPv9hIsd2 yJc6d75IkLmPv9hIsd = new HytaleTokens.yJc6d75IkLmPv9hIsd2();
			yJc6d75IkLmPv9hIsd.Na15ajBpq2(new Ed25519PrivateKeyParameters(array, 0));
			yJc6d75IkLmPv9hIsd.LXsyh3q3ag(jobject[yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -297152889 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d)].ToString());
			return yJc6d75IkLmPv9hIsd;
		}

		// Token: 0x06000212 RID: 530 RVA: 0x00009BEC File Offset: 0x00007DEC
		private static string J1IbzKfxUh(HytaleTokens.yJc6d75IkLmPv9hIsd2 \u0020, string \u0020, string \u0020)
		{
			Dictionary<string, object> dictionary = new Dictionary<string, object>();
			dictionary.Add(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(533655012 ^ 1800347438 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1084619761 ^ -605776571 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1c66e07149574924b7cd3da5aa89d5a4));
			dictionary.Add(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-374163162 ^ -2053093133 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1222915046 >> 5 ^ -1784816385 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f));
			dictionary.Add(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-907199388 - -1774585445 ^ 1102469441 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0), \u0020.xory8ohnhy());
			Dictionary<string, object> u = new Dictionary<string, object>
			{
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(533655012 ^ 1643181798 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25),
					\u0020
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-169174967 ^ -694176382 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62),
					\u0020
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1193207239 - -1972173397 ^ 1436518048 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0),
					Guid.NewGuid().ToString()
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1643288979 - 908650859 ^ 1908769222 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8),
					DateTimeOffset.Now.ToUnixTimeSeconds()
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763020866 ^ -468376331 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0),
					DateTimeOffset.Now.AddYears(1000).ToUnixTimeSeconds()
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -506529672 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3),
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2094095138 ^ -2105497424 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b)
				}
			};
			return HytaleTokens.hkeJhNQjPk(dictionary, u, \u0020.SZV5RXWB0D());
		}

		// Token: 0x06000213 RID: 531 RVA: 0x00009DF4 File Offset: 0x00007FF4
		private static string eBFJ8Zxgxg(HytaleTokens.yJc6d75IkLmPv9hIsd2 \u0020, string \u0020, string \u0020, string \u0020)
		{
			Dictionary<string, object> u = new Dictionary<string, object>
			{
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -1501491340 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c),
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1984943586 ^ 819349257 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed)
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-752914475 ^ -206722949 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_52dac0565f7f422e80cc0f27df2b90e5),
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1479692193 ^ 1772539021 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20)
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -786589100 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a),
					\u0020.xory8ohnhy()
				}
			};
			Dictionary<string, object> value = new Dictionary<string, object>
			{
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -269193024 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22),
					\u0020
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-583370756 + -1440598365 ^ -55754945 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0),
					new string[]
					{
						yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(607992573 ^ 564661289 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a1f1dffb08f44e581e0c0e6fac695b4),
						yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~1397486621 ^ -603296315 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add),
						yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1899508754 ^ 1234747673 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7)
					}
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-654387379 >> 4 ^ -2089059628 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0),
					null
				}
			};
			Dictionary<string, object> u2 = new Dictionary<string, object>
			{
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2060960577 >> 4 ^ 1973969954 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0),
					DateTimeOffset.Now.AddYears(1000).ToUnixTimeSeconds()
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1006549809 >> 1 ^ -1963705862 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc),
					DateTimeOffset.Now.ToUnixTimeSeconds()
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1876786663 ^ -44309227 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b),
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-34176907 ^ -1879861129 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0)
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763766170 >> 6 ^ -1886764986 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a),
					Guid.NewGuid().ToString()
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1487851180 ^ -1960725530 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94),
					value
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -1233007335 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25),
					\u0020
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1538648569 ^ -553401836 ^ -1386888468 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18),
					\u0020
				}
			};
			return HytaleTokens.hkeJhNQjPk(u, u2, \u0020.SZV5RXWB0D());
		}

		// Token: 0x06000214 RID: 532 RVA: 0x0000A108 File Offset: 0x00008308
		private static string hkeJhNQjPk(Dictionary<string, object> \u0020, Dictionary<string, object> \u0020, Ed25519PrivateKeyParameters \u0020)
		{
			string s = JsonConvert.SerializeObject(\u0020, 0);
			string s2 = JsonConvert.SerializeObject(\u0020, 0);
			string str = HytaleTokens.JriJkQjxLa(Encoding.UTF8.GetBytes(s));
			string str2 = HytaleTokens.JriJkQjxLa(Encoding.UTF8.GetBytes(s2));
			string text = str + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1477603883 ^ -908896272 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c) + str2;
			byte[] bytes = Encoding.UTF8.GetBytes(text);
			Ed25519Signer ed25519Signer = new Ed25519Signer();
			ed25519Signer.Init(true, \u0020);
			ed25519Signer.BlockUpdate(bytes, 0, bytes.Length);
			byte[] u = ed25519Signer.GenerateSignature();
			return text + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-654387379 >> 4 ^ -1886718582 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0) + HytaleTokens.JriJkQjxLa(u);
		}

		// Token: 0x06000215 RID: 533 RVA: 0x0000A1C4 File Offset: 0x000083C4
		private static string JriJkQjxLa(byte[] \u0020)
		{
			return Convert.ToBase64String(\u0020).TrimEnd(new char[]
			{
				'='
			}).Replace('+', '-').Replace('/', '_');
		}

		// Token: 0x06000216 RID: 534 RVA: 0x0000A1F0 File Offset: 0x000083F0
		private static byte[] PfeJw6iv5u(string \u0020)
		{
			string text = \u0020.Replace('-', '+').Replace('_', '/');
			int num = text.Length % 4;
			if (num != 2)
			{
				if (num == 3)
				{
					text += yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-146310919 ^ -559642652 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18);
				}
			}
			else
			{
				text += yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1876786663 ^ -190891894 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d);
			}
			return Convert.FromBase64String(text);
		}

		// Token: 0x04000183 RID: 387
		private static readonly HytaleTokens.yJc6d75IkLmPv9hIsd2 F8eJbTS8fF;

		// Token: 0x04000184 RID: 388
		private static readonly Dictionary<HytaleScope, string> S9eJJ2kBht;

		// Token: 0x02000060 RID: 96
		public class HytaleAuthData
		{
			// Token: 0x1700006B RID: 107
			// (get) Token: 0x06000217 RID: 535 RVA: 0x00020EF0 File Offset: 0x0001F0F0
			// (set) Token: 0x06000218 RID: 536 RVA: 0x00020EF8 File Offset: 0x0001F0F8
			public string SessionToken { get; set; }

			// Token: 0x1700006C RID: 108
			// (get) Token: 0x06000219 RID: 537 RVA: 0x00020F04 File Offset: 0x0001F104
			// (set) Token: 0x0600021A RID: 538 RVA: 0x00020F0C File Offset: 0x0001F10C
			public string IdentifyToken { get; set; }

			// Token: 0x0600021B RID: 539 RVA: 0x00020F18 File Offset: 0x0001F118
			public HytaleAuthData()
			{
				yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
				base..ctor();
			}

			// Token: 0x04000185 RID: 389
			[CompilerGenerated]
			private string KBC53EEqQY;

			// Token: 0x04000186 RID: 390
			[CompilerGenerated]
			private string a3Y5LsFDsq;
		}

		// Token: 0x02000061 RID: 97
		private class yJc6d75IkLmPv9hIsd2
		{
			// Token: 0x0600021C RID: 540 RVA: 0x00020F2C File Offset: 0x0001F12C
			[CompilerGenerated]
			public Ed25519PrivateKeyParameters SZV5RXWB0D()
			{
				return this.NPmywEc8GD;
			}

			// Token: 0x0600021D RID: 541 RVA: 0x00020F34 File Offset: 0x0001F134
			[CompilerGenerated]
			public void Na15ajBpq2(Ed25519PrivateKeyParameters \u0020)
			{
				this.NPmywEc8GD = \u0020;
			}

			// Token: 0x0600021E RID: 542 RVA: 0x00020F40 File Offset: 0x0001F140
			[CompilerGenerated]
			public string xory8ohnhy()
			{
				return this.toOybKJqaP;
			}

			// Token: 0x0600021F RID: 543 RVA: 0x00020F48 File Offset: 0x0001F148
			[CompilerGenerated]
			public void LXsyh3q3ag(string \u0020)
			{
				this.toOybKJqaP = \u0020;
			}

			// Token: 0x06000220 RID: 544 RVA: 0x00020F54 File Offset: 0x0001F154
			public yJc6d75IkLmPv9hIsd2()
			{
				yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
				base..ctor();
			}

			// Token: 0x04000187 RID: 391
			[CompilerGenerated]
			private Ed25519PrivateKeyParameters NPmywEc8GD;

			// Token: 0x04000188 RID: 392
			[CompilerGenerated]
			private string toOybKJqaP;
		}
	}
}
