﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AGSw7LJMkp5usDW1gK1;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000B5 RID: 181
	public static class ServerManager
	{
		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000383 RID: 899 RVA: 0x00016444 File Offset: 0x00014644
		// (remove) Token: 0x06000384 RID: 900 RVA: 0x0001647C File Offset: 0x0001467C
		public static event Action<string> OnLogReceived
		{
			[CompilerGenerated]
			add
			{
				Action<string> action = ServerManager.lVl0hbOBme;
				Action<string> action2;
				do
				{
					action2 = action;
					Action<string> value2 = (Action<string>)Delegate.Combine(action2, value);
					action = Interlocked.CompareExchange<Action<string>>(ref ServerManager.lVl0hbOBme, value2, action2);
				}
				while (action != action2);
			}
			[CompilerGenerated]
			remove
			{
				Action<string> action = ServerManager.lVl0hbOBme;
				Action<string> action2;
				do
				{
					action2 = action;
					Action<string> value2 = (Action<string>)Delegate.Remove(action2, value);
					action = Interlocked.CompareExchange<Action<string>>(ref ServerManager.lVl0hbOBme, value2, action2);
				}
				while (action != action2);
			}
		}

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000385 RID: 901 RVA: 0x000164B4 File Offset: 0x000146B4
		// (remove) Token: 0x06000386 RID: 902 RVA: 0x000164EC File Offset: 0x000146EC
		public static event Action<string> OnStatusChanged
		{
			[CompilerGenerated]
			add
			{
				Action<string> action = ServerManager.M7R0kdPi5a;
				Action<string> action2;
				do
				{
					action2 = action;
					Action<string> value2 = (Action<string>)Delegate.Combine(action2, value);
					action = Interlocked.CompareExchange<Action<string>>(ref ServerManager.M7R0kdPi5a, value2, action2);
				}
				while (action != action2);
			}
			[CompilerGenerated]
			remove
			{
				Action<string> action = ServerManager.M7R0kdPi5a;
				Action<string> action2;
				do
				{
					action2 = action;
					Action<string> value2 = (Action<string>)Delegate.Remove(action2, value);
					action = Interlocked.CompareExchange<Action<string>>(ref ServerManager.M7R0kdPi5a, value2, action2);
				}
				while (action != action2);
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000387 RID: 903 RVA: 0x00016524 File Offset: 0x00014724
		public static bool IsRunning
		{
			get
			{
				return ServerManager.pQX1noAqNy != null && !ServerManager.pQX1noAqNy.HasExited;
			}
		}

		// Token: 0x06000388 RID: 904 RVA: 0x00016540 File Offset: 0x00014740
		static ServerManager()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			ServerManager.CL61eFLcTr = RJG3u8JZLa1autEARgF.METJ4myejd;
			ServerManager.LogHistory = new List<string>();
			AppDomain.CurrentDomain.ProcessExit += ServerManager.<>c.VyTC3Hi4HU.jKmCpyjbPh;
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0001657C File Offset: 0x0001477C
		public static void Initialize()
		{
			DriveHelper.CleanupOrphanedDrives(ServerManager.CL61eFLcTr);
			ServerManager.cxu1d7iw7A();
		}

		// Token: 0x0600038A RID: 906 RVA: 0x00016590 File Offset: 0x00014790
		private static void xyg1E8tmlY(string \u0020)
		{
			string path = PathHelper.Combine(new string[]
			{
				\u0020,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1877665038 - 1504633712 ^ 2016458876 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156)
			});
			if (File.Exists(path))
			{
				return;
			}
			string contents = JsonConvert.SerializeObject(new
			{
				Version = 3,
				ServerName = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1437861049 - 796136520 ^ 29511734 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3),
				MOTD = "",
				Password = "",
				MaxPlayers = 10,
				MaxViewRadius = 12,
				Defaults = new
				{
					World = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1479692193 ^ 874575411 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264),
					GameMode = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(796731446 >> 3 ^ 1573805357 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a)
				},
				ConnectionTimeouts = new
				{

				},
				RateLimit = new
				{

				},
				Modules = new
				{

				},
				LogLevels = new
				{

				},
				Mods = new
				{

				},
				DisplayTmpTagsInStrings = false,
				PlayerStorage = new
				{
					Type = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1256492628 << 2 ^ -1895698790 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967)
				},
				Update = new
				{

				}
			}, 1);
			File.WriteAllText(path, contents, new UTF8Encoding(false));
		}

		// Token: 0x0600038B RID: 907 RVA: 0x000166B0 File Offset: 0x000148B0
		public static void LaunchServer(bool virtualization, bool onlineFix)
		{
			ServerManager.<LaunchServer>d__21 <LaunchServer>d__;
			<LaunchServer>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<LaunchServer>d__.virtualization = virtualization;
			<LaunchServer>d__.onlineFix = onlineFix;
			<LaunchServer>d__.<>1__state = -1;
			<LaunchServer>d__.<>t__builder.Start<ServerManager.<LaunchServer>d__21>(ref <LaunchServer>d__);
		}

		// Token: 0x0600038C RID: 908 RVA: 0x000166F0 File Offset: 0x000148F0
		public static Task StopServer()
		{
			ServerManager.<StopServer>d__22 <StopServer>d__;
			<StopServer>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<StopServer>d__.<>1__state = -1;
			<StopServer>d__.<>t__builder.Start<ServerManager.<StopServer>d__22>(ref <StopServer>d__);
			return <StopServer>d__.<>t__builder.Task;
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0001672C File Offset: 0x0001492C
		private static void gQ91prmaMV()
		{
			if (ServerManager.pQX1noAqNy == null)
			{
				return;
			}
			int num = -1;
			try
			{
				num = ServerManager.pQX1noAqNy.ExitCode;
			}
			catch
			{
			}
			if (ServerManager.Wbv08idDjI)
			{
				Action<string> m7R0kdPi5a = ServerManager.M7R0kdPi5a;
				if (m7R0kdPi5a == null)
				{
					return;
				}
				m7R0kdPi5a(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -331586011 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22));
				return;
			}
			else if (num != 0 && num != 130)
			{
				Action<string> m7R0kdPi5a2 = ServerManager.M7R0kdPi5a;
				if (m7R0kdPi5a2 == null)
				{
					return;
				}
				m7R0kdPi5a2(string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1968780863 ^ -478177009 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_bcad499d901540f895e61fc7be5dbf2b), num));
				return;
			}
			else
			{
				Action<string> m7R0kdPi5a3 = ServerManager.M7R0kdPi5a;
				if (m7R0kdPi5a3 == null)
				{
					return;
				}
				m7R0kdPi5a3(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(796731446 >> 3 ^ 1048359969 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790));
				return;
			}
		}

		// Token: 0x0600038E RID: 910 RVA: 0x00016828 File Offset: 0x00014A28
		private static Task Mq81FuATFC()
		{
			ServerManager.<Cleanup>d__24 <Cleanup>d__;
			<Cleanup>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Cleanup>d__.<>1__state = -1;
			<Cleanup>d__.<>t__builder.Start<ServerManager.<Cleanup>d__24>(ref <Cleanup>d__);
			return <Cleanup>d__.<>t__builder.Task;
		}

		// Token: 0x0600038F RID: 911 RVA: 0x00016864 File Offset: 0x00014A64
		public static void ForceCleanupSync()
		{
			try
			{
				if (ServerManager.pQX1noAqNy != null && !ServerManager.pQX1noAqNy.HasExited)
				{
					ServerManager.pQX1noAqNy.Kill();
					ServerManager.pQX1noAqNy.WaitForExit(1000);
				}
			}
			catch
			{
			}
			if (ServerManager.h0B1Rylh1K != null)
			{
				DriveHelper.RunSubst(ServerManager.h0B1Rylh1K.Value, null, false);
			}
		}

		// Token: 0x06000390 RID: 912 RVA: 0x000168E0 File Offset: 0x00014AE0
		private static Task cxu1d7iw7A()
		{
			ServerManager.<CleanupStaticLegacy>d__26 <CleanupStaticLegacy>d__;
			<CleanupStaticLegacy>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CleanupStaticLegacy>d__.<>1__state = -1;
			<CleanupStaticLegacy>d__.<>t__builder.Start<ServerManager.<CleanupStaticLegacy>d__26>(ref <CleanupStaticLegacy>d__);
			return <CleanupStaticLegacy>d__.<>t__builder.Task;
		}

		// Token: 0x06000391 RID: 913 RVA: 0x0001691C File Offset: 0x00014B1C
		private static void nAG1WTcZrx(string \u0020)
		{
			if (string.IsNullOrWhiteSpace(\u0020))
			{
				return;
			}
			ServerManager.LogHistory.Add(\u0020);
			if (ServerManager.LogHistory.Count > 5000)
			{
				ServerManager.LogHistory.RemoveAt(0);
			}
			Action<string> action = ServerManager.lVl0hbOBme;
			if (action == null)
			{
				return;
			}
			action(\u0020);
		}

		// Token: 0x06000392 RID: 914 RVA: 0x00016974 File Offset: 0x00014B74
		public static void SendCommand(string command)
		{
			if (ServerManager.IsRunning)
			{
				ServerManager.pQX1noAqNy.StandardInput.WriteLine(command);
				ServerManager.nAG1WTcZrx(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(819711667 ^ 653949393 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8) + command);
			}
		}

		// Token: 0x04000304 RID: 772
		private static readonly string CL61eFLcTr;

		// Token: 0x04000305 RID: 773
		private static Process pQX1noAqNy;

		// Token: 0x04000306 RID: 774
		private static DataReceivedEventHandler WEk13PLUCw;

		// Token: 0x04000307 RID: 775
		private static DataReceivedEventHandler BY01LMAx1M;

		// Token: 0x04000308 RID: 776
		private static EventHandler oDQ1IGhltk;

		// Token: 0x04000309 RID: 777
		private static char? h0B1Rylh1K;

		// Token: 0x0400030A RID: 778
		private static string kMk1aUY5xw;

		// Token: 0x0400030B RID: 779
		private static string PqR1z19fyP;

		// Token: 0x0400030C RID: 780
		private static bool Wbv08idDjI;

		// Token: 0x0400030D RID: 781
		public static List<string> LogHistory;

		// Token: 0x0400030E RID: 782
		[CompilerGenerated]
		private static Action<string> lVl0hbOBme;

		// Token: 0x0400030F RID: 783
		[CompilerGenerated]
		private static Action<string> M7R0kdPi5a;
	}
}
