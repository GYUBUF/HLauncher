﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using HLauncher.Properties;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000C6 RID: 198
	public partial class SplashForm : Form
	{
		// Token: 0x06000404 RID: 1028 RVA: 0x00019588 File Offset: 0x00017788
		public SplashForm()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.U0IX74yDHB = -150f;
			this.jx9XgXxmO7 = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1279801375 ^ -1614334537 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94), 18f, FontStyle.Bold);
			this.kKJXYLypBU = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~234019875 ^ -266375279 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb), 12f, FontStyle.Bold);
			this.GPpXlL93XA = new SolidBrush(Color.FromArgb(255, 68, 138, 255));
			this.vBjXVInxLR = new SolidBrush(Color.FromArgb(60, 0, 0, 0));
			base..ctor();
			base.FormBorderStyle = FormBorderStyle.None;
			base.StartPosition = FormStartPosition.CenterScreen;
			base.ShowInTaskbar = false;
			base.TopMost = true;
			base.Size = new Size(700, 350);
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
			base.Opacity = 0.0;
			this.QiwXNlfiD9();
			this.oMYXAJgB9s = new System.Windows.Forms.Timer
			{
				Interval = 15
			};
			this.oMYXAJgB9s.Tick += this.S0uXH4kTSL;
			base.Load += this.T2yX4wTEs8;
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x000196DC File Offset: 0x000178DC
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if (m.Msg == 132)
			{
				m.Result = (IntPtr)2;
			}
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00019704 File Offset: 0x00017904
		private void QiwXNlfiD9()
		{
			this.RfuXBxnXs1 = new Bitmap(base.Width, base.Height);
			using (Graphics graphics = Graphics.FromImage(this.RfuXBxnXs1))
			{
				graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
				graphics.DrawImage(SplashForm.s8WXGS2UfU, 0, 0, base.Width, base.Height);
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(180, 12, 12, 12)))
				{
					graphics.FillRectangle(solidBrush, 0, 0, base.Width, base.Height);
				}
			}
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x000197BC File Offset: 0x000179BC
		private void IIrXsdWy6d()
		{
			if (this.b07XqfQFUs < 1f)
			{
				this.b07XqfQFUs += 0.06f;
				base.Opacity = (double)Math.Min(1f, this.b07XqfQFUs * 1.2f);
			}
			this.U0IX74yDHB += 12f;
			if (this.U0IX74yDHB > (float)base.Width)
			{
				this.U0IX74yDHB = -150f;
			}
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x00019838 File Offset: 0x00017A38
		protected override void OnPaint(PaintEventArgs e)
		{
			if (this.RfuXBxnXs1 == null)
			{
				return;
			}
			Graphics graphics = e.Graphics;
			graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.DrawImage(this.RfuXBxnXs1, 0, 0);
			float num = (float)Math.Pow((double)(1f - Math.Min(1f, this.b07XqfQFUs)), 2.0);
			int num2 = base.Height / 2 - 40 + (int)(40f * num);
			int num3 = 80;
			graphics.DrawImage(SplashForm.Ia0XTKtQT5, num3, num2, 64, 64);
			graphics.DrawString(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1424072547 ^ 966297655 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b), this.jx9XgXxmO7, Brushes.White, (float)(num3 + 80), (float)(num2 + 5));
			graphics.DrawString(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(582215781 ^ 247667323 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94), this.kKJXYLypBU, Brushes.LightGray, (float)(num3 + 82), (float)(num2 + 42));
			graphics.FillRectangle(this.vBjXVInxLR, 0, base.Height - 5, base.Width, 5);
			graphics.FillRectangle(this.GPpXlL93XA, this.U0IX74yDHB, (float)(base.Height - 5), 150f, 5f);
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x00019970 File Offset: 0x00017B70
		public static void ShowSplash()
		{
			object ruqx9APsMU = SplashForm.RUQX9APsMU;
			lock (ruqx9APsMU)
			{
				if (SplashForm.lKfXoXkVow == null || SplashForm.lKfXoXkVow.IsDisposed)
				{
					SplashForm.wmFXQxQiPw = false;
					Thread thread = new Thread(new ThreadStart(SplashForm.<>c.S5LS7UQys2.mQBSBvW5QQ));
					thread.SetApartmentState(ApartmentState.STA);
					thread.IsBackground = true;
					thread.Start();
				}
			}
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x00019A10 File Offset: 0x00017C10
		public static void HideSplash()
		{
			SplashForm.<HideSplash>d__23 <HideSplash>d__;
			<HideSplash>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<HideSplash>d__.<>1__state = -1;
			<HideSplash>d__.<>t__builder.Start<SplashForm.<HideSplash>d__23>(ref <HideSplash>d__);
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x0600040C RID: 1036 RVA: 0x00019AE4 File Offset: 0x00017CE4
		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams createParams = base.CreateParams;
				createParams.ExStyle |= 8;
				createParams.ExStyle |= 128;
				return createParams;
			}
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00019B0C File Offset: 0x00017D0C
		// Note: this type is marked as 'beforefieldinit'.
		static SplashForm()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			SplashForm.s8WXGS2UfU = Resources.clear_background;
			SplashForm.Ia0XTKtQT5 = Resources.logo.ToBitmap();
			SplashForm.RUQX9APsMU = new object();
			SplashForm.wmFXQxQiPw = false;
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x00019B44 File Offset: 0x00017D44
		[CompilerGenerated]
		private void S0uXH4kTSL(object \u0020, EventArgs \u0020)
		{
			this.IIrXsdWy6d();
			base.Invalidate();
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00019B54 File Offset: 0x00017D54
		[CompilerGenerated]
		private void T2yX4wTEs8(object \u0020, EventArgs \u0020)
		{
			SplashForm.<<-ctor>b__17_1>d <<-ctor>b__17_1>d;
			<<-ctor>b__17_1>d.<>t__builder = AsyncVoidMethodBuilder.Create();
			<<-ctor>b__17_1>d.<>4__this = this;
			<<-ctor>b__17_1>d.<>1__state = -1;
			<<-ctor>b__17_1>d.<>t__builder.Start<SplashForm.<<-ctor>b__17_1>d>(ref <<-ctor>b__17_1>d);
		}

		// Token: 0x0400037F RID: 895
		private static readonly Image s8WXGS2UfU;

		// Token: 0x04000380 RID: 896
		private static readonly Image Ia0XTKtQT5;

		// Token: 0x04000382 RID: 898
		private float b07XqfQFUs;

		// Token: 0x04000383 RID: 899
		private float U0IX74yDHB;

		// Token: 0x04000385 RID: 901
		private Stopwatch s4HXPs8XSt;

		// Token: 0x04000386 RID: 902
		private static SplashForm lKfXoXkVow;

		// Token: 0x04000387 RID: 903
		private static readonly object RUQX9APsMU;

		// Token: 0x04000388 RID: 904
		private static bool wmFXQxQiPw;
	}
}
