﻿using System;
using System.Windows.Forms;
using y0ve6F17gu3T12r7mYI;

namespace HLauncher
{
	// Token: 0x0200007C RID: 124
	public static class Tray
	{
		// Token: 0x06000271 RID: 625 RVA: 0x0000AB20 File Offset: 0x00008D20
		public static void Show(Form form, NotifyIcon notifyIcon)
		{
			if (!form.Visible)
			{
				form.Show();
				form.Activate();
				bpJXyX1qocPR5dVW9GD.N9k1olbldd(form.Handle);
				if (notifyIcon != null)
				{
					notifyIcon.Visible = false;
				}
				SettingsManager.Settings.InTrayHidden = false;
			}
		}

		// Token: 0x06000272 RID: 626 RVA: 0x0000AB60 File Offset: 0x00008D60
		public static void Hide(Form form, NotifyIcon notifyIcon)
		{
			if (form.Visible)
			{
				form.Hide();
				if (notifyIcon != null)
				{
					notifyIcon.Visible = true;
				}
				SettingsManager.Settings.InTrayHidden = true;
			}
		}
	}
}
