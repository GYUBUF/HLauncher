﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using AGSw7LJMkp5usDW1gK1;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x02000046 RID: 70
	public static class CleanMemory
	{
		// Token: 0x06000187 RID: 391 RVA: 0x00007B98 File Offset: 0x00005D98
		public static Task Execute(Label statusLabel = null, IProgress<int> progress = null, bool intensive = false)
		{
			CleanMemory.<Execute>d__4 <Execute>d__;
			<Execute>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Execute>d__.statusLabel = statusLabel;
			<Execute>d__.progress = progress;
			<Execute>d__.intensive = intensive;
			<Execute>d__.<>1__state = -1;
			<Execute>d__.<>t__builder.Start<CleanMemory.<Execute>d__4>(ref <Execute>d__);
			return <Execute>d__.<>t__builder.Task;
		}

		// Token: 0x06000188 RID: 392 RVA: 0x00007BEC File Offset: 0x00005DEC
		private static float KvDwFYWMbB()
		{
			float result;
			try
			{
				using (PerformanceCounter performanceCounter = new PerformanceCounter(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-551092600 ^ 1412615215 ^ -2024987374 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1822672301 ^ -391268553 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0)))
				{
					result = performanceCounter.NextValue();
				}
			}
			catch
			{
				result = 0f;
			}
			return result;
		}

		// Token: 0x06000189 RID: 393 RVA: 0x00007C80 File Offset: 0x00005E80
		private static Task g93wdj0yuY(Label \u0020, IProgress<int> \u0020)
		{
			CleanMemory.<CheckAndDownloadStandByList>d__6 <CheckAndDownloadStandByList>d__;
			<CheckAndDownloadStandByList>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CheckAndDownloadStandByList>d__.statusLabel = \u0020;
			<CheckAndDownloadStandByList>d__.progress = \u0020;
			<CheckAndDownloadStandByList>d__.<>1__state = -1;
			<CheckAndDownloadStandByList>d__.<>t__builder.Start<CleanMemory.<CheckAndDownloadStandByList>d__6>(ref <CheckAndDownloadStandByList>d__);
			return <CheckAndDownloadStandByList>d__.<>t__builder.Task;
		}

		// Token: 0x0600018A RID: 394 RVA: 0x00007CCC File Offset: 0x00005ECC
		private static void Sl7wWhoUnN(Label \u0020, IProgress<int> \u0020, int \u0020, string \u0020)
		{
			CleanMemory.<>c__DisplayClass7_0 CS$<>8__locals1 = new CleanMemory.<>c__DisplayClass7_0();
			CS$<>8__locals1.aOJ5BraAoP = \u0020;
			CS$<>8__locals1.htA5qi85q7 = \u0020;
			if (\u0020 >= 0 && \u0020 != null)
			{
				\u0020.Report(\u0020);
			}
			if (CS$<>8__locals1.aOJ5BraAoP == null || CS$<>8__locals1.aOJ5BraAoP.IsDisposed || !CS$<>8__locals1.aOJ5BraAoP.IsHandleCreated)
			{
				return;
			}
			try
			{
				CS$<>8__locals1.aOJ5BraAoP.BeginInvoke(new Action(CS$<>8__locals1.PN55Th1QW5));
			}
			catch
			{
			}
		}

		// Token: 0x0600018B RID: 395 RVA: 0x00007D64 File Offset: 0x00005F64
		// Note: this type is marked as 'beforefieldinit'.
		static CleanMemory()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			CleanMemory.DHpweu9K5f = RJG3u8JZLa1autEARgF.METJ4myejd;
			CleanMemory.xuhwnmy25i = PathHelper.Combine(new string[]
			{
				CleanMemory.DHpweu9K5f,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-269698511 ^ -1445500251 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e)
			});
			CleanMemory.sgGw3E9f5K = PathHelper.Combine(new string[]
			{
				CleanMemory.xuhwnmy25i,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-382924511 ^ -1347124064 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed)
			});
			CleanMemory.InEwLfi2GR = PathHelper.Combine(new string[]
			{
				CleanMemory.sgGw3E9f5K,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1877665038 - 1504633712 ^ 1860462021 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770)
			});
		}

		// Token: 0x040000FF RID: 255
		private static readonly string DHpweu9K5f;

		// Token: 0x04000100 RID: 256
		private static readonly string xuhwnmy25i;

		// Token: 0x04000101 RID: 257
		private static readonly string sgGw3E9f5K;

		// Token: 0x04000102 RID: 258
		private static readonly string InEwLfi2GR;
	}
}
