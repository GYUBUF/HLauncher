﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x0200004F RID: 79
	public class CustomTextBox : Control
	{
		// Token: 0x14000002 RID: 2
		// (add) Token: 0x060001B4 RID: 436 RVA: 0x000082E8 File Offset: 0x000064E8
		// (remove) Token: 0x060001B5 RID: 437 RVA: 0x00008320 File Offset: 0x00006520
		public event EventHandler TextChangedCustom
		{
			[CompilerGenerated]
			add
			{
				EventHandler eventHandler = this.xwmbqwi7hH;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.xwmbqwi7hH, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				EventHandler eventHandler = this.xwmbqwi7hH;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.xwmbqwi7hH, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x00008358 File Offset: 0x00006558
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x00008360 File Offset: 0x00006560
		public CustomTextBoxColorScheme ColorScheme
		{
			get
			{
				return this.pshbBaYOAS;
			}
			set
			{
				this.pshbBaYOAS = (value ?? CustomTextBoxColorScheme.Default);
				base.Invalidate();
			}
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x0000837C File Offset: 0x0000657C
		public CustomTextBox()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.Xgabm01nvQ = string.Empty;
			this.PUCbNOTxig = string.Empty;
			this.pshbBaYOAS = CustomTextBoxColorScheme.Default;
			base..ctor();
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.Size = new Size(200, 30);
			this.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2091326168 ^ -1141372939 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7), 10f);
			this.Cursor = Cursors.IBeam;
			this.diJbT1XB6M = new System.Windows.Forms.Timer
			{
				Interval = 500
			};
			this.diJbT1XB6M.Tick += this.OFNbcdv5Xq;
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x0000843C File Offset: 0x0000663C
		// (set) Token: 0x060001BA RID: 442 RVA: 0x00008444 File Offset: 0x00006644
		public char PasswordChar
		{
			get
			{
				return this.SVgbrIjQXF;
			}
			set
			{
				this.SVgbrIjQXF = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060001BB RID: 443 RVA: 0x00008454 File Offset: 0x00006654
		// (set) Token: 0x060001BC RID: 444 RVA: 0x0000845C File Offset: 0x0000665C
		public string Placeholder
		{
			get
			{
				return this.PUCbNOTxig;
			}
			set
			{
				this.PUCbNOTxig = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060001BD RID: 445 RVA: 0x0000846C File Offset: 0x0000666C
		// (set) Token: 0x060001BE RID: 446 RVA: 0x00008474 File Offset: 0x00006674
		public override string Text
		{
			get
			{
				return this.Xgabm01nvQ;
			}
			set
			{
				if (this.Xgabm01nvQ != value)
				{
					this.Xgabm01nvQ = (value ?? string.Empty);
					this.YD6bKafddG = Math.Min(this.YD6bKafddG, this.Xgabm01nvQ.Length);
					this.S8gb2mJHII = 0;
					this.rNFbCGycRw();
					base.Invalidate();
					EventHandler eventHandler = this.xwmbqwi7hH;
					if (eventHandler == null)
					{
						return;
					}
					eventHandler(this, EventArgs.Empty);
				}
			}
		}

		// Token: 0x060001BF RID: 447 RVA: 0x000084F0 File Offset: 0x000066F0
		private string Ka8bysyCJr()
		{
			if (this.SVgbrIjQXF == '\0')
			{
				return this.Xgabm01nvQ;
			}
			return new string(this.SVgbrIjQXF, this.Xgabm01nvQ.Length);
		}

		// Token: 0x060001C0 RID: 448 RVA: 0x0000851C File Offset: 0x0000671C
		private int Bn4bZPnL5J(Graphics \u0020, int \u0020)
		{
			string text = this.Ka8bysyCJr();
			if (\u0020 <= 0)
			{
				return 0;
			}
			if (\u0020 > text.Length)
			{
				\u0020 = text.Length;
			}
			return TextRenderer.MeasureText(\u0020, text.Substring(0, \u0020), this.Font, Size.Empty, TextFormatFlags.NoPadding).Width;
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x00008574 File Offset: 0x00006774
		private int AmobMaiPa0(Graphics \u0020, int \u0020)
		{
			string text = this.Ka8bysyCJr();
			int num = \u0020 - 5 + this.FR0bHCqooF;
			if (num <= 0)
			{
				return 0;
			}
			for (int i = 0; i <= text.Length; i++)
			{
				Size size = TextRenderer.MeasureText(\u0020, text.Substring(0, i), this.Font, Size.Empty, TextFormatFlags.NoPadding);
				if (size.Width >= num)
				{
					if (i > 0)
					{
						Size size2 = TextRenderer.MeasureText(\u0020, text.Substring(0, i - 1), this.Font, Size.Empty, TextFormatFlags.NoPadding);
						int num2 = size.Width - size2.Width;
						if (num < size2.Width + num2 / 2)
						{
							return i - 1;
						}
					}
					return i;
				}
			}
			return text.Length;
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x00008638 File Offset: 0x00006838
		private void rNFbCGycRw()
		{
			using (Graphics graphics = base.CreateGraphics())
			{
				int num = this.Bn4bZPnL5J(graphics, this.YD6bKafddG);
				int num2 = base.ClientRectangle.Width - 7;
				if (num < this.FR0bHCqooF)
				{
					this.FR0bHCqooF = num;
				}
				else if (num > this.FR0bHCqooF + num2)
				{
					this.FR0bHCqooF = num - num2;
				}
				if (this.Bn4bZPnL5J(graphics, this.Xgabm01nvQ.Length) < num2)
				{
					this.FR0bHCqooF = -3;
				}
			}
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x000086DC File Offset: 0x000068DC
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			CustomTextBoxColorScheme customTextBoxColorScheme = this.pshbBaYOAS ?? CustomTextBoxColorScheme.Default;
			using (SolidBrush solidBrush = new SolidBrush(customTextBoxColorScheme.BackColor))
			{
				graphics.FillRectangle(solidBrush, base.ClientRectangle);
			}
			using (Pen pen = new Pen(customTextBoxColorScheme.BorderColor, 2f))
			{
				pen.Alignment = PenAlignment.Inset;
				graphics.DrawRectangle(pen, 0, 0, base.Width, base.Height);
			}
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			Rectangle clip = new Rectangle(5, 0, base.Width - 10, base.Height);
			graphics.SetClip(clip);
			string text = this.Ka8bysyCJr();
			int num = (base.Height - this.Font.Height) / 2;
			if (string.IsNullOrEmpty(this.Xgabm01nvQ) && !string.IsNullOrEmpty(this.PUCbNOTxig))
			{
				Color foreColor = Color.FromArgb(120, customTextBoxColorScheme.PlaceholderColor);
				TextFormatFlags flags = TextFormatFlags.NoPadding;
				TextRenderer.DrawText(graphics, this.PUCbNOTxig, this.Font, new Point(7, num), foreColor, flags);
			}
			if (this.S8gb2mJHII > 0)
			{
				int num2 = this.Bn4bZPnL5J(graphics, this.YD6bKafddG);
				int num3 = this.Bn4bZPnL5J(graphics, this.YD6bKafddG + this.S8gb2mJHII);
				int x = Math.Min(num2, num3) - this.FR0bHCqooF + 5;
				int width = Math.Abs(num3 - num2);
				using (SolidBrush solidBrush2 = new SolidBrush(customTextBoxColorScheme.SelectionColor))
				{
					graphics.FillRectangle(solidBrush2, new Rectangle(x, 1, width, base.Height - 2));
				}
			}
			TextFormatFlags flags2 = TextFormatFlags.NoPrefix | TextFormatFlags.NoPadding;
			Point pt = new Point(5 - this.FR0bHCqooF, num);
			TextRenderer.DrawText(graphics, text, this.Font, pt, customTextBoxColorScheme.ForeColor, flags2);
			if (this.Focused && this.qXbbsm5ULh && this.S8gb2mJHII == 0)
			{
				int num4 = this.Bn4bZPnL5J(graphics, this.YD6bKafddG) - this.FR0bHCqooF + 5;
				using (Pen pen2 = new Pen(customTextBoxColorScheme.CursorColor, 1f))
				{
					graphics.DrawLine(pen2, num4, num, num4, num + this.Font.Height);
				}
			}
			graphics.ResetClip();
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x00008980 File Offset: 0x00006B80
		protected override void OnGotFocus(EventArgs e)
		{
			base.OnGotFocus(e);
			this.qXbbsm5ULh = true;
			this.diJbT1XB6M.Start();
			base.Invalidate();
		}

		// Token: 0x060001C5 RID: 453 RVA: 0x000089A4 File Offset: 0x00006BA4
		protected override void OnLostFocus(EventArgs e)
		{
			base.OnLostFocus(e);
			this.diJbT1XB6M.Stop();
			this.qXbbsm5ULh = false;
			this.S8gb2mJHII = 0;
			base.Invalidate();
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x000089CC File Offset: 0x00006BCC
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				base.Focus();
				using (Graphics graphics = base.CreateGraphics())
				{
					int yd6bKafddG = this.AmobMaiPa0(graphics, e.X);
					this.YD6bKafddG = yd6bKafddG;
					this.S8gb2mJHII = 0;
					this.j5tb4riSET = true;
					this.K4tbGBeUc2 = this.YD6bKafddG;
					this.rNFbCGycRw();
					base.Invalidate();
				}
			}
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x00008A5C File Offset: 0x00006C5C
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			if (this.j5tb4riSET)
			{
				using (Graphics graphics = base.CreateGraphics())
				{
					int num = this.AmobMaiPa0(graphics, e.X);
					if (num < this.K4tbGBeUc2)
					{
						this.YD6bKafddG = num;
						this.S8gb2mJHII = this.K4tbGBeUc2 - num;
					}
					else
					{
						this.YD6bKafddG = this.K4tbGBeUc2;
						this.S8gb2mJHII = num - this.K4tbGBeUc2;
					}
					this.rNFbCGycRw();
					base.Invalidate();
					return;
				}
			}
			this.Cursor = Cursors.IBeam;
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x00008B0C File Offset: 0x00006D0C
		protected override void OnMouseUp(MouseEventArgs e)
		{
			base.OnMouseUp(e);
			this.j5tb4riSET = false;
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x00008B1C File Offset: 0x00006D1C
		private int T5obS1sjf4(int \u0020)
		{
			if (\u0020 <= 0)
			{
				return 0;
			}
			int i;
			for (i = \u0020 - 1; i > 0; i--)
			{
				if (!char.IsWhiteSpace(this.Xgabm01nvQ[i]))
				{
					break;
				}
			}
			while (i > 0 && !char.IsWhiteSpace(this.Xgabm01nvQ[i - 1]))
			{
				i--;
			}
			return i;
		}

		// Token: 0x060001CA RID: 458 RVA: 0x00008B88 File Offset: 0x00006D88
		public void DeleteWordBack()
		{
			if (this.S8gb2mJHII > 0)
			{
				this.DeleteSelection();
				return;
			}
			if (this.YD6bKafddG > 0)
			{
				int num = this.T5obS1sjf4(this.YD6bKafddG);
				int count = this.YD6bKafddG - num;
				this.Xgabm01nvQ = this.Xgabm01nvQ.Remove(num, count);
				this.YD6bKafddG = num;
				this.rNFbCGycRw();
				base.Invalidate();
				EventHandler eventHandler = this.xwmbqwi7hH;
				if (eventHandler == null)
				{
					return;
				}
				eventHandler(this, EventArgs.Empty);
			}
		}

		// Token: 0x060001CB RID: 459 RVA: 0x00008C0C File Offset: 0x00006E0C
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (keyData == (Keys)131137)
			{
				this.SelectAll();
				return true;
			}
			if (keyData == (Keys)131139)
			{
				this.Copy();
				return true;
			}
			if (keyData == (Keys)131158)
			{
				this.Paste();
				return true;
			}
			if (keyData == (Keys)131160)
			{
				this.Cut();
				return true;
			}
			bool flag = (keyData & Keys.Shift) == Keys.Shift;
			Keys keys = keyData & Keys.KeyCode;
			if (keys == Keys.Left)
			{
				if (flag)
				{
					if (this.S8gb2mJHII == 0)
					{
						if (this.YD6bKafddG > 0)
						{
							this.YD6bKafddG--;
							this.S8gb2mJHII = 1;
						}
					}
					else if (this.YD6bKafddG > 0)
					{
						this.YD6bKafddG--;
						this.S8gb2mJHII++;
					}
				}
				else
				{
					if (this.S8gb2mJHII <= 0 && this.YD6bKafddG > 0)
					{
						this.YD6bKafddG--;
					}
					this.S8gb2mJHII = 0;
				}
				this.qXbbsm5ULh = true;
				this.rNFbCGycRw();
				base.Invalidate();
				return true;
			}
			if (keys == Keys.Right)
			{
				if (flag)
				{
					if (this.YD6bKafddG + this.S8gb2mJHII < this.Xgabm01nvQ.Length)
					{
						this.S8gb2mJHII++;
					}
				}
				else
				{
					if (this.S8gb2mJHII > 0)
					{
						this.YD6bKafddG += this.S8gb2mJHII;
					}
					else if (this.YD6bKafddG < this.Xgabm01nvQ.Length)
					{
						this.YD6bKafddG++;
					}
					this.S8gb2mJHII = 0;
				}
				this.qXbbsm5ULh = true;
				this.rNFbCGycRw();
				base.Invalidate();
				return true;
			}
			if (keyData == (Keys.Back | Keys.Control))
			{
				this.DeleteWordBack();
				return true;
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		// Token: 0x060001CC RID: 460 RVA: 0x00008DE8 File Offset: 0x00006FE8
		protected override void OnKeyPress(KeyPressEventArgs e)
		{
			base.OnKeyPress(e);
			if (char.IsControl(e.KeyChar) && e.KeyChar != '\b')
			{
				return;
			}
			if (e.KeyChar == '\b')
			{
				this.b2cbtSts2F();
			}
			else
			{
				this.InsertText(e.KeyChar.ToString());
			}
			e.Handled = true;
		}

		// Token: 0x060001CD RID: 461 RVA: 0x00008E4C File Offset: 0x0000704C
		private void b2cbtSts2F()
		{
			if (this.S8gb2mJHII > 0)
			{
				this.DeleteSelection();
				return;
			}
			if (this.YD6bKafddG > 0)
			{
				this.Xgabm01nvQ = this.Xgabm01nvQ.Remove(this.YD6bKafddG - 1, 1);
				this.YD6bKafddG--;
				this.rNFbCGycRw();
				base.Invalidate();
				EventHandler eventHandler = this.xwmbqwi7hH;
				if (eventHandler == null)
				{
					return;
				}
				eventHandler(this, EventArgs.Empty);
			}
		}

		// Token: 0x060001CE RID: 462 RVA: 0x00008EC8 File Offset: 0x000070C8
		public void InsertText(string str)
		{
			if (string.IsNullOrEmpty(str))
			{
				return;
			}
			if (this.S8gb2mJHII > 0)
			{
				this.Xgabm01nvQ = this.Xgabm01nvQ.Remove(this.YD6bKafddG, this.S8gb2mJHII);
				this.S8gb2mJHII = 0;
			}
			this.Xgabm01nvQ = this.Xgabm01nvQ.Insert(this.YD6bKafddG, str);
			this.YD6bKafddG += str.Length;
			this.rNFbCGycRw();
			base.Invalidate();
			EventHandler eventHandler = this.xwmbqwi7hH;
			if (eventHandler == null)
			{
				return;
			}
			eventHandler(this, EventArgs.Empty);
		}

		// Token: 0x060001CF RID: 463 RVA: 0x00008F64 File Offset: 0x00007164
		public void DeleteSelection()
		{
			if (this.S8gb2mJHII > 0)
			{
				this.Xgabm01nvQ = this.Xgabm01nvQ.Remove(this.YD6bKafddG, this.S8gb2mJHII);
				this.S8gb2mJHII = 0;
				this.rNFbCGycRw();
				base.Invalidate();
				EventHandler eventHandler = this.xwmbqwi7hH;
				if (eventHandler == null)
				{
					return;
				}
				eventHandler(this, EventArgs.Empty);
			}
		}

		// Token: 0x060001D0 RID: 464 RVA: 0x00008FC8 File Offset: 0x000071C8
		public void SelectAll()
		{
			this.YD6bKafddG = 0;
			this.S8gb2mJHII = this.Xgabm01nvQ.Length;
			base.Invalidate();
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x00008FE8 File Offset: 0x000071E8
		public void Copy()
		{
			if (this.S8gb2mJHII > 0 && this.SVgbrIjQXF == '\0')
			{
				Clipboard.SetText(this.Xgabm01nvQ.Substring(this.YD6bKafddG, this.S8gb2mJHII));
			}
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x00009020 File Offset: 0x00007220
		public void Paste()
		{
			if (Clipboard.ContainsText())
			{
				string text = Clipboard.GetText();
				text = text.Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(432533716 ^ 2105169851 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d), "").Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 564888104 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94), "");
				this.InsertText(text);
			}
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x00009090 File Offset: 0x00007290
		public void Cut()
		{
			if (this.S8gb2mJHII > 0 && this.SVgbrIjQXF == '\0')
			{
				this.Copy();
				this.DeleteSelection();
			}
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x000090B8 File Offset: 0x000072B8
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				System.Windows.Forms.Timer timer = this.diJbT1XB6M;
				if (timer != null)
				{
					timer.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x060001D5 RID: 469 RVA: 0x000090E0 File Offset: 0x000072E0
		[CompilerGenerated]
		private void OFNbcdv5Xq(object \u0020, EventArgs \u0020)
		{
			if (this.Focused)
			{
				this.qXbbsm5ULh = !this.qXbbsm5ULh;
				base.Invalidate();
			}
		}

		// Token: 0x04000125 RID: 293
		private string Xgabm01nvQ;

		// Token: 0x04000126 RID: 294
		private int YD6bKafddG;

		// Token: 0x04000127 RID: 295
		private int S8gb2mJHII;

		// Token: 0x04000128 RID: 296
		private char SVgbrIjQXF;

		// Token: 0x04000129 RID: 297
		private string PUCbNOTxig;

		// Token: 0x0400012A RID: 298
		private bool qXbbsm5ULh;

		// Token: 0x0400012B RID: 299
		private int FR0bHCqooF;

		// Token: 0x0400012C RID: 300
		private bool j5tb4riSET;

		// Token: 0x0400012D RID: 301
		private int K4tbGBeUc2;

		// Token: 0x0400012E RID: 302
		private readonly System.Windows.Forms.Timer diJbT1XB6M;

		// Token: 0x0400012F RID: 303
		private CustomTextBoxColorScheme pshbBaYOAS;

		// Token: 0x04000130 RID: 304
		[CompilerGenerated]
		private EventHandler xwmbqwi7hH;
	}
}
