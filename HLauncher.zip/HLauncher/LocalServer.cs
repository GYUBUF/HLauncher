﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x0200000D RID: 13
public class LocalServer : IDisposable
{
	// Token: 0x17000023 RID: 35
	// (get) Token: 0x06000051 RID: 81 RVA: 0x0000345C File Offset: 0x0000165C
	// (set) Token: 0x06000052 RID: 82 RVA: 0x00003464 File Offset: 0x00001664
	public int Port { get; private set; }

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x06000053 RID: 83 RVA: 0x00003470 File Offset: 0x00001670
	public string BaseUrl
	{
		get
		{
			return string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1441071425 ^ -727272872 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbea00432075407aa72d35bfa93254e3), this.Port);
		}
	}

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000054 RID: 84 RVA: 0x000034A0 File Offset: 0x000016A0
	public bool IsListening
	{
		get
		{
			return this.aJRnKaAnb != null && this.aJRnKaAnb.IsListening;
		}
	}

	// Token: 0x06000055 RID: 85 RVA: 0x000034BC File Offset: 0x000016BC
	public Task<bool> StartAsync()
	{
		LocalServer.<StartAsync>d__11 <StartAsync>d__;
		<StartAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
		<StartAsync>d__.<>4__this = this;
		<StartAsync>d__.<>1__state = -1;
		<StartAsync>d__.<>t__builder.Start<LocalServer.<StartAsync>d__11>(ref <StartAsync>d__);
		return <StartAsync>d__.<>t__builder.Task;
	}

	// Token: 0x06000056 RID: 86 RVA: 0x00003500 File Offset: 0x00001700
	private Task<bool> DJgutq5AQ()
	{
		LocalServer.<CheckConnectivityAsync>d__12 <CheckConnectivityAsync>d__;
		<CheckConnectivityAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
		<CheckConnectivityAsync>d__.<>4__this = this;
		<CheckConnectivityAsync>d__.<>1__state = -1;
		<CheckConnectivityAsync>d__.<>t__builder.Start<LocalServer.<CheckConnectivityAsync>d__12>(ref <CheckConnectivityAsync>d__);
		return <CheckConnectivityAsync>d__.<>t__builder.Task;
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00003544 File Offset: 0x00001744
	public void AddRoute(string path, Action<HttpListenerContext> handler)
	{
		LocalServer.<>c__DisplayClass13_0 CS$<>8__locals1 = new LocalServer.<>c__DisplayClass13_0();
		CS$<>8__locals1.piqjTQuJJy = handler;
		this.a2sLjqDrI[path.Trim(new char[]
		{
			'/'
		})] = new Func<HttpListenerContext, Task>(CS$<>8__locals1.hJ6jGpAoTq);
	}

	// Token: 0x06000058 RID: 88 RVA: 0x00003588 File Offset: 0x00001788
	public void AddAsyncRoute(string path, Func<HttpListenerContext, Task> handler)
	{
		this.a2sLjqDrI[path.Trim(new char[]
		{
			'/'
		})] = handler;
	}

	// Token: 0x06000059 RID: 89 RVA: 0x000035A8 File Offset: 0x000017A8
	private Task OFRvwqjwO(CancellationToken \u0020)
	{
		LocalServer.<AcceptConnectionsAsync>d__15 <AcceptConnectionsAsync>d__;
		<AcceptConnectionsAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<AcceptConnectionsAsync>d__.<>4__this = this;
		<AcceptConnectionsAsync>d__.token = \u0020;
		<AcceptConnectionsAsync>d__.<>1__state = -1;
		<AcceptConnectionsAsync>d__.<>t__builder.Start<LocalServer.<AcceptConnectionsAsync>d__15>(ref <AcceptConnectionsAsync>d__);
		return <AcceptConnectionsAsync>d__.<>t__builder.Task;
	}

	// Token: 0x0600005A RID: 90 RVA: 0x000035F4 File Offset: 0x000017F4
	private Task RrrE7GX5G(HttpListenerContext \u0020)
	{
		LocalServer.<ProcessRequestAsync>d__16 <ProcessRequestAsync>d__;
		<ProcessRequestAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<ProcessRequestAsync>d__.<>4__this = this;
		<ProcessRequestAsync>d__.context = \u0020;
		<ProcessRequestAsync>d__.<>1__state = -1;
		<ProcessRequestAsync>d__.<>t__builder.Start<LocalServer.<ProcessRequestAsync>d__16>(ref <ProcessRequestAsync>d__);
		return <ProcessRequestAsync>d__.<>t__builder.Task;
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00003640 File Offset: 0x00001840
	public void SendTextResponse(HttpListenerContext context, string text, HttpStatusCode code = HttpStatusCode.OK)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(text ?? "");
		this.JqDpOtijo(context, bytes, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1307286652 - 1848242595 ^ -1239898355 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_bcad499d901540f895e61fc7be5dbf2b), code);
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00003690 File Offset: 0x00001890
	public void SendJsonResponse(HttpListenerContext context, object data, HttpStatusCode code = HttpStatusCode.OK)
	{
		string s = JsonConvert.SerializeObject(data, 1);
		byte[] bytes = Encoding.UTF8.GetBytes(s);
		this.JqDpOtijo(context, bytes, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1414349225 >> 4 ^ 528744412 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), code);
	}

	// Token: 0x0600005D RID: 93 RVA: 0x000036DC File Offset: 0x000018DC
	public void SendRawJson(HttpListenerContext context, string json, HttpStatusCode code = HttpStatusCode.OK)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(json ?? yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(372928822 + -1261521798 ^ -258315271 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790));
		this.JqDpOtijo(context, bytes, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1955617249 >> 6 ^ 2030710516 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770), code);
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00003748 File Offset: 0x00001948
	private void JqDpOtijo(HttpListenerContext \u0020, byte[] \u0020, string \u0020, HttpStatusCode \u0020)
	{
		try
		{
			\u0020.Response.StatusCode = (int)\u0020;
			\u0020.Response.ContentType = \u0020;
			\u0020.Response.ContentLength64 = (long)\u0020.Length;
			\u0020.Response.OutputStream.Write(\u0020, 0, \u0020.Length);
		}
		catch
		{
		}
	}

	// Token: 0x0600005F RID: 95 RVA: 0x000037B0 File Offset: 0x000019B0
	private int os4FHMLR0()
	{
		TcpListener tcpListener = new TcpListener(IPAddress.Loopback, 0);
		tcpListener.Start();
		int port = ((IPEndPoint)tcpListener.LocalEndpoint).Port;
		tcpListener.Stop();
		return port;
	}

	// Token: 0x06000060 RID: 96 RVA: 0x000037E8 File Offset: 0x000019E8
	public void Stop()
	{
		CancellationTokenSource ge93aMVjY = this.Ge93aMVjY;
		if (ge93aMVjY != null)
		{
			ge93aMVjY.Cancel();
		}
		HttpListener httpListener = this.aJRnKaAnb;
		if (httpListener != null)
		{
			httpListener.Close();
		}
		this.aJRnKaAnb = null;
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00003820 File Offset: 0x00001A20
	public void Dispose()
	{
		this.Stop();
		CancellationTokenSource ge93aMVjY = this.Ge93aMVjY;
		if (ge93aMVjY == null)
		{
			return;
		}
		ge93aMVjY.Dispose();
	}

	// Token: 0x06000062 RID: 98 RVA: 0x0000383C File Offset: 0x00001A3C
	public LocalServer()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		this.a2sLjqDrI = new Dictionary<string, Func<HttpListenerContext, Task>>(StringComparer.OrdinalIgnoreCase);
		base..ctor();
	}

	// Token: 0x06000063 RID: 99 RVA: 0x00003860 File Offset: 0x00001A60
	[CompilerGenerated]
	private Task Ch9diB6IH()
	{
		return this.OFRvwqjwO(this.Ge93aMVjY.Token);
	}

	// Token: 0x06000064 RID: 100 RVA: 0x00003874 File Offset: 0x00001A74
	[CompilerGenerated]
	private void eabWtvrqM()
	{
		HttpListener httpListener = this.aJRnKaAnb;
		if (httpListener == null)
		{
			return;
		}
		httpListener.Stop();
	}

	// Token: 0x04000023 RID: 35
	private HttpListener aJRnKaAnb;

	// Token: 0x04000024 RID: 36
	private CancellationTokenSource Ge93aMVjY;

	// Token: 0x04000025 RID: 37
	private readonly Dictionary<string, Func<HttpListenerContext, Task>> a2sLjqDrI;

	// Token: 0x04000026 RID: 38
	[CompilerGenerated]
	private int NVsI3L7Gc;
}
