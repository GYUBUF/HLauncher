﻿using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000D2 RID: 210
	public static class Downloader
	{
		// Token: 0x06000440 RID: 1088 RVA: 0x0001A5C8 File Offset: 0x000187C8
		static Downloader()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			ServicePointManager.SecurityProtocol = (SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13);
			Downloader.WQBXzwlgFI = new HttpClient(new HttpClientHandler
			{
				MaxConnectionsPerServer = 10,
				AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate)
			})
			{
				Timeout = TimeSpan.FromMinutes(30.0)
			};
		}

		// Token: 0x06000441 RID: 1089 RVA: 0x0001A61C File Offset: 0x0001881C
		public static Task DownloadAsync(string url, string destPath, IProgress<DownloadStatus> progress = null, CancellationToken token = default(CancellationToken))
		{
			Downloader.<DownloadAsync>d__2 <DownloadAsync>d__;
			<DownloadAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<DownloadAsync>d__.url = url;
			<DownloadAsync>d__.destPath = destPath;
			<DownloadAsync>d__.progress = progress;
			<DownloadAsync>d__.token = token;
			<DownloadAsync>d__.<>1__state = -1;
			<DownloadAsync>d__.<>t__builder.Start<Downloader.<DownloadAsync>d__2>(ref <DownloadAsync>d__);
			return <DownloadAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000442 RID: 1090 RVA: 0x0001A678 File Offset: 0x00018878
		private static void C8NXR4CN3Z(string \u0020, string \u0020)
		{
			if (PathHelper.FileExists(\u0020))
			{
				PathHelper.DeleteFile(\u0020);
			}
			PathHelper.MoveFile(\u0020, \u0020);
		}

		// Token: 0x06000443 RID: 1091 RVA: 0x0001A694 File Offset: 0x00018894
		public static Task<bool> DownloadIfChangedAsync(string url, string destPath, HttpClient client = null)
		{
			Downloader.<DownloadIfChangedAsync>d__4 <DownloadIfChangedAsync>d__;
			<DownloadIfChangedAsync>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<DownloadIfChangedAsync>d__.url = url;
			<DownloadIfChangedAsync>d__.destPath = destPath;
			<DownloadIfChangedAsync>d__.client = client;
			<DownloadIfChangedAsync>d__.<>1__state = -1;
			<DownloadIfChangedAsync>d__.<>t__builder.Start<Downloader.<DownloadIfChangedAsync>d__4>(ref <DownloadIfChangedAsync>d__);
			return <DownloadIfChangedAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x0001A6E8 File Offset: 0x000188E8
		public static Task ExtractArchiveAsync(string zipPath, string targetDir, IProgress<int> progress = null)
		{
			Downloader.<ExtractArchiveAsync>d__5 <ExtractArchiveAsync>d__;
			<ExtractArchiveAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<ExtractArchiveAsync>d__.zipPath = zipPath;
			<ExtractArchiveAsync>d__.targetDir = targetDir;
			<ExtractArchiveAsync>d__.progress = progress;
			<ExtractArchiveAsync>d__.<>1__state = -1;
			<ExtractArchiveAsync>d__.<>t__builder.Start<Downloader.<ExtractArchiveAsync>d__5>(ref <ExtractArchiveAsync>d__);
			return <ExtractArchiveAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0001A73C File Offset: 0x0001893C
		private static void Jm7Xaxw7Tq(string \u0020)
		{
			string[] directories = PathHelper.GetDirectories(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(781125426 - -604724779 ^ 572791866 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add), SearchOption.TopDirectoryOnly);
			if (PathHelper.GetFiles(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2091326168 ^ -43589078 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25), SearchOption.TopDirectoryOnly).Length == 0 && directories.Length == 1)
			{
				string p = directories[0];
				foreach (string text in PathHelper.GetDirectories(p, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-361965784 ^ -2074996175 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c), SearchOption.TopDirectoryOnly))
				{
					PathHelper.MoveDirectory(text, PathHelper.Combine(new string[]
					{
						\u0020,
						Path.GetFileName(text)
					}));
				}
				foreach (string text2 in PathHelper.GetFiles(p, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1721586492 ^ 404821701 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbea00432075407aa72d35bfa93254e3), SearchOption.TopDirectoryOnly))
				{
					PathHelper.MoveFile(text2, PathHelper.Combine(new string[]
					{
						\u0020,
						Path.GetFileName(text2)
					}));
				}
				PathHelper.DeleteDirectory(p, true);
			}
		}

		// Token: 0x040003B4 RID: 948
		private static readonly HttpClient WQBXzwlgFI;
	}
}
