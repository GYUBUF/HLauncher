﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000D1 RID: 209
	public readonly struct DownloadStatus
	{
		// Token: 0x1700008D RID: 141
		// (get) Token: 0x0600043A RID: 1082 RVA: 0x0001A43C File Offset: 0x0001863C
		public long TotalBytes { get; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600043B RID: 1083 RVA: 0x0001A444 File Offset: 0x00018644
		public long BytesDownloaded { get; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x0600043C RID: 1084 RVA: 0x0001A44C File Offset: 0x0001864C
		public double BytesPerSecond { get; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x0600043D RID: 1085 RVA: 0x0001A454 File Offset: 0x00018654
		public double Percent { get; }

		// Token: 0x0600043E RID: 1086 RVA: 0x0001A45C File Offset: 0x0001865C
		public DownloadStatus(long total, long downloaded, double speed)
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.TotalBytes = total;
			this.BytesDownloaded = downloaded;
			this.BytesPerSecond = speed;
			this.Percent = ((total > 0L) ? Math.Round((double)downloaded / (double)total * 100.0, 2) : 0.0);
		}

		// Token: 0x0600043F RID: 1087 RVA: 0x0001A4BC File Offset: 0x000186BC
		public static string FormatBytes(long bytes)
		{
			string[] array = new string[]
			{
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(401291062 ^ 2144225197 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1025056733 ^ 109721393 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(781125426 - -604724779 ^ 547294359 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -172375440 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20)
			};
			int num = 0;
			decimal num2 = bytes;
			while (Math.Round(num2 / 1024m) >= 1m)
			{
				num2 /= 1024m;
				num++;
			}
			return string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(339415119 ^ 1331102243 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967), num2, array[num]);
		}

		// Token: 0x040003B0 RID: 944
		[CompilerGenerated]
		private readonly long njFXnjuaSO;

		// Token: 0x040003B1 RID: 945
		[CompilerGenerated]
		private readonly long ouDX3mENCq;

		// Token: 0x040003B2 RID: 946
		[CompilerGenerated]
		private readonly double mm2XL7WDAU;

		// Token: 0x040003B3 RID: 947
		[CompilerGenerated]
		private readonly double JKYXIu0nJV;
	}
}
