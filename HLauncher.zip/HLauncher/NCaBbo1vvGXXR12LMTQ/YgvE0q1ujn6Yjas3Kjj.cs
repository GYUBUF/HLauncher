﻿using System;
using System.Threading;
using System.Windows.Forms;
using HLauncher;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;
using uSIbxvKkOV86OyFYPaQ;
using UyBdd0m3d7fDJWiP5r1;
using y0ve6F17gu3T12r7mYI;

namespace NCaBbo1vvGXXR12LMTQ
{
	// Token: 0x020000B4 RID: 180
	internal static class YgvE0q1ujn6Yjas3Kjj
	{
		// Token: 0x06000381 RID: 897 RVA: 0x00016378 File Offset: 0x00014578
		[STAThread]
		private static void Main()
		{
			hUuLgnKhnPlS8FM7sW9.kLjw4iIsCLsZtxc4lksN0j();
			xSUri5mn9OWiGm4sKZJ.lLHifFIsCLsZtjvFfN0i();
			bool flag;
			using (new Mutex(true, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-225059726 ^ -1934893218 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25), ref flag))
			{
				if (flag)
				{
					Application.EnableVisualStyles();
					Application.SetCompatibleTextRenderingDefault(false);
					NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
					try
					{
						StyleManager.LoadFonts();
						Application.Run(new Main());
						return;
					}
					finally
					{
						StyleManager.Cleanup();
					}
				}
				bpJXyX1qocPR5dVW9GD.IGX1PKQ3r2((IntPtr)65535, bpJXyX1qocPR5dVW9GD.b841VILlRi, IntPtr.Zero, IntPtr.Zero);
			}
		}

		// Token: 0x06000382 RID: 898 RVA: 0x00016430 File Offset: 0x00014630
		// Note: this type is marked as 'beforefieldinit'.
		static YgvE0q1ujn6Yjas3Kjj()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			hUuLgnKhnPlS8FM7sW9.kLjw4iIsCLsZtxc4lksN0j();
			xSUri5mn9OWiGm4sKZJ.lLHifFIsCLsZtjvFfN0i();
		}
	}
}
