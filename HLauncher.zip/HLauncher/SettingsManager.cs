﻿using System;
using System.IO;
using System.Threading;
using AGSw7LJMkp5usDW1gK1;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000C5 RID: 197
	public static class SettingsManager
	{
		// Token: 0x060003FF RID: 1023 RVA: 0x00019374 File Offset: 0x00017574
		static SettingsManager()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			SettingsManager.ziVXraYsoW = new object();
			SettingsManager.vZRX2pbY4F = PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.METJ4myejd,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1279801375 ^ -1306936433 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b)
			});
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000400 RID: 1024 RVA: 0x000193CC File Offset: 0x000175CC
		public static AppSettings Settings
		{
			get
			{
				if (SettingsManager.JNAXKbsX0l == null)
				{
					object obj = SettingsManager.ziVXraYsoW;
					lock (obj)
					{
						if (SettingsManager.JNAXKbsX0l == null)
						{
							SettingsManager.Load();
						}
					}
				}
				return SettingsManager.JNAXKbsX0l;
			}
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x0001942C File Offset: 0x0001762C
		public static void Load()
		{
			object obj = SettingsManager.ziVXraYsoW;
			lock (obj)
			{
				try
				{
					if (PathHelper.FileExists(SettingsManager.vZRX2pbY4F))
					{
						SettingsManager.JNAXKbsX0l = (JsonConvert.DeserializeObject<AppSettings>(PathHelper.ReadAllText(SettingsManager.vZRX2pbY4F)) ?? new AppSettings());
					}
					else
					{
						SettingsManager.JNAXKbsX0l = new AppSettings();
					}
				}
				catch
				{
					SettingsManager.JNAXKbsX0l = new AppSettings();
				}
			}
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x000194C8 File Offset: 0x000176C8
		public static void Save()
		{
			object obj = SettingsManager.ziVXraYsoW;
			lock (obj)
			{
				try
				{
					string directoryName = Path.GetDirectoryName(SettingsManager.vZRX2pbY4F);
					if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
					{
						Directory.CreateDirectory(directoryName);
					}
					string contents = JsonConvert.SerializeObject(SettingsManager.JNAXKbsX0l, 1);
					File.WriteAllText(SettingsManager.vZRX2pbY4F, contents);
				}
				catch (IOException)
				{
					Thread.Sleep(100);
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00019574 File Offset: 0x00017774
		public static void Reset()
		{
			SettingsManager.JNAXKbsX0l = new AppSettings();
			SettingsManager.Save();
		}

		// Token: 0x0400037C RID: 892
		private static AppSettings JNAXKbsX0l;

		// Token: 0x0400037D RID: 893
		private static readonly string vZRX2pbY4F;

		// Token: 0x0400037E RID: 894
		private static readonly object ziVXraYsoW;
	}
}
