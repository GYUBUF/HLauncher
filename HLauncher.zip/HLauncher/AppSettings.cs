﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000C4 RID: 196
	public class AppSettings
	{
		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060003DA RID: 986 RVA: 0x0001917C File Offset: 0x0001737C
		// (set) Token: 0x060003DB RID: 987 RVA: 0x00019184 File Offset: 0x00017384
		public List<string> OfflineNicknames { get; set; }

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060003DC RID: 988 RVA: 0x00019190 File Offset: 0x00017390
		// (set) Token: 0x060003DD RID: 989 RVA: 0x00019198 File Offset: 0x00017398
		public string SelectedProfileId { get; set; }

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060003DE RID: 990 RVA: 0x000191A4 File Offset: 0x000173A4
		// (set) Token: 0x060003DF RID: 991 RVA: 0x000191AC File Offset: 0x000173AC
		public string SelectedVersionName { get; set; }

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060003E0 RID: 992 RVA: 0x000191B8 File Offset: 0x000173B8
		// (set) Token: 0x060003E1 RID: 993 RVA: 0x000191C0 File Offset: 0x000173C0
		public bool IsOnlineMode { get; set; }

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060003E2 RID: 994 RVA: 0x000191CC File Offset: 0x000173CC
		// (set) Token: 0x060003E3 RID: 995 RVA: 0x000191D4 File Offset: 0x000173D4
		public string Nickname { get; set; }

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060003E4 RID: 996 RVA: 0x000191E0 File Offset: 0x000173E0
		// (set) Token: 0x060003E5 RID: 997 RVA: 0x000191E8 File Offset: 0x000173E8
		public string Language { get; set; }

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060003E6 RID: 998 RVA: 0x000191F4 File Offset: 0x000173F4
		// (set) Token: 0x060003E7 RID: 999 RVA: 0x000191FC File Offset: 0x000173FC
		public bool CheckUpdates { get; set; }

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060003E8 RID: 1000 RVA: 0x00019208 File Offset: 0x00017408
		// (set) Token: 0x060003E9 RID: 1001 RVA: 0x00019210 File Offset: 0x00017410
		public bool VirtualEnabled { get; set; }

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060003EA RID: 1002 RVA: 0x0001921C File Offset: 0x0001741C
		// (set) Token: 0x060003EB RID: 1003 RVA: 0x00019224 File Offset: 0x00017424
		public bool RussianPath { get; set; }

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060003EC RID: 1004 RVA: 0x00019230 File Offset: 0x00017430
		// (set) Token: 0x060003ED RID: 1005 RVA: 0x00019238 File Offset: 0x00017438
		public bool OnlineFixEnabled { get; set; }

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060003EE RID: 1006 RVA: 0x00019244 File Offset: 0x00017444
		// (set) Token: 0x060003EF RID: 1007 RVA: 0x0001924C File Offset: 0x0001744C
		public bool RecommendedServers { get; set; }

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060003F0 RID: 1008 RVA: 0x00019258 File Offset: 0x00017458
		// (set) Token: 0x060003F1 RID: 1009 RVA: 0x00019260 File Offset: 0x00017460
		public bool CleanPatchCache { get; set; }

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060003F2 RID: 1010 RVA: 0x0001926C File Offset: 0x0001746C
		// (set) Token: 0x060003F3 RID: 1011 RVA: 0x00019274 File Offset: 0x00017474
		public bool AnimationsEnabled { get; set; }

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x00019280 File Offset: 0x00017480
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x00019288 File Offset: 0x00017488
		public bool TransparencyEnabled { get; set; }

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060003F6 RID: 1014 RVA: 0x00019294 File Offset: 0x00017494
		// (set) Token: 0x060003F7 RID: 1015 RVA: 0x0001929C File Offset: 0x0001749C
		public bool MainBoxHidden { get; set; }

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060003F8 RID: 1016 RVA: 0x000192A8 File Offset: 0x000174A8
		// (set) Token: 0x060003F9 RID: 1017 RVA: 0x000192B0 File Offset: 0x000174B0
		public bool InTrayHidden { get; set; }

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060003FA RID: 1018 RVA: 0x000192BC File Offset: 0x000174BC
		// (set) Token: 0x060003FB RID: 1019 RVA: 0x000192C4 File Offset: 0x000174C4
		public bool IgnoreNetAlert { get; set; }

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060003FC RID: 1020 RVA: 0x000192D0 File Offset: 0x000174D0
		// (set) Token: 0x060003FD RID: 1021 RVA: 0x000192D8 File Offset: 0x000174D8
		public bool IgnoreAVFolder { get; set; }

		// Token: 0x060003FE RID: 1022 RVA: 0x000192E4 File Offset: 0x000174E4
		public AppSettings()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.OfflineNicknames = new List<string>();
			this.SelectedProfileId = "";
			this.SelectedVersionName = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~234019875 ^ -1694912575 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc);
			this.Nickname = "";
			this.Language = "";
			this.CheckUpdates = true;
			this.OnlineFixEnabled = true;
			this.RecommendedServers = true;
			this.CleanPatchCache = true;
			this.AnimationsEnabled = true;
			base..ctor();
		}

		// Token: 0x0400036A RID: 874
		[CompilerGenerated]
		private List<string> VmlXkKquR7;

		// Token: 0x0400036B RID: 875
		[CompilerGenerated]
		private string QRvXwITJ2g;

		// Token: 0x0400036C RID: 876
		[CompilerGenerated]
		private string jS0XbeOZ4b;

		// Token: 0x0400036D RID: 877
		[CompilerGenerated]
		private bool IyCXJCGeu4;

		// Token: 0x0400036E RID: 878
		[CompilerGenerated]
		private string e9yXxb9Ftc;

		// Token: 0x0400036F RID: 879
		[CompilerGenerated]
		private string NcIX1x8C8n;

		// Token: 0x04000370 RID: 880
		[CompilerGenerated]
		private bool CJEX05qOHH;

		// Token: 0x04000371 RID: 881
		[CompilerGenerated]
		private bool LVrXXlE3L5;

		// Token: 0x04000372 RID: 882
		[CompilerGenerated]
		private bool TFuXjB6k3Q;

		// Token: 0x04000373 RID: 883
		[CompilerGenerated]
		private bool fVoX5eG0c4;

		// Token: 0x04000374 RID: 884
		[CompilerGenerated]
		private bool KxPXyW9nJF;

		// Token: 0x04000375 RID: 885
		[CompilerGenerated]
		private bool mjRXZvnEMn;

		// Token: 0x04000376 RID: 886
		[CompilerGenerated]
		private bool cymXMrN5mU;

		// Token: 0x04000377 RID: 887
		[CompilerGenerated]
		private bool uUUXCdNO1l;

		// Token: 0x04000378 RID: 888
		[CompilerGenerated]
		private bool BiLXSpu1Ut;

		// Token: 0x04000379 RID: 889
		[CompilerGenerated]
		private bool cm9XtejNkh;

		// Token: 0x0400037A RID: 890
		[CompilerGenerated]
		private bool v9oXcGCohK;

		// Token: 0x0400037B RID: 891
		[CompilerGenerated]
		private bool hmuXmnZjtH;
	}
}
