﻿using System;
using System.Drawing;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x02000053 RID: 83
	public class FormDrags
	{
		// Token: 0x060001DD RID: 477 RVA: 0x0000926C File Offset: 0x0000746C
		public FormDrags(Form form)
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
			if (form == null)
			{
				throw new ArgumentNullException(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1565264222 ^ -728735288 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215));
			}
			this.mCibg5raXV = form;
		}

		// Token: 0x060001DE RID: 478 RVA: 0x000092B8 File Offset: 0x000074B8
		public void AttachToControl(Control control)
		{
			if (control == null)
			{
				return;
			}
			control.MouseDown += this.TB1b7k1i6b;
			control.MouseMove += this.gnTbAiuKDn;
			control.MouseUp += this.Vh0bPnn22C;
		}

		// Token: 0x060001DF RID: 479 RVA: 0x000092F8 File Offset: 0x000074F8
		public void DetachFromControl(Control control)
		{
			if (control == null)
			{
				return;
			}
			control.MouseDown -= this.TB1b7k1i6b;
			control.MouseMove -= this.gnTbAiuKDn;
			control.MouseUp -= this.Vh0bPnn22C;
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x00009338 File Offset: 0x00007538
		private void TB1b7k1i6b(object \u0020, MouseEventArgs \u0020)
		{
			this.ft8boF6f3q = true;
			this.t98b9niK95 = Cursor.Position;
			this.PEubQdVCcV = this.mCibg5raXV.Location;
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x00009360 File Offset: 0x00007560
		private void gnTbAiuKDn(object \u0020, MouseEventArgs \u0020)
		{
			if (this.ft8boF6f3q)
			{
				Point pt = Point.Subtract(Cursor.Position, new Size(this.t98b9niK95));
				this.mCibg5raXV.Location = Point.Add(this.PEubQdVCcV, new Size(pt));
			}
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x000093AC File Offset: 0x000075AC
		private void Vh0bPnn22C(object \u0020, MouseEventArgs \u0020)
		{
			this.ft8boF6f3q = false;
		}

		// Token: 0x0400013C RID: 316
		private bool ft8boF6f3q;

		// Token: 0x0400013D RID: 317
		private Point t98b9niK95;

		// Token: 0x0400013E RID: 318
		private Point PEubQdVCcV;

		// Token: 0x0400013F RID: 319
		private readonly Form mCibg5raXV;
	}
}
