﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace Wp3lZxkj6rXGXsu4jjS
{
	// Token: 0x02000032 RID: 50
	internal class wvgJOlkXwNtHE6GK6mY
	{
		// Token: 0x0600010E RID: 270 RVA: 0x00004F1C File Offset: 0x0000311C
		[CompilerGenerated]
		public string vtok5KRJ0q()
		{
			return this.ggjkr6vXEP;
		}

		// Token: 0x0600010F RID: 271 RVA: 0x00004F24 File Offset: 0x00003124
		[CompilerGenerated]
		public void pmjkykSanS(string \u0020)
		{
			this.ggjkr6vXEP = \u0020;
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000110 RID: 272 RVA: 0x00004F30 File Offset: 0x00003130
		// (set) Token: 0x06000111 RID: 273 RVA: 0x00004F38 File Offset: 0x00003138
		public string refresh_token { get; set; }

		// Token: 0x06000112 RID: 274 RVA: 0x00004F44 File Offset: 0x00003144
		[CompilerGenerated]
		public string ulfkSrYVRH()
		{
			return this.XX0ksDBkLK;
		}

		// Token: 0x06000113 RID: 275 RVA: 0x00004F4C File Offset: 0x0000314C
		[CompilerGenerated]
		public void x12kt78Q3u(string \u0020)
		{
			this.XX0ksDBkLK = \u0020;
		}

		// Token: 0x06000114 RID: 276 RVA: 0x00004F58 File Offset: 0x00003158
		[CompilerGenerated]
		public int BADkmKu6cA()
		{
			return this.DwBkHDbYec;
		}

		// Token: 0x06000115 RID: 277 RVA: 0x00004F60 File Offset: 0x00003160
		[CompilerGenerated]
		public void aTDkKvbfYK(int \u0020)
		{
			this.DwBkHDbYec = \u0020;
		}

		// Token: 0x06000116 RID: 278 RVA: 0x00004F6C File Offset: 0x0000316C
		public wvgJOlkXwNtHE6GK6mY()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x040000C5 RID: 197
		[CompilerGenerated]
		private string ggjkr6vXEP;

		// Token: 0x040000C6 RID: 198
		[CompilerGenerated]
		private string HUvkNT9eL1;

		// Token: 0x040000C7 RID: 199
		[CompilerGenerated]
		private string XX0ksDBkLK;

		// Token: 0x040000C8 RID: 200
		[CompilerGenerated]
		private int DwBkHDbYec;
	}
}
