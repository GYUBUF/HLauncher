﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using gpm15skv4ndlJ0bmJ30;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;
using uR6iUfk3GIX55MYPkNT;

// Token: 0x02000036 RID: 54
public partial class RoundedForm : Form
{
	// Token: 0x0600012F RID: 303 RVA: 0x000059BC File Offset: 0x00003BBC
	public RoundedForm()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
		base.FormBorderStyle = FormBorderStyle.None;
		base.StartPosition = FormStartPosition.CenterScreen;
		this.DoubleBuffered = true;
		base.SetStyle(ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		if (LicenseManager.UsageMode == LicenseUsageMode.Runtime && !RoundedForm.ygkkUks7pb)
		{
			this.F1OkiikBsy = new yPEIdHku1BhompHOFRp(this, 18, 18);
		}
	}

	// Token: 0x06000130 RID: 304 RVA: 0x00005A20 File Offset: 0x00003C20
	protected override void OnHandleCreated(EventArgs e)
	{
		base.OnHandleCreated(e);
		if (RoundedForm.ygkkUks7pb)
		{
			this.f4ek6ojngH();
			return;
		}
		this.JFSkOPwjxp();
	}

	// Token: 0x06000131 RID: 305 RVA: 0x00005A40 File Offset: 0x00003C40
	private void f4ek6ojngH()
	{
		int num = 2;
		U10J3wknhsfdKLH2ygX.haQw8FEu3H(base.Handle, 33, ref num, 4U);
		int num2 = U10J3wknhsfdKLH2ygX.AUYwhUdL9g(base.Handle, -16);
		U10J3wknhsfdKLH2ygX.dJ8wkMtRTG(base.Handle, -16, num2 | 12582912 | 131072);
	}

	// Token: 0x06000132 RID: 306 RVA: 0x00005A8C File Offset: 0x00003C8C
	protected override void OnShown(EventArgs e)
	{
		base.OnShown(e);
		if (this.F1OkiikBsy != null)
		{
			this.F1OkiikBsy.Show();
			base.BeginInvoke(new Action(this.bhXkfQxhZR));
		}
	}

	// Token: 0x06000133 RID: 307 RVA: 0x00005AC0 File Offset: 0x00003CC0
	private void JFSkOPwjxp()
	{
		if (RoundedForm.ygkkUks7pb || base.Width <= 0 || base.Height <= 0)
		{
			return;
		}
		IntPtr u = U10J3wknhsfdKLH2ygX.VQHkL9YwyJ(0, 0, base.Width + 1, base.Height + 1, 18, 18);
		U10J3wknhsfdKLH2ygX.oUgkIXYemk(base.Handle, u, true);
		U10J3wknhsfdKLH2ygX.DkokR0U9FS(u);
	}

	// Token: 0x06000134 RID: 308 RVA: 0x00005B24 File Offset: 0x00003D24
	protected override void OnLocationChanged(EventArgs e)
	{
		base.OnLocationChanged(e);
		yPEIdHku1BhompHOFRp f1OkiikBsy = this.F1OkiikBsy;
		if (f1OkiikBsy == null)
		{
			return;
		}
		f1OkiikBsy.GibkE18f7m();
	}

	// Token: 0x06000135 RID: 309 RVA: 0x00005B40 File Offset: 0x00003D40
	protected override void OnSizeChanged(EventArgs e)
	{
		base.OnSizeChanged(e);
		if (!RoundedForm.ygkkUks7pb)
		{
			this.JFSkOPwjxp();
			yPEIdHku1BhompHOFRp f1OkiikBsy = this.F1OkiikBsy;
			if (f1OkiikBsy != null)
			{
				f1OkiikBsy.AwKkpdv9t2();
			}
			base.Invalidate();
		}
	}

	// Token: 0x06000136 RID: 310 RVA: 0x00005B78 File Offset: 0x00003D78
	protected override void OnMouseDown(MouseEventArgs e)
	{
		if (e.Button == MouseButtons.Left)
		{
			U10J3wknhsfdKLH2ygX.KL3kaoRG39();
			U10J3wknhsfdKLH2ygX.AwpkzB1TE1(base.Handle, 161, 2, 0);
		}
		base.OnMouseDown(e);
	}

	// Token: 0x06000138 RID: 312 RVA: 0x00005BD4 File Offset: 0x00003DD4
	// Note: this type is marked as 'beforefieldinit'.
	static RoundedForm()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		RoundedForm.ygkkUks7pb = (Environment.OSVersion.Version.Build >= 22000);
	}

	// Token: 0x06000139 RID: 313 RVA: 0x00005C00 File Offset: 0x00003E00
	[CompilerGenerated]
	private void bhXkfQxhZR()
	{
		this.F1OkiikBsy.AwKkpdv9t2();
		this.F1OkiikBsy.GibkE18f7m();
		base.Activate();
	}

	// Token: 0x040000D2 RID: 210
	private static readonly bool ygkkUks7pb;
}
