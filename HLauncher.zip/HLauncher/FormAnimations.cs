﻿using System;
using System.Windows.Forms;

namespace HLauncher
{
	// Token: 0x02000050 RID: 80
	public static class FormAnimations
	{
		// Token: 0x060001D6 RID: 470 RVA: 0x00009104 File Offset: 0x00007304
		public static Timer AnimateFormAppearance(Form form, double targetOpacity, Action onComplete = null)
		{
			FormAnimations.<>c__DisplayClass0_0 CS$<>8__locals1 = new FormAnimations.<>c__DisplayClass0_0();
			CS$<>8__locals1.Ion5Ae6G4S = form;
			CS$<>8__locals1.SCK5Phtjtd = targetOpacity;
			CS$<>8__locals1.NJ75Qa470G = onComplete;
			if (CS$<>8__locals1.Ion5Ae6G4S == null)
			{
				return null;
			}
			CS$<>8__locals1.Ion5Ae6G4S.Opacity = 0.0;
			CS$<>8__locals1.CxC59LoCTc = new Timer
			{
				Interval = 10
			};
			CS$<>8__locals1.upq5oPWPet = 0.005;
			CS$<>8__locals1.CxC59LoCTc.Tick += CS$<>8__locals1.KtV57hsylQ;
			CS$<>8__locals1.CxC59LoCTc.Start();
			return CS$<>8__locals1.CxC59LoCTc;
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x00009198 File Offset: 0x00007398
		public static Timer AnimateOpacityChange(Form form, double targetOpacity, bool animated = true, Action onComplete = null)
		{
			FormAnimations.<>c__DisplayClass1_0 CS$<>8__locals1 = new FormAnimations.<>c__DisplayClass1_0();
			CS$<>8__locals1.rMg5YbC5MZ = targetOpacity;
			CS$<>8__locals1.lHu5DR7VNL = form;
			CS$<>8__locals1.G1B5OBmebi = onComplete;
			if (CS$<>8__locals1.lHu5DR7VNL == null)
			{
				return null;
			}
			if (!animated)
			{
				CS$<>8__locals1.lHu5DR7VNL.Opacity = CS$<>8__locals1.rMg5YbC5MZ;
				Action g1B5OBmebi = CS$<>8__locals1.G1B5OBmebi;
				if (g1B5OBmebi != null)
				{
					g1B5OBmebi();
				}
				return null;
			}
			CS$<>8__locals1.Wx156u01vG = new Timer
			{
				Interval = 16
			};
			CS$<>8__locals1.Tmh5l86hwM = CS$<>8__locals1.lHu5DR7VNL.Opacity;
			CS$<>8__locals1.oU15VqAgQr = 0.02;
			CS$<>8__locals1.Wx156u01vG.Tick += CS$<>8__locals1.T6D5gZEvSr;
			CS$<>8__locals1.Wx156u01vG.Start();
			return CS$<>8__locals1.Wx156u01vG;
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x00009258 File Offset: 0x00007458
		public static void StopAnimation(Timer timer)
		{
			if (timer != null)
			{
				timer.Stop();
				timer.Dispose();
			}
		}
	}
}
