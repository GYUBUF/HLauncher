﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x0200002E RID: 46
public class PatchlineInfo
{
	// Token: 0x1700003A RID: 58
	// (get) Token: 0x060000DF RID: 223 RVA: 0x00004C8C File Offset: 0x00002E8C
	// (set) Token: 0x060000E0 RID: 224 RVA: 0x00004C94 File Offset: 0x00002E94
	[JsonProperty("buildVersion")]
	public string BuildVersion { get; set; }

	// Token: 0x1700003B RID: 59
	// (get) Token: 0x060000E1 RID: 225 RVA: 0x00004CA0 File Offset: 0x00002EA0
	// (set) Token: 0x060000E2 RID: 226 RVA: 0x00004CA8 File Offset: 0x00002EA8
	[JsonProperty("newest")]
	public int Newest { get; set; }

	// Token: 0x060000E3 RID: 227 RVA: 0x00004CB4 File Offset: 0x00002EB4
	public PatchlineInfo()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
	}

	// Token: 0x040000B1 RID: 177
	[CompilerGenerated]
	private string UNShgsJikD;

	// Token: 0x040000B2 RID: 178
	[CompilerGenerated]
	private int cZAhYCwAVT;
}
