﻿// Token: 0x02000036 RID: 54
public partial class RoundedForm : global::System.Windows.Forms.Form
{
	// Token: 0x06000137 RID: 311 RVA: 0x00005BAC File Offset: 0x00003DAC
	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			global::gpm15skv4ndlJ0bmJ30.yPEIdHku1BhompHOFRp f1OkiikBsy = this.F1OkiikBsy;
			if (f1OkiikBsy != null)
			{
				f1OkiikBsy.Dispose();
			}
		}
		base.Dispose(disposing);
	}

	// Token: 0x040000D1 RID: 209
	private readonly global::gpm15skv4ndlJ0bmJ30.yPEIdHku1BhompHOFRp F1OkiikBsy;
}
