﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

namespace rvUKBghIZ0GPi7iT1sU
{
	// Token: 0x02000031 RID: 49
	internal class HVBFk2hL9hF2dMQhlxf
	{
		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000109 RID: 265 RVA: 0x00004EE0 File Offset: 0x000030E0
		// (set) Token: 0x0600010A RID: 266 RVA: 0x00004EE8 File Offset: 0x000030E8
		[JsonProperty("sub")]
		public string Xrykk8BS6c { get; set; }

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x0600010B RID: 267 RVA: 0x00004EF4 File Offset: 0x000030F4
		// (set) Token: 0x0600010C RID: 268 RVA: 0x00004EFC File Offset: 0x000030FC
		[JsonProperty("email")]
		public string YgVkx7GPXw { get; set; }

		// Token: 0x0600010D RID: 269 RVA: 0x00004F08 File Offset: 0x00003108
		public HVBFk2hL9hF2dMQhlxf()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x040000C3 RID: 195
		[CompilerGenerated]
		private string zcjk1jiFEQ;

		// Token: 0x040000C4 RID: 196
		[CompilerGenerated]
		private string Uqik0okV59;
	}
}
