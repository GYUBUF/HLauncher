﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using AGSw7LJMkp5usDW1gK1;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;
using rvUKBghIZ0GPi7iT1sU;
using Wp3lZxkj6rXGXsu4jjS;

// Token: 0x02000022 RID: 34
public class HytaleAccountManager
{
	// Token: 0x17000032 RID: 50
	// (get) Token: 0x060000AB RID: 171 RVA: 0x000044F0 File Offset: 0x000026F0
	// (set) Token: 0x060000AC RID: 172 RVA: 0x000044F8 File Offset: 0x000026F8
	public List<HytaleAccount> Accounts { get; private set; }

	// Token: 0x060000AD RID: 173 RVA: 0x00004504 File Offset: 0x00002704
	public HytaleAccountManager()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		this.W5YhrdVdXw = new object();
		this.XL3hNpvlqQ = Path.Combine(RJG3u8JZLa1autEARgF.METJ4myejd, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -449830193 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8));
		this.mp5hHLWETj = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-269698511 ^ -181694095 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142);
		this.u6qhTFVMF8 = new CookieContainer();
		this.Accounts = new List<HytaleAccount>();
		base..ctor();
		ServicePointManager.SecurityProtocol = (SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13);
		ServicePointManager.DefaultConnectionLimit = 100;
		this.QQohGFHjbe = new HttpClientHandler
		{
			CookieContainer = this.u6qhTFVMF8,
			UseCookies = true
		};
		this.FhUhst5XLX = new HttpClient(this.QQohGFHjbe);
		this.YJ5hy8llQL();
		this.vqfhSwwpHN();
		this.InitializeVersionAsync();
	}

	// Token: 0x060000AE RID: 174 RVA: 0x000045E4 File Offset: 0x000027E4
	public Task InitializeVersionAsync()
	{
		HytaleAccountManager.<InitializeVersionAsync>d__19 <InitializeVersionAsync>d__;
		<InitializeVersionAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<InitializeVersionAsync>d__.<>4__this = this;
		<InitializeVersionAsync>d__.<>1__state = -1;
		<InitializeVersionAsync>d__.<>t__builder.Start<HytaleAccountManager.<InitializeVersionAsync>d__19>(ref <InitializeVersionAsync>d__);
		return <InitializeVersionAsync>d__.<>t__builder.Task;
	}

	// Token: 0x060000AF RID: 175 RVA: 0x00004628 File Offset: 0x00002828
	private void YJ5hy8llQL()
	{
		this.FhUhst5XLX.DefaultRequestHeaders.Clear();
		this.FhUhst5XLX.DefaultRequestHeaders.TryAddWithoutValidation(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-316901148 - -1443672473 ^ 736353482 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1366522423 ^ -902748068 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d) + this.mp5hHLWETj);
		this.FhUhst5XLX.DefaultRequestHeaders.TryAddWithoutValidation(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1899508754 ^ 54343688 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0), this.mp5hHLWETj);
		this.FhUhst5XLX.DefaultRequestHeaders.TryAddWithoutValidation(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--238918963 ^ 1373514826 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1406576133 >> 4 ^ -692976755 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94));
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x00004720 File Offset: 0x00002920
	public Task<GameSessionResponse> CreateGameSessionAsync(HytaleAccount account)
	{
		HytaleAccountManager.<CreateGameSessionAsync>d__21 <CreateGameSessionAsync>d__;
		<CreateGameSessionAsync>d__.<>t__builder = AsyncTaskMethodBuilder<GameSessionResponse>.Create();
		<CreateGameSessionAsync>d__.<>4__this = this;
		<CreateGameSessionAsync>d__.account = account;
		<CreateGameSessionAsync>d__.<>1__state = -1;
		<CreateGameSessionAsync>d__.<>t__builder.Start<HytaleAccountManager.<CreateGameSessionAsync>d__21>(ref <CreateGameSessionAsync>d__);
		return <CreateGameSessionAsync>d__.<>t__builder.Task;
	}

	// Token: 0x060000B1 RID: 177 RVA: 0x0000476C File Offset: 0x0000296C
	public Task<HytaleAccount> LoginNewAccountAsync()
	{
		HytaleAccountManager.<LoginNewAccountAsync>d__22 <LoginNewAccountAsync>d__;
		<LoginNewAccountAsync>d__.<>t__builder = AsyncTaskMethodBuilder<HytaleAccount>.Create();
		<LoginNewAccountAsync>d__.<>4__this = this;
		<LoginNewAccountAsync>d__.<>1__state = -1;
		<LoginNewAccountAsync>d__.<>t__builder.Start<HytaleAccountManager.<LoginNewAccountAsync>d__22>(ref <LoginNewAccountAsync>d__);
		return <LoginNewAccountAsync>d__.<>t__builder.Task;
	}

	// Token: 0x060000B2 RID: 178 RVA: 0x000047B0 File Offset: 0x000029B0
	public Task FetchLauncherDataAsync(HytaleAccount account)
	{
		HytaleAccountManager.<FetchLauncherDataAsync>d__23 <FetchLauncherDataAsync>d__;
		<FetchLauncherDataAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<FetchLauncherDataAsync>d__.<>4__this = this;
		<FetchLauncherDataAsync>d__.account = account;
		<FetchLauncherDataAsync>d__.<>1__state = -1;
		<FetchLauncherDataAsync>d__.<>t__builder.Start<HytaleAccountManager.<FetchLauncherDataAsync>d__23>(ref <FetchLauncherDataAsync>d__);
		return <FetchLauncherDataAsync>d__.<>t__builder.Task;
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x000047FC File Offset: 0x000029FC
	public Task RefreshTokenIfNeededAsync(HytaleAccount account)
	{
		HytaleAccountManager.<RefreshTokenIfNeededAsync>d__24 <RefreshTokenIfNeededAsync>d__;
		<RefreshTokenIfNeededAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<RefreshTokenIfNeededAsync>d__.<>4__this = this;
		<RefreshTokenIfNeededAsync>d__.account = account;
		<RefreshTokenIfNeededAsync>d__.<>1__state = -1;
		<RefreshTokenIfNeededAsync>d__.<>t__builder.Start<HytaleAccountManager.<RefreshTokenIfNeededAsync>d__24>(ref <RefreshTokenIfNeededAsync>d__);
		return <RefreshTokenIfNeededAsync>d__.<>t__builder.Task;
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x00004848 File Offset: 0x00002A48
	public void Logout(HytaleAccount account)
	{
		this.Accounts.Remove(account);
		this.tMjhCMZ8Mj();
	}

	// Token: 0x060000B5 RID: 181 RVA: 0x00004860 File Offset: 0x00002A60
	private Task<wvgJOlkXwNtHE6GK6mY> LKthZRKufR(string \u0020, string \u0020)
	{
		HytaleAccountManager.<ExchangeCodeForTokenAsync>d__26 <ExchangeCodeForTokenAsync>d__;
		<ExchangeCodeForTokenAsync>d__.<>t__builder = AsyncTaskMethodBuilder<wvgJOlkXwNtHE6GK6mY>.Create();
		<ExchangeCodeForTokenAsync>d__.<>4__this = this;
		<ExchangeCodeForTokenAsync>d__.code = \u0020;
		<ExchangeCodeForTokenAsync>d__.verifier = \u0020;
		<ExchangeCodeForTokenAsync>d__.<>1__state = -1;
		<ExchangeCodeForTokenAsync>d__.<>t__builder.Start<HytaleAccountManager.<ExchangeCodeForTokenAsync>d__26>(ref <ExchangeCodeForTokenAsync>d__);
		return <ExchangeCodeForTokenAsync>d__.<>t__builder.Task;
	}

	// Token: 0x060000B6 RID: 182 RVA: 0x000048B4 File Offset: 0x00002AB4
	private Task<string> dTKhMcQIWA(string \u0020, string \u0020)
	{
		HytaleAccountManager.<PerformBrowserAuthAsync>d__27 <PerformBrowserAuthAsync>d__;
		<PerformBrowserAuthAsync>d__.<>t__builder = AsyncTaskMethodBuilder<string>.Create();
		<PerformBrowserAuthAsync>d__.codeChallenge = \u0020;
		<PerformBrowserAuthAsync>d__.state = \u0020;
		<PerformBrowserAuthAsync>d__.<>1__state = -1;
		<PerformBrowserAuthAsync>d__.<>t__builder.Start<HytaleAccountManager.<PerformBrowserAuthAsync>d__27>(ref <PerformBrowserAuthAsync>d__);
		return <PerformBrowserAuthAsync>d__.<>t__builder.Task;
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x00004900 File Offset: 0x00002B00
	private void tMjhCMZ8Mj()
	{
		try
		{
			string s = JsonConvert.SerializeObject(this.Accounts, 1);
			byte[] bytes = ProtectedData.Protect(Encoding.UTF8.GetBytes(s), null, DataProtectionScope.CurrentUser);
			object w5YhrdVdXw = this.W5YhrdVdXw;
			lock (w5YhrdVdXw)
			{
				File.WriteAllBytes(this.XL3hNpvlqQ, bytes);
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2060960577 >> 4 ^ 1662046913 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d) + ex.Message);
		}
	}

	// Token: 0x060000B8 RID: 184 RVA: 0x000049B8 File Offset: 0x00002BB8
	private void vqfhSwwpHN()
	{
		object w5YhrdVdXw = this.W5YhrdVdXw;
		lock (w5YhrdVdXw)
		{
			if (File.Exists(this.XL3hNpvlqQ))
			{
				try
				{
					byte[] bytes = ProtectedData.Unprotect(File.ReadAllBytes(this.XL3hNpvlqQ), null, DataProtectionScope.CurrentUser);
					string @string = Encoding.UTF8.GetString(bytes);
					this.Accounts = (JsonConvert.DeserializeObject<List<HytaleAccount>>(@string) ?? new List<HytaleAccount>());
				}
				catch
				{
					Console.WriteLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1397297908 ^ 996935528 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f));
					this.Accounts = new List<HytaleAccount>();
				}
			}
		}
	}

	// Token: 0x060000B9 RID: 185 RVA: 0x00004A84 File Offset: 0x00002C84
	private string tFthtBSELe(int \u0020)
	{
		HytaleAccountManager.<>c__DisplayClass30_0 CS$<>8__locals1 = new HytaleAccountManager.<>c__DisplayClass30_0();
		CS$<>8__locals1.BN358rYUXw = new Random();
		return new string(Enumerable.Repeat<string>(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1583188517 ^ 1748815593 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df), \u0020).Select(new Func<string, char>(CS$<>8__locals1.EIxjzJjvSd)).ToArray<char>());
	}

	// Token: 0x060000BA RID: 186 RVA: 0x00004AE0 File Offset: 0x00002CE0
	private string JNmhcgiFSu()
	{
		return this.tFthtBSELe(64);
	}

	// Token: 0x060000BB RID: 187 RVA: 0x00004AEC File Offset: 0x00002CEC
	private string PelhmXpXXW(string \u0020)
	{
		string result;
		using (SHA256 sha = SHA256.Create())
		{
			result = Convert.ToBase64String(sha.ComputeHash(Encoding.UTF8.GetBytes(\u0020))).Replace('+', '-').Replace('/', '_').TrimEnd(new char[]
			{
				'='
			});
		}
		return result;
	}

	// Token: 0x060000BC RID: 188 RVA: 0x00004B5C File Offset: 0x00002D5C
	private HVBFk2hL9hF2dMQhlxf KrBhKgPppl(string \u0020)
	{
		string text = \u0020.Split(new char[]
		{
			'.'
		})[1].Replace('-', '+').Replace('_', '/');
		while (text.Length % 4 != 0)
		{
			text += yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2091326168 ^ -245503754 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0);
		}
		return JsonConvert.DeserializeObject<HVBFk2hL9hF2dMQhlxf>(Encoding.UTF8.GetString(Convert.FromBase64String(text)));
	}

	// Token: 0x04000069 RID: 105
	private readonly object W5YhrdVdXw;

	// Token: 0x0400006A RID: 106
	private readonly string XL3hNpvlqQ;

	// Token: 0x0400006B RID: 107
	private readonly HttpClient FhUhst5XLX;

	// Token: 0x0400006C RID: 108
	private string mp5hHLWETj;

	// Token: 0x0400006D RID: 109
	private bool vTOh4FRyFH;

	// Token: 0x0400006E RID: 110
	private readonly HttpClientHandler QQohGFHjbe;

	// Token: 0x0400006F RID: 111
	private readonly CookieContainer u6qhTFVMF8;

	// Token: 0x04000070 RID: 112
	[CompilerGenerated]
	private List<HytaleAccount> TmyhBy4sA9;
}
