﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x0200003A RID: 58
public static class TaskbarProgress
{
	// Token: 0x0600014F RID: 335 RVA: 0x000060A8 File Offset: 0x000042A8
	static TaskbarProgress()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		TaskbarProgress.cEnwyTH81S = (Environment.OSVersion.Version >= new Version(6, 1));
		if (TaskbarProgress.cEnwyTH81S)
		{
			TaskbarProgress.z7Uw5fj2NZ = (TaskbarProgress.ITaskbarList3)new TaskbarProgress.TaskbarInstance();
			TaskbarProgress.z7Uw5fj2NZ.HrInit();
		}
	}

	// Token: 0x06000150 RID: 336 RVA: 0x00006100 File Offset: 0x00004300
	public static void SetProgress(IntPtr windowHandle, int value, int max = 100)
	{
		if (!TaskbarProgress.cEnwyTH81S || windowHandle == IntPtr.Zero)
		{
			return;
		}
		if (value <= 0)
		{
			TaskbarProgress.z7Uw5fj2NZ.SetProgressState(windowHandle, TaskbarProgress.TaskbarStates.NoProgress);
			return;
		}
		TaskbarProgress.z7Uw5fj2NZ.SetProgressState(windowHandle, TaskbarProgress.TaskbarStates.Normal);
		TaskbarProgress.z7Uw5fj2NZ.SetProgressValue(windowHandle, (ulong)((long)value), (ulong)((long)max));
	}

	// Token: 0x040000DB RID: 219
	private static readonly TaskbarProgress.ITaskbarList3 z7Uw5fj2NZ;

	// Token: 0x040000DC RID: 220
	private static readonly bool cEnwyTH81S;

	// Token: 0x0200003B RID: 59
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("ea1afb91-9e28-4b86-90e9-9e9f8a5eefaf")]
	[ComImport]
	private interface ITaskbarList3
	{
		// Token: 0x06000151 RID: 337
		void HrInit();

		// Token: 0x06000152 RID: 338
		void AddTab(IntPtr hwnd);

		// Token: 0x06000153 RID: 339
		void DeleteTab(IntPtr hwnd);

		// Token: 0x06000154 RID: 340
		void ActivateTab(IntPtr hwnd);

		// Token: 0x06000155 RID: 341
		void SetActiveAlt(IntPtr hwnd);

		// Token: 0x06000156 RID: 342
		void MarkFullscreenWindow(IntPtr hwnd, bool fFullscreen);

		// Token: 0x06000157 RID: 343
		void SetProgressValue(IntPtr hwnd, ulong ullCompleted, ulong ullTotal);

		// Token: 0x06000158 RID: 344
		void SetProgressState(IntPtr hwnd, TaskbarProgress.TaskbarStates tbpFlags);
	}

	// Token: 0x0200003C RID: 60
	[Guid("56fdf344-fd6d-11d0-958a-006097c9a090")]
	[ClassInterface(ClassInterfaceType.None)]
	[ComImport]
	private class TaskbarInstance
	{
		// Token: 0x06000159 RID: 345
		[MethodImpl(MethodImplOptions.InternalCall)]
		public extern TaskbarInstance();
	}

	// Token: 0x0200003D RID: 61
	public enum TaskbarStates
	{
		// Token: 0x040000DE RID: 222
		NoProgress,
		// Token: 0x040000DF RID: 223
		Indeterminate,
		// Token: 0x040000E0 RID: 224
		Normal,
		// Token: 0x040000E1 RID: 225
		Error = 4,
		// Token: 0x040000E2 RID: 226
		Paused = 8
	}
}
