﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;

namespace uR6iUfk3GIX55MYPkNT
{
	// Token: 0x02000038 RID: 56
	internal static class U10J3wknhsfdKLH2ygX
	{
		// Token: 0x0600013F RID: 319
		[DllImport("gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
		public static extern IntPtr VQHkL9YwyJ(int \u0020, int \u0020, int \u0020, int \u0020, int \u0020, int \u0020);

		// Token: 0x06000140 RID: 320
		[DllImport("user32.dll", EntryPoint = "SetWindowRgn")]
		public static extern int oUgkIXYemk(IntPtr \u0020, IntPtr \u0020, bool \u0020);

		// Token: 0x06000141 RID: 321
		[DllImport("gdi32.dll", EntryPoint = "DeleteObject")]
		public static extern bool DkokR0U9FS(IntPtr \u0020);

		// Token: 0x06000142 RID: 322
		[DllImport("user32.dll", EntryPoint = "ReleaseCapture")]
		public static extern bool KL3kaoRG39();

		// Token: 0x06000143 RID: 323
		[DllImport("user32.dll", EntryPoint = "SendMessage")]
		public static extern int AwpkzB1TE1(IntPtr \u0020, int \u0020, int \u0020, int \u0020);

		// Token: 0x06000144 RID: 324
		[DllImport("dwmapi.dll", EntryPoint = "DwmSetWindowAttribute")]
		public static extern int haQw8FEu3H(IntPtr \u0020, int \u0020, ref int \u0020, uint \u0020);

		// Token: 0x06000145 RID: 325
		[DllImport("user32.dll", EntryPoint = "GetWindowLong")]
		public static extern int AUYwhUdL9g(IntPtr \u0020, int \u0020);

		// Token: 0x06000146 RID: 326
		[DllImport("user32.dll", EntryPoint = "SetWindowLong")]
		public static extern int dJ8wkMtRTG(IntPtr \u0020, int \u0020, int \u0020);

		// Token: 0x06000147 RID: 327
		[DllImport("user32.dll", EntryPoint = "UpdateLayeredWindow")]
		public static extern bool DjqwwIi3Ig(IntPtr \u0020, IntPtr \u0020, ref Point \u0020, ref Size \u0020, IntPtr \u0020, ref Point \u0020, int \u0020, ref U10J3wknhsfdKLH2ygX.CqcsfR5hlhMZh3JEQiw \u0020, int \u0020);

		// Token: 0x06000148 RID: 328
		[DllImport("user32.dll", EntryPoint = "GetDC")]
		public static extern IntPtr udCwblLx2t(IntPtr \u0020);

		// Token: 0x06000149 RID: 329
		[DllImport("user32.dll", EntryPoint = "ReleaseDC")]
		public static extern int ABAwJflRRW(IntPtr \u0020, IntPtr \u0020);

		// Token: 0x0600014A RID: 330
		[DllImport("gdi32.dll", EntryPoint = "CreateCompatibleDC")]
		public static extern IntPtr xHkwx5xnnZ(IntPtr \u0020);

		// Token: 0x0600014B RID: 331
		[DllImport("gdi32.dll", EntryPoint = "DeleteDC")]
		public static extern bool EQrw1W1tdv(IntPtr \u0020);

		// Token: 0x0600014C RID: 332
		[DllImport("gdi32.dll", EntryPoint = "SelectObject")]
		public static extern IntPtr Rj7w0lL5MN(IntPtr \u0020, IntPtr \u0020);

		// Token: 0x0600014D RID: 333 RVA: 0x00005EF8 File Offset: 0x000040F8
		public static void VRkwXVPq1l(IntPtr \u0020, Bitmap \u0020, int \u0020, int \u0020)
		{
			IntPtr u = U10J3wknhsfdKLH2ygX.udCwblLx2t(IntPtr.Zero);
			IntPtr u2 = U10J3wknhsfdKLH2ygX.xHkwx5xnnZ(u);
			IntPtr intPtr = IntPtr.Zero;
			IntPtr intPtr2 = IntPtr.Zero;
			try
			{
				intPtr = \u0020.GetHbitmap(Color.FromArgb(0));
				intPtr2 = U10J3wknhsfdKLH2ygX.Rj7w0lL5MN(u2, intPtr);
				Point point = new Point(\u0020, \u0020);
				Size size = \u0020.Size;
				Point point2 = new Point(0, 0);
				U10J3wknhsfdKLH2ygX.CqcsfR5hlhMZh3JEQiw cqcsfR5hlhMZh3JEQiw = new U10J3wknhsfdKLH2ygX.CqcsfR5hlhMZh3JEQiw
				{
					I9m5kMV2h1 = 0,
					JAk5w6Lj1y = 0,
					WI75bR4hxE = byte.MaxValue,
					aeG5JQTHeC = 1
				};
				U10J3wknhsfdKLH2ygX.DjqwwIi3Ig(\u0020, u, ref point, ref size, u2, ref point2, 0, ref cqcsfR5hlhMZh3JEQiw, 2);
			}
			finally
			{
				if (intPtr2 != IntPtr.Zero)
				{
					U10J3wknhsfdKLH2ygX.Rj7w0lL5MN(u2, intPtr2);
				}
				if (intPtr != IntPtr.Zero)
				{
					U10J3wknhsfdKLH2ygX.DkokR0U9FS(intPtr);
				}
				U10J3wknhsfdKLH2ygX.EQrw1W1tdv(u2);
				U10J3wknhsfdKLH2ygX.ABAwJflRRW(IntPtr.Zero, u);
			}
		}

		// Token: 0x0600014E RID: 334 RVA: 0x00005FF0 File Offset: 0x000041F0
		public static GraphicsPath TSVwjEEDOA(Rectangle \u0020, int \u0020)
		{
			int num = \u0020 * 2;
			GraphicsPath graphicsPath = new GraphicsPath();
			if (num <= 0)
			{
				graphicsPath.AddRectangle(\u0020);
				return graphicsPath;
			}
			graphicsPath.AddArc(\u0020.X, \u0020.Y, num, num, 180f, 90f);
			graphicsPath.AddArc(\u0020.Right - num, \u0020.Y, num, num, 270f, 90f);
			graphicsPath.AddArc(\u0020.Right - num, \u0020.Bottom - num, num, num, 0f, 90f);
			graphicsPath.AddArc(\u0020.X, \u0020.Bottom - num, num, num, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x02000039 RID: 57
		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct CqcsfR5hlhMZh3JEQiw
		{
			// Token: 0x040000D7 RID: 215
			public byte I9m5kMV2h1;

			// Token: 0x040000D8 RID: 216
			public byte JAk5w6Lj1y;

			// Token: 0x040000D9 RID: 217
			public byte WI75bR4hxE;

			// Token: 0x040000DA RID: 218
			public byte aeG5JQTHeC;
		}
	}
}
