﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using gt2OLuXUIOYbfABBoJo;
using ro2IpYtzntGHp8CGrmT;
using y0ve6F17gu3T12r7mYI;

namespace HLauncher
{
	// Token: 0x020000AE RID: 174
	public static class PathHelper
	{
		// Token: 0x0600034F RID: 847 RVA: 0x000153F0 File Offset: 0x000135F0
		private static string W1L1DmCkFH(string \u0020)
		{
			if (string.IsNullOrWhiteSpace(\u0020))
			{
				return \u0020;
			}
			string fullPath = Path.GetFullPath(\u0020);
			if (fullPath.StartsWith(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1307286652 - 1848242595 ^ -1296529263 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b)))
			{
				return fullPath;
			}
			if (fullPath.StartsWith(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-316901148 - -1443672473 ^ 635516380 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22)))
			{
				if (fullPath.Length < 260)
				{
					return fullPath;
				}
				return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-704542734 ^ -150739452 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8fc27a48c0ce461586dd8068b3daaced) + fullPath.Substring(2);
			}
			else
			{
				if (fullPath.Length < 260)
				{
					return fullPath;
				}
				return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-800407371 ^ -832438890 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562) + fullPath;
			}
		}

		// Token: 0x06000350 RID: 848 RVA: 0x000154D8 File Offset: 0x000136D8
		public static bool FileExists(string p)
		{
			return File.Exists(PathHelper.W1L1DmCkFH(p));
		}

		// Token: 0x06000351 RID: 849 RVA: 0x000154E8 File Offset: 0x000136E8
		public static bool DirectoryExists(string p)
		{
			return Directory.Exists(PathHelper.W1L1DmCkFH(p));
		}

		// Token: 0x06000352 RID: 850 RVA: 0x000154F8 File Offset: 0x000136F8
		public static bool Exists(string p)
		{
			return PathHelper.FileExists(p) || PathHelper.DirectoryExists(p);
		}

		// Token: 0x06000353 RID: 851 RVA: 0x00015510 File Offset: 0x00013710
		public static void CreateDirectory(string p)
		{
			Directory.CreateDirectory(PathHelper.W1L1DmCkFH(p));
		}

		// Token: 0x06000354 RID: 852 RVA: 0x00015520 File Offset: 0x00013720
		public static void DeleteDirectory(string p, bool recursive = true)
		{
			string text = PathHelper.W1L1DmCkFH(p);
			if (!PathHelper.DirectoryExists(text))
			{
				return;
			}
			try
			{
				PathHelper.RJp162mHQQ(text);
				Directory.Delete(text, recursive);
			}
			catch
			{
				string shortPath = PathHelper.GetShortPath(Path.GetFullPath(p));
				string u = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(198208080 ^ 1965340748 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0) + shortPath + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~515955376 ^ -189389701 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a);
				string u2 = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-582625272 ^ 500065816 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410) + shortPath + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -993642710 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a1f1dffb08f44e581e0c0e6fac695b4);
				yNhAJGXiuLnPpwrVl1j.BsjXuMVO9f(u, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1699465266 ^ -58970681 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22));
				yNhAJGXiuLnPpwrVl1j.BsjXuMVO9f(u2, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(401291062 ^ 746073853 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790));
				if (PathHelper.DirectoryExists(text))
				{
					PathHelper.KillProcessFromPath(text);
					yNhAJGXiuLnPpwrVl1j.BsjXuMVO9f(u2, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1169289335 ^ -1689490449 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8fc27a48c0ce461586dd8068b3daaced));
				}
			}
		}

		// Token: 0x06000355 RID: 853 RVA: 0x00015678 File Offset: 0x00013878
		public static void DeleteFile(string p)
		{
			string path = PathHelper.W1L1DmCkFH(p);
			if (!File.Exists(path))
			{
				return;
			}
			File.SetAttributes(path, FileAttributes.Normal);
			File.Delete(path);
		}

		// Token: 0x06000356 RID: 854 RVA: 0x000156AC File Offset: 0x000138AC
		private static void RJp162mHQQ(string \u0020)
		{
			try
			{
				string[] array = PathHelper.GetFiles(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-917748829 ^ -1411286098 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4), SearchOption.TopDirectoryOnly);
				for (int i = 0; i < array.Length; i++)
				{
					File.SetAttributes(PathHelper.W1L1DmCkFH(array[i]), FileAttributes.Normal);
				}
				foreach (string u in PathHelper.GetDirectories(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -222481940 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0), SearchOption.TopDirectoryOnly))
				{
					PathHelper.RJp162mHQQ(u);
					File.SetAttributes(PathHelper.W1L1DmCkFH(u), FileAttributes.Normal);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00015774 File Offset: 0x00013974
		public static void CopyFile(string s, string d, bool overwrite = false)
		{
			string text = PathHelper.W1L1DmCkFH(d);
			string directoryName = Path.GetDirectoryName(text);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			File.Copy(PathHelper.W1L1DmCkFH(s), text, overwrite);
		}

		// Token: 0x06000358 RID: 856 RVA: 0x000157B0 File Offset: 0x000139B0
		public static void MoveFile(string s, string d)
		{
			string text = PathHelper.W1L1DmCkFH(d);
			string directoryName = Path.GetDirectoryName(text);
			if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			File.Move(PathHelper.W1L1DmCkFH(s), text);
		}

		// Token: 0x06000359 RID: 857 RVA: 0x000157F4 File Offset: 0x000139F4
		public static void MoveDirectory(string s, string d)
		{
			string text = PathHelper.W1L1DmCkFH(s);
			string text2 = PathHelper.W1L1DmCkFH(d);
			if (!Directory.Exists(text))
			{
				return;
			}
			string directoryName = Path.GetDirectoryName(text2);
			if (!string.IsNullOrEmpty(directoryName))
			{
				PathHelper.CreateDirectory(directoryName);
			}
			try
			{
				Directory.Move(text, text2);
			}
			catch (IOException)
			{
				PathHelper.Ex61OECWHn(text, text2);
				PathHelper.DeleteDirectory(text, true);
			}
		}

		// Token: 0x0600035A RID: 858 RVA: 0x00015864 File Offset: 0x00013A64
		private static void Ex61OECWHn(string \u0020, string \u0020)
		{
			PathHelper.CreateDirectory(\u0020);
			foreach (string text in Directory.GetFiles(\u0020))
			{
				PathHelper.CopyFile(text, PathHelper.Combine(new string[]
				{
					\u0020,
					Path.GetFileName(text)
				}), true);
			}
			foreach (string text2 in Directory.GetDirectories(\u0020))
			{
				PathHelper.Ex61OECWHn(text2, PathHelper.Combine(new string[]
				{
					\u0020,
					Path.GetFileName(text2)
				}));
			}
		}

		// Token: 0x0600035B RID: 859 RVA: 0x000158F4 File Offset: 0x00013AF4
		public static string ReadAllText(string p)
		{
			return File.ReadAllText(PathHelper.W1L1DmCkFH(p));
		}

		// Token: 0x0600035C RID: 860 RVA: 0x00015904 File Offset: 0x00013B04
		public static void WriteAllText(string p, string contents)
		{
			string path = PathHelper.W1L1DmCkFH(p);
			string directoryName = Path.GetDirectoryName(path);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			File.WriteAllText(path, contents);
		}

		// Token: 0x0600035D RID: 861 RVA: 0x00015938 File Offset: 0x00013B38
		public static DateTime GetLastWriteTimeUtc(string p)
		{
			return File.GetLastWriteTimeUtc(PathHelper.W1L1DmCkFH(p));
		}

		// Token: 0x0600035E RID: 862 RVA: 0x00015948 File Offset: 0x00013B48
		public static void SetLastWriteTimeUtc(string p, DateTime dt)
		{
			File.SetLastWriteTimeUtc(PathHelper.W1L1DmCkFH(p), dt);
		}

		// Token: 0x0600035F RID: 863 RVA: 0x00015958 File Offset: 0x00013B58
		public static FileStream OpenWrite(string p, FileMode mode = FileMode.Create, bool isAsync = false)
		{
			string path = PathHelper.W1L1DmCkFH(p);
			string directoryName = Path.GetDirectoryName(path);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			return new FileStream(path, mode, FileAccess.Write, FileShare.None, 4096, isAsync);
		}

		// Token: 0x06000360 RID: 864 RVA: 0x00015994 File Offset: 0x00013B94
		public static void WriteAllBytes(string p, byte[] bytes)
		{
			string path = PathHelper.W1L1DmCkFH(p);
			string directoryName = Path.GetDirectoryName(path);
			if (!string.IsNullOrEmpty(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			File.WriteAllBytes(path, bytes);
		}

		// Token: 0x06000361 RID: 865 RVA: 0x000159C8 File Offset: 0x00013BC8
		public static byte[] ReadAllBytes(string p)
		{
			string text = PathHelper.W1L1DmCkFH(p);
			if (!File.Exists(text))
			{
				throw new FileNotFoundException(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(743695506 ^ 1151809839 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc), text);
			}
			return File.ReadAllBytes(text);
		}

		// Token: 0x06000362 RID: 866 RVA: 0x00015A10 File Offset: 0x00013C10
		public static string NormalizePath(string path)
		{
			if (string.IsNullOrWhiteSpace(path))
			{
				return string.Empty;
			}
			return Uri.EscapeDataString(path.Replace('\\', '/').TrimStart(new char[]
			{
				'/'
			}));
		}

		// Token: 0x06000363 RID: 867 RVA: 0x00015A44 File Offset: 0x00013C44
		public static string[] GetFiles(string p, string pattern = "*", SearchOption opt = SearchOption.TopDirectoryOnly)
		{
			return Directory.GetFiles(PathHelper.W1L1DmCkFH(p), pattern, opt);
		}

		// Token: 0x06000364 RID: 868 RVA: 0x00015A54 File Offset: 0x00013C54
		public static string[] GetDirectories(string p, string pattern = "*", SearchOption opt = SearchOption.TopDirectoryOnly)
		{
			return Directory.GetDirectories(PathHelper.W1L1DmCkFH(p), pattern, opt);
		}

		// Token: 0x06000365 RID: 869 RVA: 0x00015A64 File Offset: 0x00013C64
		public static void SetAttributes(string p, FileAttributes attr)
		{
			File.SetAttributes(PathHelper.W1L1DmCkFH(p), attr);
		}

		// Token: 0x06000366 RID: 870 RVA: 0x00015A74 File Offset: 0x00013C74
		public static ZipArchive OpenZipRead(string p)
		{
			return ZipFile.OpenRead(PathHelper.W1L1DmCkFH(p));
		}

		// Token: 0x06000367 RID: 871 RVA: 0x00015A84 File Offset: 0x00013C84
		public static string Combine(params string[] ps)
		{
			return PathHelper.W1L1DmCkFH(Path.Combine(ps));
		}

		// Token: 0x06000368 RID: 872 RVA: 0x00015A94 File Offset: 0x00013C94
		public static long GetFreeSpace(string p)
		{
			string path = PathHelper.W1L1DmCkFH(p);
			long result;
			try
			{
				string pathRoot = Path.GetPathRoot(path);
				if (string.IsNullOrEmpty(pathRoot))
				{
					result = 0L;
				}
				else
				{
					DriveInfo driveInfo = new DriveInfo(pathRoot);
					result = (driveInfo.IsReady ? driveInfo.AvailableFreeSpace : 0L);
				}
			}
			catch
			{
				result = 0L;
			}
			return result;
		}

		// Token: 0x06000369 RID: 873 RVA: 0x00015B04 File Offset: 0x00013D04
		public static long GetFileSize(string p)
		{
			string text = PathHelper.W1L1DmCkFH(p);
			if (!File.Exists(text))
			{
				return 0L;
			}
			return new FileInfo(text).Length;
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00015B34 File Offset: 0x00013D34
		public static long GetDirectorySize(string p)
		{
			string text = PathHelper.W1L1DmCkFH(p);
			if (!PathHelper.DirectoryExists(text))
			{
				return 0L;
			}
			long result;
			try
			{
				result = new DirectoryInfo(text).EnumerateFiles(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(219099983 << 4 ^ -1765218438 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e), SearchOption.AllDirectories).Sum(new Func<FileInfo, long>(PathHelper.<>c.tAVC6BBNlm.KUnCDnTMOG));
			}
			catch
			{
				result = 0L;
			}
			return result;
		}

		// Token: 0x0600036B RID: 875 RVA: 0x00015BCC File Offset: 0x00013DCC
		public static string GetShortPath(string longPath)
		{
			StringBuilder stringBuilder = new StringBuilder(256);
			if (bpJXyX1qocPR5dVW9GD.zfs1gmaJNV(longPath, stringBuilder, stringBuilder.Capacity) <= 0)
			{
				return longPath;
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600036C RID: 876 RVA: 0x00015C00 File Offset: 0x00013E00
		public static string EscapePathForArgs(string path)
		{
			if (string.IsNullOrWhiteSpace(path))
			{
				return string.Empty;
			}
			string fullPath = Path.GetFullPath(path);
			return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(598276251 ^ 1337610078 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264) + fullPath.Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1367514771 ^ -159211016 ^ 638259759 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1984943586 ^ 2048301879 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1)) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(598276251 ^ 406578290 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790);
		}

		// Token: 0x0600036D RID: 877 RVA: 0x00015CA4 File Offset: 0x00013EA4
		public static void CreateSymbolicLink(string linkPath, string targetPath, bool isDirectory = false, bool hidden = false)
		{
			PathHelper.DeleteSymbolicLink(linkPath);
			string text = Path.GetFullPath(linkPath).TrimEnd(new char[]
			{
				Path.DirectorySeparatorChar,
				Path.AltDirectorySeparatorChar
			});
			string text2 = Path.GetFullPath(targetPath).TrimEnd(new char[]
			{
				Path.DirectorySeparatorChar,
				Path.AltDirectorySeparatorChar
			});
			uint u = ((isDirectory > false) ? 1U : 0U) | 2U;
			if (!bpJXyX1qocPR5dVW9GD.OZM1YPbi0w(text, text2, u))
			{
				int lastWin32Error = Marshal.GetLastWin32Error();
				throw new Win32Exception(lastWin32Error, string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1822672301 ^ -1857149800 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb), lastWin32Error, text, text2));
			}
			if (hidden)
			{
				PathHelper.SetAttributes(text, FileAttributes.Hidden | FileAttributes.System);
			}
		}

		// Token: 0x0600036E RID: 878 RVA: 0x00015D54 File Offset: 0x00013F54
		public static bool DeleteSymbolicLink(string path)
		{
			string text = PathHelper.W1L1DmCkFH(path);
			if (!PathHelper.Exists(text))
			{
				return false;
			}
			File.SetAttributes(text, FileAttributes.System | FileAttributes.Normal);
			if (PathHelper.DirectoryExists(text))
			{
				Directory.Delete(text);
			}
			else
			{
				File.Delete(text);
			}
			return true;
		}

		// Token: 0x0600036F RID: 879 RVA: 0x00015DA0 File Offset: 0x00013FA0
		public static void CreateHardLink(string source, string target, bool isDirectory = false, bool hidden = false)
		{
			string text = PathHelper.W1L1DmCkFH(source).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-551092600 ^ 1412615215 ^ -2024964918 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1), "");
			string text2 = PathHelper.W1L1DmCkFH(target).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1363603166 ^ -1624386421 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20), "");
			if (isDirectory)
			{
				if (Directory.Exists(text2))
				{
					try
					{
						PathHelper.DeleteDirectory(text2, true);
					}
					catch
					{
						PathHelper.KillProcessFromPath(text2);
						PathHelper.DeleteDirectory(text2, true);
					}
				}
				Directory.CreateDirectory(text2);
				if (hidden)
				{
					try
					{
						File.SetAttributes(text2, FileAttributes.Hidden | FileAttributes.System);
					}
					catch
					{
					}
				}
				foreach (string text3 in Directory.GetFiles(text, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1751905627 ^ -85121067 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b), SearchOption.AllDirectories))
				{
					string text4 = text3.Substring(text.Length).TrimStart(new char[]
					{
						Path.DirectorySeparatorChar
					});
					string text5 = PathHelper.Combine(new string[]
					{
						text2,
						text4
					});
					string directoryName = Path.GetDirectoryName(text5);
					if (!string.IsNullOrEmpty(directoryName) && !Directory.Exists(directoryName))
					{
						Directory.CreateDirectory(directoryName);
					}
					PathHelper.CreateHardLink(text3, text5, false, false);
				}
				return;
			}
			string text6 = PathHelper.W1L1DmCkFH(target);
			string text7 = PathHelper.W1L1DmCkFH(source);
			string directoryName2 = Path.GetDirectoryName(text6);
			if (!string.IsNullOrEmpty(directoryName2))
			{
				Directory.CreateDirectory(directoryName2);
			}
			if (PathHelper.FileExists(text6))
			{
				PathHelper.DeleteFile(text6);
			}
			bool flag = false;
			if (PathHelper.VDv1iiuMWW(text6) && Path.GetPathRoot(text6) == Path.GetPathRoot(text7))
			{
				flag = bpJXyX1qocPR5dVW9GD.VM51lDdAHG(text6, text7, IntPtr.Zero);
			}
			if (!flag)
			{
				File.Copy(text7, text6, true);
			}
			FileInfo fileInfo = new FileInfo(text6);
			fileInfo.Refresh();
			if (fileInfo.Length == 0L && new FileInfo(text7).Length > 0L)
			{
				try
				{
					PathHelper.DeleteFile(text6);
				}
				catch
				{
				}
				File.Copy(text7, text6, true);
			}
			FileAttributes fileAttributes = hidden ? (FileAttributes.Hidden | FileAttributes.System | FileAttributes.Normal) : FileAttributes.Normal;
			try
			{
				File.SetAttributes(text6, fileAttributes);
			}
			catch
			{
			}
		}

		// Token: 0x06000370 RID: 880 RVA: 0x00016034 File Offset: 0x00014234
		public static Task KillProcessFromPath(string path)
		{
			PathHelper.<KillProcessFromPath>d__34 <KillProcessFromPath>d__;
			<KillProcessFromPath>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<KillProcessFromPath>d__.path = path;
			<KillProcessFromPath>d__.<>1__state = -1;
			<KillProcessFromPath>d__.<>t__builder.Start<PathHelper.<KillProcessFromPath>d__34>(ref <KillProcessFromPath>d__);
			return <KillProcessFromPath>d__.<>t__builder.Task;
		}

		// Token: 0x06000371 RID: 881 RVA: 0x00016078 File Offset: 0x00014278
		private static string soo1fvJKoV(Process \u0020)
		{
			string result;
			try
			{
				ProcessModule mainModule = \u0020.MainModule;
				result = ((mainModule != null) ? mainModule.FileName : null);
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000372 RID: 882 RVA: 0x000160BC File Offset: 0x000142BC
		private static bool VDv1iiuMWW(string \u0020)
		{
			bool result;
			try
			{
				result = new DriveInfo(Path.GetPathRoot(Path.GetFullPath(\u0020))).DriveFormat.Equals(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(219099983 << 4 ^ -1126069147 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264), StringComparison.OrdinalIgnoreCase);
			}
			catch
			{
				result = false;
			}
			return result;
		}
	}
}
