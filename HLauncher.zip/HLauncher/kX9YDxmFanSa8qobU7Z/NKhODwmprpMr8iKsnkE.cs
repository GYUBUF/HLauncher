﻿using System;

namespace kX9YDxmFanSa8qobU7Z
{
	// Token: 0x020000F2 RID: 242
	internal class NKhODwmprpMr8iKsnkE
	{
		// Token: 0x060004F1 RID: 1265 RVA: 0x00032354 File Offset: 0x00030554
		internal static void tWt2mJv6ED()
		{
		}

		// Token: 0x0400042B RID: 1067
		private static bool ixjmdPyVvK;
	}
}
