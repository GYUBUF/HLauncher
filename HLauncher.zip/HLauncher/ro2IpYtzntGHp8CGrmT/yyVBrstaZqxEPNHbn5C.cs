﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using kX9YDxmFanSa8qobU7Z;

namespace ro2IpYtzntGHp8CGrmT
{
	// Token: 0x020000E2 RID: 226
	internal class yyVBrstaZqxEPNHbn5C
	{
		// Token: 0x0600047C RID: 1148 RVA: 0x0002D740 File Offset: 0x0002B940
		static yyVBrstaZqxEPNHbn5C()
		{
			yyVBrstaZqxEPNHbn5C.NJJcpnqrI3 = new uint[]
			{
				3614090360U,
				3905402710U,
				606105819U,
				3250441966U,
				4118548399U,
				1200080426U,
				2821735955U,
				4249261313U,
				1770035416U,
				2336552879U,
				4294925233U,
				2304563134U,
				1804603682U,
				4254626195U,
				2792965006U,
				1236535329U,
				4129170786U,
				3225465664U,
				643717713U,
				3921069994U,
				3593408605U,
				38016083U,
				3634488961U,
				3889429448U,
				568446438U,
				3275163606U,
				4107603335U,
				1163531501U,
				2850285829U,
				4243563512U,
				1735328473U,
				2368359562U,
				4294588738U,
				2272392833U,
				1839030562U,
				4259657740U,
				2763975236U,
				1272893353U,
				4139469664U,
				3200236656U,
				681279174U,
				3936430074U,
				3572445317U,
				76029189U,
				3654602809U,
				3873151461U,
				530742520U,
				3299628645U,
				4096336452U,
				1126891415U,
				2878612391U,
				4237533241U,
				1700485571U,
				2399980690U,
				4293915773U,
				2240044497U,
				1873313359U,
				4264355552U,
				2734768916U,
				1309151649U,
				4149444226U,
				3174756917U,
				718787259U,
				3951481745U
			};
			yyVBrstaZqxEPNHbn5C.r9RcFG2wYm = false;
			yyVBrstaZqxEPNHbn5C.lfjcdQBE7R = false;
			yyVBrstaZqxEPNHbn5C.FMCcW9IUJ4 = null;
			yyVBrstaZqxEPNHbn5C.bRuceGMPSP = null;
			yyVBrstaZqxEPNHbn5C.AwUcnVYrkv = new object();
			yyVBrstaZqxEPNHbn5C.zoZc3ePHTK = 0;
			yyVBrstaZqxEPNHbn5C.Y92cLIjNTp = new object();
			yyVBrstaZqxEPNHbn5C.xpYcI36CGF = null;
			yyVBrstaZqxEPNHbn5C.WO4cRVDiFj = null;
			yyVBrstaZqxEPNHbn5C.kIlcaXkDo5 = new byte[0];
			yyVBrstaZqxEPNHbn5C.ohncz9H3bn = new byte[0];
			yyVBrstaZqxEPNHbn5C.W6ym8PjvYr = IntPtr.Zero;
			yyVBrstaZqxEPNHbn5C.l4Rmh5RuEH = IntPtr.Zero;
			yyVBrstaZqxEPNHbn5C.Rq0mkBLmHb = new string[0];
			yyVBrstaZqxEPNHbn5C.kaXmwCGWl1 = new int[0];
			yyVBrstaZqxEPNHbn5C.zVhmbS9Lig = 1;
			yyVBrstaZqxEPNHbn5C.nNvmJXatcK = false;
			yyVBrstaZqxEPNHbn5C.gu4mxLc34w = new SortedList();
			yyVBrstaZqxEPNHbn5C.AAom1riiMD = 0;
			yyVBrstaZqxEPNHbn5C.Oq9m08NeoQ = 0L;
			yyVBrstaZqxEPNHbn5C.GRmmXUF3Cw = null;
			yyVBrstaZqxEPNHbn5C.BmOmjFbnC4 = null;
			yyVBrstaZqxEPNHbn5C.q85m5cJlFU = 0L;
			yyVBrstaZqxEPNHbn5C.pj3mye07i6 = 0;
			yyVBrstaZqxEPNHbn5C.bd8mZJRG7T = false;
			yyVBrstaZqxEPNHbn5C.RDCmMjhDeI = false;
			yyVBrstaZqxEPNHbn5C.plGmCGaGGP = 0;
			yyVBrstaZqxEPNHbn5C.qnnmSwhXd1 = IntPtr.Zero;
			yyVBrstaZqxEPNHbn5C.kKAmtIRglY = false;
			yyVBrstaZqxEPNHbn5C.Garmc6k3DI = new Hashtable();
			yyVBrstaZqxEPNHbn5C.YwummnZKMS = null;
			yyVBrstaZqxEPNHbn5C.e93mK8HDSw = null;
			yyVBrstaZqxEPNHbn5C.X30m2agtVR = null;
			yyVBrstaZqxEPNHbn5C.fB3mrWuR3b = null;
			yyVBrstaZqxEPNHbn5C.oWsmN0o9vZ = null;
			yyVBrstaZqxEPNHbn5C.bFpmsy2KaX = null;
			yyVBrstaZqxEPNHbn5C.JGHmHuoe0X = IntPtr.Zero;
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600047D RID: 1149 RVA: 0x0002D8B4 File Offset: 0x0002BAB4
		private void D2b2cb5MjJ()
		{
		}

		// Token: 0x0600047E RID: 1150 RVA: 0x0002D8B8 File Offset: 0x0002BAB8
		internal static byte[] TAjc8RR1rE(byte[] \u0020)
		{
			uint[] array = new uint[16];
			uint num = (uint)((448 - \u0020.Length * 8 % 512 + 512) % 512);
			if (num == 0U)
			{
				num = 512U;
			}
			uint num2 = (uint)((long)\u0020.Length + (long)((ulong)(num / 8U)) + 8L);
			ulong num3 = (ulong)((long)\u0020.Length * 8L);
			byte[] array2 = new byte[num2];
			for (int i = 0; i < \u0020.Length; i++)
			{
				array2[i] = \u0020[i];
			}
			byte[] array3 = array2;
			int num4 = \u0020.Length;
			array3[num4] |= 128;
			for (int j = 8; j > 0; j--)
			{
				array2[(int)(checked((IntPtr)(unchecked((ulong)num2 - (ulong)((long)j)))))] = (byte)(num3 >> (8 - j) * 8 & 255UL);
			}
			uint num5 = (uint)(array2.Length * 8 / 32);
			uint num6 = 1732584193U;
			uint num7 = 4023233417U;
			uint num8 = 2562383102U;
			uint num9 = 271733878U;
			for (uint num10 = 0U; num10 < num5 / 16U; num10 += 1U)
			{
				uint num11 = num10 << 6;
				for (uint num12 = 0U; num12 < 61U; num12 += 4U)
				{
					array[(int)(num12 >> 2)] = (uint)((int)array2[(int)(num11 + (num12 + 3U))] << 24 | (int)array2[(int)(num11 + (num12 + 2U))] << 16 | (int)array2[(int)(num11 + (num12 + 1U))] << 8 | (int)array2[(int)(num11 + num12)]);
				}
				uint num13 = num6;
				uint num14 = num7;
				uint num15 = num8;
				uint num16 = num9;
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num6, num7, num8, num9, 0U, 7, 1U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num9, num6, num7, num8, 1U, 12, 2U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num8, num9, num6, num7, 2U, 17, 3U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num7, num8, num9, num6, 3U, 22, 4U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num6, num7, num8, num9, 4U, 7, 5U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num9, num6, num7, num8, 5U, 12, 6U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num8, num9, num6, num7, 6U, 17, 7U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num7, num8, num9, num6, 7U, 22, 8U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num6, num7, num8, num9, 8U, 7, 9U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num9, num6, num7, num8, 9U, 12, 10U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num8, num9, num6, num7, 10U, 17, 11U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num7, num8, num9, num6, 11U, 22, 12U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num6, num7, num8, num9, 12U, 7, 13U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num9, num6, num7, num8, 13U, 12, 14U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num8, num9, num6, num7, 14U, 17, 15U, array);
				yyVBrstaZqxEPNHbn5C.n7JchqNbS5(ref num7, num8, num9, num6, 15U, 22, 16U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num6, num7, num8, num9, 1U, 5, 17U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num9, num6, num7, num8, 6U, 9, 18U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num8, num9, num6, num7, 11U, 14, 19U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num7, num8, num9, num6, 0U, 20, 20U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num6, num7, num8, num9, 5U, 5, 21U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num9, num6, num7, num8, 10U, 9, 22U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num8, num9, num6, num7, 15U, 14, 23U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num7, num8, num9, num6, 4U, 20, 24U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num6, num7, num8, num9, 9U, 5, 25U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num9, num6, num7, num8, 14U, 9, 26U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num8, num9, num6, num7, 3U, 14, 27U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num7, num8, num9, num6, 8U, 20, 28U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num6, num7, num8, num9, 13U, 5, 29U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num9, num6, num7, num8, 2U, 9, 30U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num8, num9, num6, num7, 7U, 14, 31U, array);
				yyVBrstaZqxEPNHbn5C.z05ckhh96M(ref num7, num8, num9, num6, 12U, 20, 32U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num6, num7, num8, num9, 5U, 4, 33U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num9, num6, num7, num8, 8U, 11, 34U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num8, num9, num6, num7, 11U, 16, 35U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num7, num8, num9, num6, 14U, 23, 36U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num6, num7, num8, num9, 1U, 4, 37U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num9, num6, num7, num8, 4U, 11, 38U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num8, num9, num6, num7, 7U, 16, 39U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num7, num8, num9, num6, 10U, 23, 40U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num6, num7, num8, num9, 13U, 4, 41U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num9, num6, num7, num8, 0U, 11, 42U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num8, num9, num6, num7, 3U, 16, 43U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num7, num8, num9, num6, 6U, 23, 44U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num6, num7, num8, num9, 9U, 4, 45U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num9, num6, num7, num8, 12U, 11, 46U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num8, num9, num6, num7, 15U, 16, 47U, array);
				yyVBrstaZqxEPNHbn5C.UcscwNt8Yn(ref num7, num8, num9, num6, 2U, 23, 48U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num6, num7, num8, num9, 0U, 6, 49U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num9, num6, num7, num8, 7U, 10, 50U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num8, num9, num6, num7, 14U, 15, 51U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num7, num8, num9, num6, 5U, 21, 52U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num6, num7, num8, num9, 12U, 6, 53U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num9, num6, num7, num8, 3U, 10, 54U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num8, num9, num6, num7, 10U, 15, 55U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num7, num8, num9, num6, 1U, 21, 56U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num6, num7, num8, num9, 8U, 6, 57U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num9, num6, num7, num8, 15U, 10, 58U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num8, num9, num6, num7, 6U, 15, 59U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num7, num8, num9, num6, 13U, 21, 60U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num6, num7, num8, num9, 4U, 6, 61U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num9, num6, num7, num8, 11U, 10, 62U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num8, num9, num6, num7, 2U, 15, 63U, array);
				yyVBrstaZqxEPNHbn5C.iU6cb9cqxD(ref num7, num8, num9, num6, 9U, 21, 64U, array);
				num6 += num13;
				num7 += num14;
				num8 += num15;
				num9 += num16;
			}
			byte[] array4 = new byte[16];
			Array.Copy(BitConverter.GetBytes(num6), 0, array4, 0, 4);
			Array.Copy(BitConverter.GetBytes(num7), 0, array4, 4, 4);
			Array.Copy(BitConverter.GetBytes(num8), 0, array4, 8, 4);
			Array.Copy(BitConverter.GetBytes(num9), 0, array4, 12, 4);
			return array4;
		}

		// Token: 0x0600047F RID: 1151 RVA: 0x0002DF1C File Offset: 0x0002C11C
		private static void n7JchqNbS5(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += yyVBrstaZqxEPNHbn5C.B7ccJiSZJf(\u0020 + ((\u0020 & \u0020) | (~\u0020 & \u0020)) + \u0020[(int)\u0020] + yyVBrstaZqxEPNHbn5C.NJJcpnqrI3[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000480 RID: 1152 RVA: 0x0002DF48 File Offset: 0x0002C148
		private static void z05ckhh96M(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += yyVBrstaZqxEPNHbn5C.B7ccJiSZJf(\u0020 + ((\u0020 & \u0020) | (\u0020 & ~\u0020)) + \u0020[(int)\u0020] + yyVBrstaZqxEPNHbn5C.NJJcpnqrI3[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000481 RID: 1153 RVA: 0x0002DF74 File Offset: 0x0002C174
		private static void UcscwNt8Yn(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += yyVBrstaZqxEPNHbn5C.B7ccJiSZJf(\u0020 + (\u0020 ^ \u0020 ^ \u0020) + \u0020[(int)\u0020] + yyVBrstaZqxEPNHbn5C.NJJcpnqrI3[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000482 RID: 1154 RVA: 0x0002DF9C File Offset: 0x0002C19C
		private static void iU6cb9cqxD(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, uint[] \u0020)
		{
			\u0020 += yyVBrstaZqxEPNHbn5C.B7ccJiSZJf(\u0020 + (\u0020 ^ (\u0020 | ~\u0020)) + \u0020[(int)\u0020] + yyVBrstaZqxEPNHbn5C.NJJcpnqrI3[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000483 RID: 1155 RVA: 0x0002DFC4 File Offset: 0x0002C1C4
		private static uint B7ccJiSZJf(uint \u0020, ushort \u0020)
		{
			return \u0020 >> (int)(32 - \u0020) | \u0020 << (int)\u0020;
		}

		// Token: 0x06000484 RID: 1156 RVA: 0x0002DFD8 File Offset: 0x0002C1D8
		internal static bool tj0cx7MpgW()
		{
			if (!yyVBrstaZqxEPNHbn5C.r9RcFG2wYm)
			{
				yyVBrstaZqxEPNHbn5C.VbFcXlhLXM();
				yyVBrstaZqxEPNHbn5C.r9RcFG2wYm = true;
			}
			return yyVBrstaZqxEPNHbn5C.lfjcdQBE7R;
		}

		// Token: 0x06000485 RID: 1157 RVA: 0x0002DFF4 File Offset: 0x0002C1F4
		internal yyVBrstaZqxEPNHbn5C()
		{
		}

		// Token: 0x06000486 RID: 1158 RVA: 0x0002DFFC File Offset: 0x0002C1FC
		private void ff6c1CBxk2(byte[] \u0020, byte[] \u0020, byte[] \u0020)
		{
			int num = \u0020.Length % 4;
			int num2 = \u0020.Length / 4;
			byte[] array = new byte[\u0020.Length];
			int num3 = \u0020.Length / 4;
			uint num4 = 0U;
			if (num > 0)
			{
				num2++;
			}
			for (int i = 0; i < num2; i++)
			{
				int num5 = i % num3;
				int num6 = i * 4;
				uint num7 = (uint)(num5 * 4);
				uint num8 = (uint)((int)\u0020[(int)(num7 + 3U)] << 24 | (int)\u0020[(int)(num7 + 2U)] << 16 | (int)\u0020[(int)(num7 + 1U)] << 8 | (int)\u0020[(int)num7]);
				uint num9 = 255U;
				int num10 = 0;
				uint num11;
				if (i == num2 - 1 && num > 0)
				{
					num11 = 0U;
					num4 += num8;
					for (int j = 0; j < num; j++)
					{
						if (j > 0)
						{
							num11 <<= 8;
						}
						num11 |= (uint)\u0020[\u0020.Length - (1 + j)];
					}
				}
				else
				{
					num4 += num8;
					num7 = (uint)num6;
					num11 = (uint)((int)\u0020[(int)(num7 + 3U)] << 24 | (int)\u0020[(int)(num7 + 2U)] << 16 | (int)\u0020[(int)(num7 + 1U)] << 8 | (int)\u0020[(int)num7]);
				}
				uint num12 = num4;
				uint num13 = 431147977U;
				uint num14 = 1554943180U;
				uint num15 = 1900428022U;
				uint num16 = num12;
				num14 = 7336U * (num14 & 32767U) + (num14 >> 15);
				num15 = 116380U * (num15 & 32767U) + (num15 >> 15);
				num13 = 38650U * num13 + num16;
				num14 = 93839U * (num14 & 32767U) + (num14 >> 15);
				num15 = 128385U * (num15 & 32767U) + (num15 >> 15);
				num13 = 8080U * num13 + num16;
				if (num13 == 0U)
				{
					num13 -= 1U;
				}
				uint num17 = num15 / num13 + num13;
				num13 = (num15 - num15 ^ num17) + num15;
				uint num18 = (num14 << 5 | num14 >> 27) ^ num15;
				uint num19 = num18 & 252645135U;
				num18 &= 4042322160U;
				num14 = (num18 >> 4 | num19 << 4);
				uint num20 = num15 - num15 + num15;
				num16 ^= num16 << 26;
				num16 += num13;
				num16 ^= num16 >> 3;
				num16 += num14;
				num16 ^= num16 << 3;
				num16 += num20;
				num16 = ((num13 << 20) + num15 ^ num13) + num16;
				num4 = num12 + (uint)num16;
				if (i == num2 - 1 && num > 0)
				{
					uint num21 = num4 ^ num11;
					for (int k = 0; k < num; k++)
					{
						if (k > 0)
						{
							num9 <<= 8;
							num10 += 8;
						}
						array[num6 + k] = (byte)((num21 & num9) >> num10);
					}
				}
				else
				{
					uint num22 = num4 ^ num11;
					array[num6] = (byte)(num22 & 255U);
					array[num6 + 1] = (byte)((num22 & 65280U) >> 8);
					array[num6 + 2] = (byte)((num22 & 16711680U) >> 16);
					array[num6 + 3] = (byte)((num22 & 4278190080U) >> 24);
				}
			}
			yyVBrstaZqxEPNHbn5C.kIlcaXkDo5 = array;
		}

		// Token: 0x06000487 RID: 1159 RVA: 0x0002E3B4 File Offset: 0x0002C5B4
		internal static SymmetricAlgorithm WrMc0geB2w()
		{
			SymmetricAlgorithm result = null;
			if (yyVBrstaZqxEPNHbn5C.tj0cx7MpgW())
			{
				result = new AesCryptoServiceProvider();
			}
			else
			{
				try
				{
					result = new RijndaelManaged();
				}
				catch
				{
					try
					{
						result = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
					}
					catch
					{
						result = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
					}
				}
			}
			return result;
		}

		// Token: 0x06000488 RID: 1160 RVA: 0x0002E448 File Offset: 0x0002C648
		internal static void VbFcXlhLXM()
		{
			try
			{
				new MD5CryptoServiceProvider();
			}
			catch
			{
				yyVBrstaZqxEPNHbn5C.lfjcdQBE7R = true;
				return;
			}
			try
			{
				yyVBrstaZqxEPNHbn5C.lfjcdQBE7R = CryptoConfig.AllowOnlyFipsAlgorithms;
			}
			catch
			{
			}
		}

		// Token: 0x06000489 RID: 1161 RVA: 0x0002E4A0 File Offset: 0x0002C6A0
		internal static byte[] wwccjpAgAx(byte[] \u0020)
		{
			if (!yyVBrstaZqxEPNHbn5C.tj0cx7MpgW())
			{
				return new MD5CryptoServiceProvider().ComputeHash(\u0020);
			}
			return yyVBrstaZqxEPNHbn5C.TAjc8RR1rE(\u0020);
		}

		// Token: 0x0600048A RID: 1162 RVA: 0x0002E4C0 File Offset: 0x0002C6C0
		internal static void NjFc52Fq1q(HashAlgorithm \u0020, Stream \u0020, uint \u0020, byte[] \u0020)
		{
			while (\u0020 > 0U)
			{
				int num = (\u0020 > (uint)\u0020.Length) ? \u0020.Length : ((int)\u0020);
				\u0020.Read(\u0020, 0, num);
				yyVBrstaZqxEPNHbn5C.DOocymL8QC(\u0020, \u0020, 0, num);
				\u0020 -= (uint)num;
			}
		}

		// Token: 0x0600048B RID: 1163 RVA: 0x0002E504 File Offset: 0x0002C704
		internal static void DOocymL8QC(HashAlgorithm \u0020, byte[] \u0020, int \u0020, int \u0020)
		{
			\u0020.TransformBlock(\u0020, \u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x0600048C RID: 1164 RVA: 0x0002E514 File Offset: 0x0002C714
		internal static uint GA8cZAQsax(uint \u0020, int \u0020, long \u0020, BinaryReader \u0020)
		{
			for (int i = 0; i < \u0020; i++)
			{
				\u0020.BaseStream.Position = \u0020 + (long)(i * 40 + 8);
				uint num = \u0020.ReadUInt32();
				uint num2 = \u0020.ReadUInt32();
				\u0020.ReadUInt32();
				uint num3 = \u0020.ReadUInt32();
				if (num2 <= \u0020 && \u0020 < num2 + num)
				{
					return num3 + \u0020 - num2;
				}
			}
			return 0U;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x0002E57C File Offset: 0x0002C77C
		public static void zXRcM6yMaW(RuntimeTypeHandle \u0020)
		{
			try
			{
				Type typeFromHandle = Type.GetTypeFromHandle(\u0020);
				if (yyVBrstaZqxEPNHbn5C.bRuceGMPSP == null)
				{
					object awUcnVYrkv = yyVBrstaZqxEPNHbn5C.AwUcnVYrkv;
					lock (awUcnVYrkv)
					{
						Dictionary<int, int> dictionary = new Dictionary<int, int>();
						BinaryReader binaryReader = new BinaryReader(typeof(yyVBrstaZqxEPNHbn5C).Assembly.GetManifestResourceStream("vEc00g5aYEGVIYySHu.PYCPreyco2IEjwUwSL"));
						binaryReader.BaseStream.Position = 0L;
						byte[] array = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
						binaryReader.Close();
						if (array.Length != 0)
						{
							int num = array.Length % 4;
							int num2 = array.Length / 4;
							byte[] array2 = new byte[array.Length];
							uint num3 = 0U;
							if (num > 0)
							{
								num2++;
							}
							for (int i = 0; i < num2; i++)
							{
								int num4 = i * 4;
								uint num5 = 255U;
								int num6 = 0;
								uint num7;
								if (i == num2 - 1 && num > 0)
								{
									num7 = 0U;
									for (int j = 0; j < num; j++)
									{
										if (j > 0)
										{
											num7 <<= 8;
										}
										num7 |= (uint)array[array.Length - (1 + j)];
									}
								}
								else
								{
									uint num8 = (uint)num4;
									num7 = (uint)((int)array[(int)(num8 + 3U)] << 24 | (int)array[(int)(num8 + 2U)] << 16 | (int)array[(int)(num8 + 1U)] << 8 | (int)array[(int)num8]);
								}
								num3 = num3;
								num3 += yyVBrstaZqxEPNHbn5C.zLxctXGQbt(num3);
								if (i == num2 - 1 && num > 0)
								{
									uint num9 = num3 ^ num7;
									for (int k = 0; k < num; k++)
									{
										if (k > 0)
										{
											num5 <<= 8;
											num6 += 8;
										}
										array2[num4 + k] = (byte)((num9 & num5) >> num6);
									}
								}
								else
								{
									uint num10 = num3 ^ num7;
									array2[num4] = (byte)(num10 & 255U);
									array2[num4 + 1] = (byte)((num10 & 65280U) >> 8);
									array2[num4 + 2] = (byte)((num10 & 16711680U) >> 16);
									array2[num4 + 3] = (byte)((num10 & 4278190080U) >> 24);
								}
							}
							array = array2;
							int num11 = array.Length / 8;
							yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8 jeCFqRmg7B63R4bEDl = new yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8(new MemoryStream(array));
							for (int l = 0; l < num11; l++)
							{
								int key = jeCFqRmg7B63R4bEDl.Ak7mVtyscl();
								int value = jeCFqRmg7B63R4bEDl.Ak7mVtyscl();
								dictionary.Add(key, value);
							}
							jeCFqRmg7B63R4bEDl.eBCmDZug2e();
						}
						yyVBrstaZqxEPNHbn5C.bRuceGMPSP = dictionary;
					}
				}
				FieldInfo[] fields = typeFromHandle.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetField);
				for (int m = 0; m < fields.Length; m++)
				{
					try
					{
						FieldInfo fieldInfo = fields[m];
						int metadataToken = fieldInfo.MetadataToken;
						int num12 = yyVBrstaZqxEPNHbn5C.bRuceGMPSP[metadataToken];
						bool flag2 = (num12 & 1073741824) > 0;
						num12 &= 1073741823;
						MethodInfo methodInfo = (MethodInfo)typeof(yyVBrstaZqxEPNHbn5C).Module.ResolveMethod(num12, typeFromHandle.GetGenericArguments(), new Type[0]);
						if (methodInfo.IsStatic)
						{
							fieldInfo.SetValue(null, Delegate.CreateDelegate(fieldInfo.FieldType, methodInfo));
						}
						else
						{
							ParameterInfo[] parameters = methodInfo.GetParameters();
							int num13 = parameters.Length + 1;
							Type[] array3 = new Type[num13];
							if (methodInfo.DeclaringType.IsValueType)
							{
								array3[0] = methodInfo.DeclaringType.MakeByRefType();
							}
							else
							{
								array3[0] = typeof(object);
							}
							for (int n = 0; n < parameters.Length; n++)
							{
								array3[n + 1] = parameters[n].ParameterType;
							}
							DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, methodInfo.ReturnType, array3, typeFromHandle, true);
							ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
							for (int num14 = 0; num14 < num13; num14++)
							{
								switch (num14)
								{
								case 0:
									ilgenerator.Emit(OpCodes.Ldarg_0);
									break;
								case 1:
									ilgenerator.Emit(OpCodes.Ldarg_1);
									break;
								case 2:
									ilgenerator.Emit(OpCodes.Ldarg_2);
									break;
								case 3:
									ilgenerator.Emit(OpCodes.Ldarg_3);
									break;
								default:
									ilgenerator.Emit(OpCodes.Ldarg_S, num14);
									break;
								}
							}
							ilgenerator.Emit(OpCodes.Tailcall);
							ilgenerator.Emit(flag2 ? OpCodes.Callvirt : OpCodes.Call, methodInfo);
							ilgenerator.Emit(OpCodes.Ret);
							fieldInfo.SetValue(null, dynamicMethod.CreateDelegate(typeFromHandle));
						}
					}
					catch (Exception)
					{
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x0002EA70 File Offset: 0x0002CC70
		private static uint acRcSW6YAX(uint \u0020)
		{
			return (uint)"KaPmfvRJ3Rh6RfS1F".Length;
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x0002EA7C File Offset: 0x0002CC7C
		private static uint zLxctXGQbt(uint \u0020)
		{
			return 0U;
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x0002EA80 File Offset: 0x0002CC80
		internal static void yebcc3PSyG()
		{
			if (Debugger.IsAttached)
			{
				throw new Exception("Debugger Detected");
			}
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x0002EA98 File Offset: 0x0002CC98
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void kkmcmydgSK(Stream \u0020, int \u0020)
		{
			int num = 134;
			for (;;)
			{
				int num2 = num;
				int num3;
				byte[] array;
				int num4;
				byte[] array2;
				byte[] array5;
				for (;;)
				{
					int num5;
					byte[] array3;
					byte[] array4;
					byte[] array6;
					switch (num2)
					{
					case 0:
						goto IL_2394;
					case 1:
						num3 = 127 - 42;
						num2 = 157;
						continue;
					case 2:
						array[27] = (byte)num3;
						num2 = 331;
						continue;
					case 3:
						num4 = 126 - 42;
						num2 = 112;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 267;
							continue;
						}
						continue;
					case 4:
						num3 = 133 - 44;
						num2 = 50;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 124;
							continue;
						}
						continue;
					case 5:
						goto IL_8BD;
					case 6:
						num3 = 12 + 85;
						num2 = 62;
						continue;
					case 7:
						goto IL_158A;
					case 8:
						array[12] = (byte)num3;
						num2 = 309;
						continue;
					case 9:
						num3 = 0 + 56;
						num2 = 26;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 17;
							continue;
						}
						continue;
					case 10:
						num4 = 181 + 57;
						num2 = 279;
						continue;
					case 11:
						num4 = 162 - 54;
						num2 = 278;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 121;
							continue;
						}
						continue;
					case 12:
						goto IL_2C42;
					case 13:
						num3 = 146 - 48;
						num2 = 318;
						continue;
					case 14:
						array2[4] = 195 - 65;
						num2 = 10;
						continue;
					case 15:
						num4 = 142 - 47;
						num2 = 51;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 84;
							continue;
						}
						continue;
					case 16:
						array[16] = (byte)num3;
						num2 = 39;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 80;
							continue;
						}
						continue;
					case 17:
						array2[11] = 46 + 18;
						num2 = 167;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 292;
							continue;
						}
						continue;
					case 18:
						goto IL_11C4;
					case 19:
						num3 = 220 - 73;
						num2 = 154;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 329;
							continue;
						}
						continue;
					case 20:
						array[8] = (byte)num3;
						num2 = 82;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 136;
							continue;
						}
						continue;
					case 21:
						num3 = 38 + 3;
						num2 = 141;
						continue;
					case 22:
						num3 = 226 - 75;
						num2 = 30;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 34;
							continue;
						}
						continue;
					case 23:
						goto IL_180A;
					case 24:
						array2[10] = 70 + 88;
						num2 = 175;
						continue;
					case 25:
						goto IL_70F;
					case 26:
						array[13] = (byte)num3;
						num2 = 44;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 165;
							continue;
						}
						continue;
					case 27:
						num5++;
						num2 = 256;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 132;
							continue;
						}
						continue;
					case 28:
						array[2] = (byte)num3;
						num2 = 237;
						continue;
					case 29:
						array[23] = (byte)num3;
						num2 = 44;
						continue;
					case 30:
						array[18] = 199 - 66;
						num2 = 191;
						continue;
					case 31:
						array[26] = (byte)num3;
						num2 = 320;
						continue;
					case 32:
						array[17] = 168 - 59;
						num2 = 253;
						continue;
					case 33:
						array[24] = (byte)num3;
						num2 = 54;
						continue;
					case 34:
						array[23] = (byte)num3;
						num2 = 171;
						continue;
					case 35:
						array2[6] = 121 + 82;
						num2 = 258;
						continue;
					case 36:
						array3 = yyVBrstaZqxEPNHbn5C.kIlcaXkDo5;
						num2 = 51;
						continue;
					case 37:
						num3 = 150 + 85;
						num2 = 295;
						continue;
					case 38:
						num4 = 173 - 57;
						num2 = 332;
						continue;
					case 39:
						num3 = 73 + 41;
						num2 = 5;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 5;
							continue;
						}
						continue;
					case 40:
						return;
					case 41:
						array[14] = 128 - 42;
						num2 = 263;
						continue;
					case 42:
						array[8] = (byte)num3;
						num2 = 159;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 69;
							continue;
						}
						continue;
					case 43:
						array[31] = 109 + 61;
						num2 = 183;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 37;
							continue;
						}
						continue;
					case 44:
						array[24] = 11 + 94;
						num2 = 13;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 13;
							continue;
						}
						continue;
					case 45:
						array[19] = 163 + 57;
						num2 = 160;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 40;
							continue;
						}
						continue;
					case 46:
						array2[15] = 47 + 23;
						num2 = 222;
						continue;
					case 47:
						array2[14] = (byte)num4;
						num2 = 233;
						continue;
					case 48:
					{
						Stream stream;
						ICryptoTransform transform;
						CryptoStream cryptoStream = new CryptoStream(stream, transform, CryptoStreamMode.Write);
						yyVBrstaZqxEPNHbn5C.aH3krl25yq5HEWCPdfL(cryptoStream, array3, 0, array3.Length);
						yyVBrstaZqxEPNHbn5C.rBX8FM2ymd2JWCh1BFT(cryptoStream);
						yyVBrstaZqxEPNHbn5C.kIlcaXkDo5 = yyVBrstaZqxEPNHbn5C.egvayX2ZTP05HTX02Vm(stream);
						yyVBrstaZqxEPNHbn5C.bVZ7tL2MIEIev1h1N2e(stream);
						yyVBrstaZqxEPNHbn5C.bVZ7tL2MIEIev1h1N2e(cryptoStream);
						num2 = 36;
						continue;
					}
					case 49:
						array2[14] = (byte)num4;
						num2 = 230;
						continue;
					case 50:
						num3 = 188 + 30;
						num2 = 64;
						continue;
					case 51:
						goto IL_1894;
					case 52:
						num3 = 61 + 96;
						num2 = 98;
						continue;
					case 53:
						goto IL_297D;
					case 54:
						array[24] = 198 - 66;
						num2 = 211;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 1;
							continue;
						}
						continue;
					case 55:
						array[31] = 148 + 36;
						num2 = 1;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 129;
							continue;
						}
						continue;
					case 56:
						num3 = 17 + 13;
						num2 = 92;
						continue;
					case 57:
						array2[7] = 143 - 47;
						num2 = 234;
						continue;
					case 58:
						num3 = 50 + 86;
						num2 = 245;
						continue;
					case 59:
						num4 = 74 + 98;
						num2 = 204;
						continue;
					case 60:
						num3 = 139 - 46;
						num2 = 203;
						continue;
					case 61:
						array4[13] = array5[6];
						num2 = 271;
						continue;
					case 62:
						array[9] = (byte)num3;
						num2 = 152;
						continue;
					case 63:
						num4 = 13 + 117;
						num2 = 127;
						continue;
					case 64:
						array[9] = (byte)num3;
						num2 = 174;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 33;
							continue;
						}
						continue;
					case 65:
						goto IL_F08;
					case 66:
						array[3] = 234 - 119;
						num2 = 19;
						continue;
					case 67:
						num4 = 84 + 99;
						num2 = 274;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 45;
							continue;
						}
						continue;
					case 68:
						goto IL_6EC;
					case 69:
						array[8] = 170 + 52;
						num2 = 239;
						continue;
					case 70:
						array[14] = (byte)num3;
						num2 = 131;
						continue;
					case 71:
						array[16] = 46 + 53;
						num2 = 95;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 302;
							continue;
						}
						continue;
					case 72:
						num3 = 43 + 3;
						num2 = 288;
						continue;
					case 73:
						num3 = 11 + 91;
						num2 = 109;
						continue;
					case 74:
						goto IL_252C;
					case 75:
						num3 = 15 + 58;
						num2 = 42;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 76:
						array2[10] = 141 - 47;
						num2 = 24;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 77:
						goto IL_18C3;
					case 78:
						array[12] = (byte)num3;
						num2 = 261;
						continue;
					case 79:
						array[5] = 128 + 83;
						num2 = 90;
						continue;
					case 80:
						array[16] = 218 - 72;
						num2 = 41;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 71;
							continue;
						}
						continue;
					case 81:
						array2[2] = 74 + 51;
						num2 = 56;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 67;
							continue;
						}
						continue;
					case 82:
						array[25] = (byte)num3;
						num2 = 218;
						continue;
					case 83:
						array[0] = 76 + 59;
						num2 = 296;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 300;
							continue;
						}
						continue;
					case 84:
						array2[4] = (byte)num4;
						num2 = 14;
						continue;
					case 85:
						array2[10] = (byte)num4;
						num2 = 149;
						continue;
					case 86:
						array[27] = 80 + 56;
						num2 = 287;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 314;
							continue;
						}
						continue;
					case 87:
						num4 = 75 + 122;
						num2 = 241;
						continue;
					case 88:
						goto IL_17FD;
					case 89:
						array2[6] = 232 - 77;
						num2 = 35;
						continue;
					case 90:
						num3 = 30 + 31;
						num2 = 1;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 7;
							continue;
						}
						continue;
					case 91:
						array[21] = 129 + 74;
						num2 = 7;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 52;
							continue;
						}
						continue;
					case 92:
						array[6] = (byte)num3;
						num2 = 224;
						continue;
					case 93:
						array[22] = (byte)num3;
						num2 = 11;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 22;
							continue;
						}
						continue;
					case 94:
						array[17] = (byte)num3;
						num2 = 32;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 95:
						num3 = 202 - 97;
						num2 = 323;
						continue;
					case 96:
						array2[5] = 190 - 63;
						num2 = 37;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 63;
							continue;
						}
						continue;
					case 97:
						array[13] = (byte)num3;
						num2 = 168;
						continue;
					case 98:
						array[22] = (byte)num3;
						num2 = 235;
						continue;
					case 99:
						goto IL_69F;
					case 100:
						goto IL_A86;
					case 101:
						array4 = array2;
						num2 = 275;
						continue;
					case 102:
						num3 = 92 + 118;
						num2 = 254;
						continue;
					case 103:
						array2[5] = 42 + 106;
						num2 = 123;
						continue;
					case 104:
						array[7] = 39 + 44;
						num2 = 77;
						continue;
					case 105:
						array2[10] = 138 - 46;
						num2 = 195;
						continue;
					case 106:
					{
						object obj = yyVBrstaZqxEPNHbn5C.e0F4UI210lo7XeDNwgc();
						yyVBrstaZqxEPNHbn5C.HdYneq200c4awElfuZG(obj, CipherMode.CBC);
						ICryptoTransform transform = yyVBrstaZqxEPNHbn5C.gxMujP2XlXQiNX1F8Se(obj, array6, array4);
						num2 = 115;
						continue;
					}
					case 107:
						num4 = 123 + 11;
						num2 = 259;
						continue;
					case 108:
						array[28] = 208 - 69;
						num2 = 198;
						continue;
					case 109:
						array[8] = (byte)num3;
						num2 = 310;
						continue;
					case 110:
						array[11] = (byte)num3;
						num2 = 176;
						continue;
					case 111:
						array[7] = 247 - 82;
						num2 = 104;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 55;
							continue;
						}
						continue;
					case 112:
						goto IL_1780;
					case 113:
						array2[6] = (byte)num4;
						num2 = 248;
						continue;
					case 114:
						num3 = 145 - 48;
						num2 = 153;
						continue;
					case 115:
					{
						Stream stream = yyVBrstaZqxEPNHbn5C.gsOZwG2j9jObMpYRCxg();
						num2 = 2;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 48;
							continue;
						}
						continue;
					}
					case 116:
						break;
					case 117:
						array2[0] = 65 + 114;
						num2 = 53;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 15;
							continue;
						}
						continue;
					case 118:
						array2[9] = (byte)num4;
						num2 = 215;
						continue;
					case 119:
						num4 = 37 + 17;
						num2 = 196;
						continue;
					case 120:
						goto IL_1512;
					case 121:
						num3 = 120 + 81;
						num2 = 139;
						continue;
					case 122:
						array2 = new byte[16];
						num2 = 219;
						continue;
					case 123:
						goto IL_1CEA;
					case 124:
						array[21] = (byte)num3;
						num2 = 91;
						continue;
					case 125:
						num3 = 228 - 76;
						num2 = 161;
						continue;
					case 126:
						array2[1] = (byte)num4;
						num2 = 322;
						continue;
					case 127:
						array2[5] = (byte)num4;
						num2 = 103;
						continue;
					case 128:
						array2[7] = (byte)num4;
						num2 = 23;
						continue;
					case 129:
						array6 = array;
						num2 = 122;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 94;
							continue;
						}
						continue;
					case 130:
						array2[13] = 58 + 98;
						num2 = 164;
						continue;
					case 131:
						array[14] = 115 + 26;
						num2 = 20;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 266;
							continue;
						}
						continue;
					case 132:
						num4 = 152 + 79;
						num2 = 49;
						continue;
					case 133:
						array = new byte[32];
						num2 = 182;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 182;
							continue;
						}
						continue;
					case 134:
					{
						yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8 jeCFqRmg7B63R4bEDl = new yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8(\u0020);
						yyVBrstaZqxEPNHbn5C.mOaosD28oyTM2eW7JC1(yyVBrstaZqxEPNHbn5C.tNPGhDKza9257vceh2t(jeCFqRmg7B63R4bEDl), 0L);
						array3 = yyVBrstaZqxEPNHbn5C.yNRN8w2kXs6e54HhoYp(jeCFqRmg7B63R4bEDl, (int)yyVBrstaZqxEPNHbn5C.BI4VFF2hyCKmWGmphd2(yyVBrstaZqxEPNHbn5C.tNPGhDKza9257vceh2t(jeCFqRmg7B63R4bEDl)));
						yyVBrstaZqxEPNHbn5C.cRPRnj2woc0K4YOESd8(jeCFqRmg7B63R4bEDl);
						num2 = 133;
						continue;
					}
					case 135:
						goto IL_90B;
					case 136:
						array[8] = 172 - 57;
						num2 = 69;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 59;
							continue;
						}
						continue;
					case 137:
						num3 = 5 + 18;
						num2 = 97;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 58;
							continue;
						}
						continue;
					case 138:
						array[23] = (byte)num3;
						num2 = 163;
						continue;
					case 139:
						array[26] = (byte)num3;
						num2 = 86;
						continue;
					case 140:
						array[10] = 160 + 77;
						num2 = 192;
						continue;
					case 141:
						array[19] = (byte)num3;
						num2 = 276;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 317;
							continue;
						}
						continue;
					case 142:
						array[19] = 154 - 51;
						num2 = 45;
						continue;
					case 143:
						array2[6] = (byte)num4;
						num2 = 167;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 28;
							continue;
						}
						continue;
					case 144:
						array2[12] = 247 - 82;
						num2 = 321;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 72;
							continue;
						}
						continue;
					case 145:
						array[8] = (byte)num3;
						num2 = 75;
						continue;
					case 146:
						num3 = 142 - 47;
						num2 = 231;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 61;
							continue;
						}
						continue;
					case 147:
						num3 = 227 - 75;
						num2 = 207;
						continue;
					case 148:
						array2[8] = 105 + 79;
						num2 = 17;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 158;
							continue;
						}
						continue;
					case 149:
						goto IL_2D3F;
					case 150:
						array[7] = (byte)num3;
						num2 = 73;
						continue;
					case 151:
						num3 = 111 - 54;
						num2 = 28;
						continue;
					case 152:
						array[9] = 62 + 101;
						num2 = 255;
						continue;
					case 153:
						array[20] = (byte)num3;
						num2 = 250;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 163;
							continue;
						}
						continue;
					case 154:
						array[1] = 84 + 35;
						num2 = 37;
						continue;
					case 155:
						array2[15] = (byte)num4;
						num2 = 98;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 303;
							continue;
						}
						continue;
					case 156:
						array[18] = (byte)num3;
						num2 = 30;
						continue;
					case 157:
						array[1] = (byte)num3;
						num2 = 154;
						continue;
					case 158:
						array2[9] = 236 - 78;
						num2 = 140;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 246;
							continue;
						}
						continue;
					case 159:
						goto IL_121E;
					case 160:
						array[20] = 89 + 70;
						num2 = 114;
						continue;
					case 161:
						array[28] = (byte)num3;
						num2 = 276;
						continue;
					case 162:
						array[2] = 165 - 55;
						num2 = 53;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 290;
							continue;
						}
						continue;
					case 163:
						num3 = 113 - 7;
						num2 = 29;
						continue;
					case 164:
						num4 = 201 - 67;
						num2 = 122;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 197;
							continue;
						}
						continue;
					case 165:
						array[13] = 115 + 24;
						num2 = 41;
						continue;
					case 166:
						array[26] = (byte)num3;
						num2 = 121;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 12;
							continue;
						}
						continue;
					case 167:
						goto IL_241D;
					case 168:
						num3 = 74 + 87;
						num2 = 99;
						continue;
					case 169:
						array[11] = (byte)num3;
						num2 = 170;
						continue;
					case 170:
						num3 = 18 + 8;
						num2 = 78;
						continue;
					case 171:
						num3 = 133 - 44;
						num2 = 138;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 132;
							continue;
						}
						continue;
					case 172:
						num4 = 20 + 58;
						num2 = 38;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 326;
							continue;
						}
						continue;
					case 173:
						num3 = 135 - 45;
						num2 = 110;
						continue;
					case 174:
						num3 = 175 - 58;
						num2 = 251;
						continue;
					case 175:
						array2[11] = 67 + 61;
						num2 = 281;
						continue;
					case 176:
						num3 = 118 + 98;
						num2 = 154;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 169;
							continue;
						}
						continue;
					case 177:
						num3 = 253 - 84;
						num2 = 277;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 185;
							continue;
						}
						continue;
					case 178:
						array[17] = 173 - 57;
						num2 = 164;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 190;
							continue;
						}
						continue;
					case 179:
						goto IL_1B2C;
					case 180:
						goto IL_90B;
					case 181:
						array2[8] = (byte)num4;
						num2 = 102;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 148;
							continue;
						}
						continue;
					case 182:
						array[0] = 126 - 42;
						num2 = 83;
						continue;
					case 183:
						goto IL_1C96;
					case 184:
						array2[14] = 87 + 4;
						num2 = 52;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 229;
							continue;
						}
						continue;
					case 185:
						array2[7] = (byte)num4;
						num2 = 59;
						continue;
					case 186:
						array[29] = 87 + 94;
						num2 = 244;
						continue;
					case 187:
						array[3] = 246 - 82;
						num2 = 55;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 66;
							continue;
						}
						continue;
					case 188:
						array[1] = 91 + 50;
						num2 = 312;
						continue;
					case 189:
						array[28] = (byte)num3;
						num2 = 146;
						continue;
					case 190:
						num3 = 244 - 81;
						num2 = 18;
						continue;
					case 191:
						num3 = 133 + 9;
						num2 = 287;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 27;
							continue;
						}
						continue;
					case 192:
						num3 = 4 + 11;
						num2 = 265;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 91;
							continue;
						}
						continue;
					case 193:
						array4[5] = array5[2];
						num2 = 236;
						continue;
					case 194:
						if (array5 != null)
						{
							num2 = 286;
							continue;
						}
						goto IL_17FD;
					case 195:
						goto IL_2342;
					case 196:
						array2[1] = (byte)num4;
						num2 = 252;
						continue;
					case 197:
						array2[13] = (byte)num4;
						num2 = 308;
						continue;
					case 198:
						array[28] = 10 + 72;
						num2 = 79;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 206;
							continue;
						}
						continue;
					case 199:
						num4 = 32 + 116;
						num2 = 181;
						continue;
					case 200:
						array[6] = (byte)num3;
						num2 = 299;
						continue;
					case 201:
						array[30] = 79 + 67;
						num2 = 269;
						continue;
					case 202:
						goto IL_1579;
					case 203:
						goto IL_A13;
					case 204:
						array2[7] = (byte)num4;
						num2 = 57;
						continue;
					case 205:
						num4 = 222 - 74;
						num2 = 143;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 12;
							continue;
						}
						continue;
					case 206:
						num3 = 135 - 49;
						num2 = 189;
						continue;
					case 207:
						array[10] = (byte)num3;
						num2 = 270;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 160;
							continue;
						}
						continue;
					case 208:
						num3 = 56 + 14;
						num2 = 315;
						continue;
					case 209:
						array2[6] = (byte)num4;
						num2 = 89;
						continue;
					case 210:
						array[3] = (byte)num3;
						num2 = 0;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 0;
							continue;
						}
						continue;
					case 211:
						array[24] = 105 + 20;
						num2 = 293;
						continue;
					case 212:
						array[6] = 236 - 78;
						num2 = 56;
						continue;
					case 213:
						break;
					case 214:
						array[6] = 69 + 106;
						num2 = 111;
						continue;
					case 215:
						num4 = 195 - 65;
						num2 = 20;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 85;
							continue;
						}
						continue;
					case 216:
						array2[1] = (byte)num4;
						num2 = 119;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 7;
							continue;
						}
						continue;
					case 217:
						num4 = 190 - 63;
						num2 = 216;
						continue;
					case 218:
						num3 = 12 + 96;
						num2 = 249;
						continue;
					case 219:
						array2[0] = 114 + 121;
						num2 = 319;
						continue;
					case 220:
						array2[2] = 156 - 52;
						num2 = 3;
						continue;
					case 221:
						num4 = 184 - 96;
						num2 = 273;
						continue;
					case 222:
						num4 = 129 - 43;
						num2 = 155;
						continue;
					case 223:
						array[12] = 178 + 68;
						num2 = 137;
						continue;
					case 224:
						num3 = 253 - 84;
						num2 = 200;
						continue;
					case 225:
						goto IL_16D5;
					case 226:
						num3 = 4 + 5;
						num2 = 16;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 16;
							continue;
						}
						continue;
					case 227:
						goto IL_1371;
					case 228:
						array[12] = (byte)num3;
						num2 = 311;
						continue;
					case 229:
						array2[14] = 144 - 48;
						num2 = 107;
						continue;
					case 230:
						num4 = 110 + 101;
						num2 = 74;
						continue;
					case 231:
						array[29] = (byte)num3;
						num2 = 186;
						continue;
					case 232:
						num3 = 109 - 0;
						num2 = 80;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 93;
							continue;
						}
						continue;
					case 233:
						num4 = 43 + 35;
						num2 = 306;
						continue;
					case 234:
						num4 = 5 + 87;
						num2 = 282;
						continue;
					case 235:
						array[22] = 109 + 29;
						num2 = 223;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 232;
							continue;
						}
						continue;
					case 236:
						array4[7] = array5[3];
						num2 = 283;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 76;
							continue;
						}
						continue;
					case 237:
						num3 = 107 + 72;
						num2 = 210;
						continue;
					case 238:
						array2[13] = (byte)num4;
						num2 = 130;
						continue;
					case 239:
						num3 = 67 + 17;
						num2 = 296;
						continue;
					case 240:
						array2[12] = (byte)num4;
						num2 = 272;
						continue;
					case 241:
						array2[12] = (byte)num4;
						num2 = 225;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 242;
							continue;
						}
						continue;
					case 242:
						num4 = 99 - 48;
						num2 = 188;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 240;
							continue;
						}
						continue;
					case 243:
						num4 = 98 - 51;
						num2 = 118;
						continue;
					case 244:
						array[29] = 191 - 93;
						num2 = 85;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 260;
							continue;
						}
						continue;
					case 245:
						array[12] = (byte)num3;
						num2 = 223;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 223;
							continue;
						}
						continue;
					case 246:
						array2[9] = 212 - 70;
						num2 = 243;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 116;
							continue;
						}
						continue;
					case 247:
						goto IL_DF3;
					case 248:
						num4 = 134 - 44;
						num2 = 185;
						continue;
					case 249:
						array[25] = (byte)num3;
						num2 = 225;
						continue;
					case 250:
						array[20] = 180 - 63;
						num2 = 294;
						continue;
					case 251:
						array[10] = (byte)num3;
						num2 = 147;
						continue;
					case 252:
						array2[1] = 112 + 7;
						num2 = 327;
						continue;
					case 253:
						num3 = 235 - 78;
						num2 = 156;
						continue;
					case 254:
						array[17] = (byte)num3;
						num2 = 178;
						continue;
					case 255:
						array[9] = 170 - 56;
						num2 = 50;
						continue;
					case 256:
						goto IL_1780;
					case 257:
						array[4] = 125 - 41;
						num2 = 65;
						continue;
					case 258:
						num4 = 200 + 15;
						num2 = 113;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 52;
							continue;
						}
						continue;
					case 259:
						array2[14] = (byte)num4;
						num2 = 132;
						continue;
					case 260:
						array[30] = 81 + 42;
						num2 = 60;
						continue;
					case 261:
						num3 = 8 + 123;
						num2 = 228;
						continue;
					case 262:
						goto IL_17FD;
					case 263:
						num3 = 120 + 52;
						num2 = 70;
						continue;
					case 264:
						array[2] = (byte)num3;
						num2 = 313;
						continue;
					case 265:
						array[11] = (byte)num3;
						num2 = 173;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 46;
							continue;
						}
						continue;
					case 266:
						array[15] = 162 - 54;
						num2 = 280;
						continue;
					case 267:
						array2[2] = (byte)num4;
						num2 = 298;
						continue;
					case 268:
						array[0] = (byte)num3;
						num2 = 188;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 99;
							continue;
						}
						continue;
					case 269:
						array[30] = 127 + 54;
						num2 = 43;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 35;
							continue;
						}
						continue;
					case 270:
						array[10] = 128 - 42;
						num2 = 140;
						continue;
					case 271:
						array4[15] = array5[7];
						num2 = 262;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 4;
							continue;
						}
						continue;
					case 272:
						num4 = 51 + 70;
						num2 = 238;
						continue;
					case 273:
						array2[3] = (byte)num4;
						num2 = 172;
						continue;
					case 274:
						array2[2] = (byte)num4;
						num2 = 18;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 38;
							continue;
						}
						continue;
					case 275:
						yyVBrstaZqxEPNHbn5C.jOJsLI2b6R7ivqBQK3b(array4);
						num2 = 100;
						continue;
					case 276:
						array[28] = 103 + 55;
						num2 = 108;
						continue;
					case 277:
						array[5] = (byte)num3;
						num2 = 34;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 120;
							continue;
						}
						continue;
					case 278:
						array2[2] = (byte)num4;
						num2 = 220;
						continue;
					case 279:
						array2[4] = (byte)num4;
						num2 = 96;
						continue;
					case 280:
						array[15] = 15 + 69;
						num2 = 291;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 47;
							continue;
						}
						continue;
					case 281:
						array2[11] = 160 - 53;
						num2 = 17;
						continue;
					case 282:
						array2[7] = (byte)num4;
						num2 = 285;
						continue;
					case 283:
						array4[9] = array5[4];
						num2 = 330;
						continue;
					case 284:
						goto IL_2B35;
					case 285:
						num4 = 92 + 117;
						num2 = 128;
						continue;
					case 286:
						if (array5.Length == 0)
						{
							num2 = 88;
							continue;
						}
						goto IL_1371;
					case 287:
						array[18] = (byte)num3;
						num2 = 72;
						continue;
					case 288:
						array[19] = (byte)num3;
						num2 = 19;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 21;
							continue;
						}
						continue;
					case 289:
						array2[5] = 194 - 103;
						num2 = 100;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 205;
							continue;
						}
						continue;
					case 290:
						num3 = 26 + 92;
						num2 = 264;
						continue;
					case 291:
						array[15] = 217 + 35;
						num2 = 226;
						continue;
					case 292:
						goto IL_15C5;
					case 293:
						num3 = 217 - 72;
						num2 = 82;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 26;
							continue;
						}
						continue;
					case 294:
						array[21] = 248 - 82;
						num2 = 68;
						continue;
					case 295:
						array[1] = (byte)num3;
						num2 = 162;
						continue;
					case 296:
						array[9] = (byte)num3;
						num2 = 6;
						continue;
					case 297:
						num3 = 130 - 43;
						num2 = 31;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 21;
							continue;
						}
						continue;
					case 298:
						array2[2] = 166 - 55;
						num2 = 81;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 46;
							continue;
						}
						continue;
					case 299:
						array[6] = 32 + 94;
						num2 = 214;
						continue;
					case 300:
						num3 = 93 + 112;
						num2 = 208;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 268;
							continue;
						}
						continue;
					case 301:
						goto IL_25C1;
					case 302:
						array[16] = 3 - 1;
						num2 = 39;
						continue;
					case 303:
						goto IL_CB9;
					case 304:
						num3 = 241 - 80;
						num2 = 33;
						continue;
					case 305:
						array4[3] = array5[1];
						num2 = 193;
						continue;
					case 306:
						goto IL_839;
					case 307:
						num3 = 217 - 72;
						num2 = 94;
						continue;
					case 308:
						array2[13] = 58 + 83;
						num2 = 12;
						continue;
					case 309:
						array[12] = 145 - 48;
						num2 = 58;
						continue;
					case 310:
						num3 = 33 + 36;
						num2 = 145;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 138;
							continue;
						}
						continue;
					case 311:
						num3 = 70 + 36;
						num2 = 8;
						continue;
					case 312:
						array[1] = 156 - 52;
						num2 = 0;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 1;
							continue;
						}
						continue;
					case 313:
						array[2] = 211 - 70;
						num2 = 151;
						continue;
					case 314:
						num3 = 102 + 69;
						num2 = 2;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 2;
							continue;
						}
						continue;
					case 315:
						goto IL_1535;
					case 316:
						array[4] = 71 + 61;
						num2 = 257;
						continue;
					case 317:
						goto IL_289B;
					case 318:
						array[24] = (byte)num3;
						num2 = 304;
						continue;
					case 319:
						array2[0] = 122 + 34;
						num2 = 117;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 114;
							continue;
						}
						continue;
					case 320:
						num3 = 240 - 80;
						num2 = 166;
						continue;
					case 321:
						array2[12] = 251 - 83;
						num2 = 59;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
						{
							num2 = 87;
							continue;
						}
						continue;
					case 322:
						array2[1] = 47 - 7;
						num2 = 11;
						continue;
					case 323:
						array[27] = (byte)num3;
						num2 = 125;
						if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
						{
							num2 = 90;
							continue;
						}
						continue;
					case 324:
						goto IL_1B0F;
					case 325:
						num4 = 135 - 45;
						num2 = 209;
						continue;
					case 326:
						array2[4] = (byte)num4;
						num2 = 11;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 15;
							continue;
						}
						continue;
					case 327:
						num4 = 55 + 11;
						num2 = 126;
						if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 29;
							continue;
						}
						continue;
					case 328:
						array2[12] = (byte)num4;
						num2 = 4;
						if (yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
						{
							num2 = 144;
							continue;
						}
						continue;
					case 329:
						array[4] = (byte)num3;
						num2 = 316;
						continue;
					case 330:
						array4[11] = array5[5];
						num2 = 61;
						continue;
					case 331:
						array[27] = 63 + 118;
						num2 = 95;
						continue;
					case 332:
						array2[3] = (byte)num4;
						num2 = 25;
						continue;
					default:
						goto IL_2394;
					}
					new yyVBrstaZqxEPNHbn5C().ff6c1CBxk2(array6, array4, array3);
					num2 = 40;
					continue;
					IL_90B:
					array6[num5] ^= array4[num5];
					num2 = 27;
					if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
					{
						num2 = 25;
						continue;
					}
					continue;
					IL_1371:
					array4[1] = array5[0];
					num2 = 31;
					if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() == null)
					{
						num2 = 305;
						continue;
					}
					continue;
					IL_1579:
					yyVBrstaZqxEPNHbn5C.zoZc3ePHTK = 80;
					num2 = 116;
					continue;
					IL_1894:
					if (yyVBrstaZqxEPNHbn5C.HwsgoL2Sdjd24jys481(yyVBrstaZqxEPNHbn5C.bgt7pl2CZZML2AHYunm(yyVBrstaZqxEPNHbn5C.KwAcEu78rH), null))
					{
						goto IL_1579;
					}
					num2 = 213;
					if (yyVBrstaZqxEPNHbn5C.wFbn7yKapKMU7WDUwnP() != null)
					{
						num2 = 23;
						continue;
					}
					continue;
					IL_2B35:
					if (\u0020 != -1)
					{
						goto IL_1894;
					}
					num2 = 106;
					if (!yyVBrstaZqxEPNHbn5C.sDpa5tKRvepKx5SNwnl())
					{
						num2 = 103;
						continue;
					}
					continue;
					IL_1780:
					if (num5 < array4.Length)
					{
						num2 = 180;
						continue;
					}
					goto IL_2B35;
					IL_17FD:
					num5 = 0;
					num2 = 112;
					continue;
					IL_2394:
					array[3] = 93 + 105;
					num2 = 208;
				}
				IL_69F:
				array[13] = (byte)num3;
				num = 9;
				continue;
				IL_6EC:
				array[21] = 109 + 46;
				num = 4;
				continue;
				IL_70F:
				array2[3] = 4 + 78;
				num = 221;
				continue;
				IL_839:
				array2[14] = (byte)num4;
				num = 184;
				continue;
				IL_8BD:
				array[17] = (byte)num3;
				num = 102;
				continue;
				IL_A13:
				array[30] = (byte)num3;
				num = 179;
				continue;
				IL_A86:
				array5 = yyVBrstaZqxEPNHbn5C.EdjIIF2xNJ4mKrmZsAG(yyVBrstaZqxEPNHbn5C.rAsQag2JpVAJ0bUJP3o(yyVBrstaZqxEPNHbn5C.KwAcEu78rH));
				num = 194;
				continue;
				IL_CB9:
				num4 = 182 + 54;
				num = 301;
				continue;
				IL_DF3:
				array2[6] = (byte)num4;
				num = 325;
				continue;
				IL_F08:
				array[4] = 144 - 62;
				num = 177;
				continue;
				IL_11C4:
				array[17] = (byte)num3;
				num = 307;
				continue;
				IL_121E:
				num3 = 127 - 42;
				num = 20;
				continue;
				IL_1512:
				array[5] = 134 - 44;
				num = 79;
				continue;
				IL_1535:
				array[3] = (byte)num3;
				num = 187;
				continue;
				IL_158A:
				array[6] = (byte)num3;
				num = 212;
				continue;
				IL_15C5:
				array2[11] = 90 + 79;
				num = 324;
				continue;
				IL_16D5:
				array[25] = 175 - 73;
				num = 297;
				continue;
				IL_180A:
				array2[8] = 122 + 65;
				num = 199;
				continue;
				IL_18C3:
				num3 = 177 + 13;
				num = 150;
				continue;
				IL_1B0F:
				num4 = 198 - 66;
				num = 328;
				continue;
				IL_1B2C:
				array[30] = 71 + 96;
				num = 201;
				continue;
				IL_1C96:
				array[31] = 11 + 112;
				num = 55;
				continue;
				IL_1CEA:
				array2[5] = 182 - 60;
				num = 289;
				continue;
				IL_2342:
				array2[10] = 201 - 67;
				num = 76;
				continue;
				IL_241D:
				num4 = 30 + 21;
				num = 247;
				continue;
				IL_252C:
				array2[15] = (byte)num4;
				num = 46;
				continue;
				IL_25C1:
				array2[15] = (byte)num4;
				num = 101;
				continue;
				IL_289B:
				array[19] = 38 + 90;
				num = 142;
				continue;
				IL_297D:
				array2[0] = 104 + 100;
				num = 217;
				continue;
				IL_2C42:
				num4 = 96 + 76;
				num = 47;
				continue;
				IL_2D3F:
				array2[10] = 173 - 57;
				num = 105;
			}
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x00031908 File Offset: 0x0002FB08
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static string nEjcKVF6rd(int \u0020)
		{
			if (yyVBrstaZqxEPNHbn5C.kIlcaXkDo5.Length == 0)
			{
				yyVBrstaZqxEPNHbn5C.xpYcI36CGF = new List<string>();
				yyVBrstaZqxEPNHbn5C.WO4cRVDiFj = new List<int>();
				yyVBrstaZqxEPNHbn5C.kkmcmydgSK(yyVBrstaZqxEPNHbn5C.KwAcEu78rH.GetManifestResourceStream("drRsbjhFwYPLTfx3Fa.rPLtayk57nTLPUvLPS"), \u0020);
			}
			if (yyVBrstaZqxEPNHbn5C.zoZc3ePHTK < 75)
			{
				MethodBase method = new StackFrame(1).GetMethod();
				if (yyVBrstaZqxEPNHbn5C.KwAcEu78rH != method.DeclaringType.Assembly)
				{
					bool flag = false;
					string name = method.DeclaringType.Assembly.GetName().Name;
					foreach (AssemblyName assemblyName in yyVBrstaZqxEPNHbn5C.KwAcEu78rH.GetReferencedAssemblies())
					{
						if (name == assemblyName.Name)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						throw new Exception();
					}
				}
				yyVBrstaZqxEPNHbn5C.zoZc3ePHTK++;
			}
			object y92cLIjNTp = yyVBrstaZqxEPNHbn5C.Y92cLIjNTp;
			lock (y92cLIjNTp)
			{
				int num = BitConverter.ToInt32(yyVBrstaZqxEPNHbn5C.kIlcaXkDo5, \u0020);
				if (num < yyVBrstaZqxEPNHbn5C.WO4cRVDiFj.Count && yyVBrstaZqxEPNHbn5C.WO4cRVDiFj[num] == \u0020)
				{
					return yyVBrstaZqxEPNHbn5C.xpYcI36CGF[num];
				}
				try
				{
					NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
					byte[] array = new byte[num];
					Array.Copy(yyVBrstaZqxEPNHbn5C.kIlcaXkDo5, \u0020 + 4, array, 0, num);
					string @string = Encoding.Unicode.GetString(array, 0, array.Length);
					yyVBrstaZqxEPNHbn5C.xpYcI36CGF.Add(@string);
					yyVBrstaZqxEPNHbn5C.WO4cRVDiFj.Add(\u0020);
					Array.Copy(BitConverter.GetBytes(yyVBrstaZqxEPNHbn5C.xpYcI36CGF.Count - 1), 0, yyVBrstaZqxEPNHbn5C.kIlcaXkDo5, \u0020, 4);
					return @string;
				}
				catch
				{
				}
			}
			return "";
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x00031AF0 File Offset: 0x0002FCF0
		internal static string Tkic22RUV7(string \u0020)
		{
			"djc6kkemFC4zfrhkyoRI".Trim();
			byte[] array = Convert.FromBase64String(\u0020);
			return Encoding.Unicode.GetString(array, 0, array.Length);
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x00031B20 File Offset: 0x0002FD20
		private static int yj4cr4rvYX()
		{
			return 5;
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x00031B24 File Offset: 0x0002FD24
		private static void iJScNTaLkj()
		{
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x00031B54 File Offset: 0x0002FD54
		private static Delegate vB8cs7V5uC(IntPtr \u0020, Type \u0020)
		{
			return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[]
			{
				typeof(IntPtr),
				typeof(Type)
			}).Invoke(null, new object[]
			{
				\u0020,
				\u0020
			});
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x00031BB4 File Offset: 0x0002FDB4
		internal static object kV9cHc7lFR(object \u0020)
		{
			try
			{
				if (File.Exists(((Assembly)\u0020).Location))
				{
					return ((Assembly)\u0020).Location;
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(((Assembly)\u0020).GetName().CodeBase.ToString().Replace("file:///", "")))
				{
					return ((Assembly)\u0020).GetName().CodeBase.ToString().Replace("file:///", "");
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(\u0020.GetType().GetProperty("Location").GetValue(\u0020, new object[0]).ToString()))
				{
					return \u0020.GetType().GetProperty("Location").GetValue(\u0020, new object[0]).ToString();
				}
			}
			catch
			{
			}
			return "";
		}

		// Token: 0x06000498 RID: 1176
		[DllImport("kernel32", EntryPoint = "LoadLibrary")]
		public static extern IntPtr dUOc4RogRt(string \u0020);

		// Token: 0x06000499 RID: 1177
		[DllImport("kernel32", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress")]
		public static extern IntPtr NvkcGSyOhh(IntPtr \u0020, string \u0020);

		// Token: 0x0600049A RID: 1178 RVA: 0x00031CE4 File Offset: 0x0002FEE4
		private static IntPtr ptQcTkIOeE(IntPtr \u0020, string \u0020, uint \u0020)
		{
			if (yyVBrstaZqxEPNHbn5C.YwummnZKMS == null)
			{
				yyVBrstaZqxEPNHbn5C.YwummnZKMS = (yyVBrstaZqxEPNHbn5C.RovhC5mOLBIYKy9NRco)Marshal.GetDelegateForFunctionPointer(yyVBrstaZqxEPNHbn5C.NvkcGSyOhh(yyVBrstaZqxEPNHbn5C.F6BhDkqRs(), "Find ".Trim() + "ResourceA"), typeof(yyVBrstaZqxEPNHbn5C.RovhC5mOLBIYKy9NRco));
			}
			return yyVBrstaZqxEPNHbn5C.YwummnZKMS(\u0020, \u0020, \u0020);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x00031D40 File Offset: 0x0002FF40
		private static IntPtr osQcBPObu3(IntPtr \u0020, uint \u0020, uint \u0020, uint \u0020)
		{
			if (yyVBrstaZqxEPNHbn5C.e93mK8HDSw == null)
			{
				yyVBrstaZqxEPNHbn5C.e93mK8HDSw = (yyVBrstaZqxEPNHbn5C.MQxiDVmfPReIdXYAX0C)Marshal.GetDelegateForFunctionPointer(yyVBrstaZqxEPNHbn5C.NvkcGSyOhh(yyVBrstaZqxEPNHbn5C.F6BhDkqRs(), "Virtual ".Trim() + "Alloc"), typeof(yyVBrstaZqxEPNHbn5C.MQxiDVmfPReIdXYAX0C));
			}
			return yyVBrstaZqxEPNHbn5C.e93mK8HDSw(\u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00031D9C File Offset: 0x0002FF9C
		private static int nvbcqumX2t(IntPtr \u0020, IntPtr \u0020, [In] [Out] byte[] \u0020, uint \u0020, out IntPtr \u0020)
		{
			if (yyVBrstaZqxEPNHbn5C.X30m2agtVR == null)
			{
				yyVBrstaZqxEPNHbn5C.X30m2agtVR = (yyVBrstaZqxEPNHbn5C.vF6LKumio4k77aXj3CL)Marshal.GetDelegateForFunctionPointer(yyVBrstaZqxEPNHbn5C.NvkcGSyOhh(yyVBrstaZqxEPNHbn5C.F6BhDkqRs(), "Write ".Trim() + "Process ".Trim() + "Memory"), typeof(yyVBrstaZqxEPNHbn5C.vF6LKumio4k77aXj3CL));
			}
			return yyVBrstaZqxEPNHbn5C.X30m2agtVR(\u0020, \u0020, \u0020, \u0020, out \u0020);
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x00031E04 File Offset: 0x00030004
		private static int MlVc7EZ6EQ(IntPtr \u0020, int \u0020, int \u0020, ref int \u0020)
		{
			if (yyVBrstaZqxEPNHbn5C.fB3mrWuR3b == null)
			{
				yyVBrstaZqxEPNHbn5C.fB3mrWuR3b = (yyVBrstaZqxEPNHbn5C.jbyKqgmU3D3GRHUQJtX)Marshal.GetDelegateForFunctionPointer(yyVBrstaZqxEPNHbn5C.NvkcGSyOhh(yyVBrstaZqxEPNHbn5C.F6BhDkqRs(), "Virtual ".Trim() + "Protect"), typeof(yyVBrstaZqxEPNHbn5C.jbyKqgmU3D3GRHUQJtX));
			}
			return yyVBrstaZqxEPNHbn5C.fB3mrWuR3b(\u0020, \u0020, \u0020, ref \u0020);
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x00031E60 File Offset: 0x00030060
		private static IntPtr pyncAeaW52(uint \u0020, int \u0020, uint \u0020)
		{
			if (yyVBrstaZqxEPNHbn5C.oWsmN0o9vZ == null)
			{
				yyVBrstaZqxEPNHbn5C.oWsmN0o9vZ = (yyVBrstaZqxEPNHbn5C.i86nB2mu0prWMMjZsM7)Marshal.GetDelegateForFunctionPointer(yyVBrstaZqxEPNHbn5C.NvkcGSyOhh(yyVBrstaZqxEPNHbn5C.F6BhDkqRs(), "Open ".Trim() + "Process"), typeof(yyVBrstaZqxEPNHbn5C.i86nB2mu0prWMMjZsM7));
			}
			return yyVBrstaZqxEPNHbn5C.oWsmN0o9vZ(\u0020, \u0020, \u0020);
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x00031EBC File Offset: 0x000300BC
		private static int fFDcPOk7aF(IntPtr \u0020)
		{
			if (yyVBrstaZqxEPNHbn5C.bFpmsy2KaX == null)
			{
				yyVBrstaZqxEPNHbn5C.bFpmsy2KaX = (yyVBrstaZqxEPNHbn5C.sDuaHImvSR7Iho0kL9x)Marshal.GetDelegateForFunctionPointer(yyVBrstaZqxEPNHbn5C.NvkcGSyOhh(yyVBrstaZqxEPNHbn5C.F6BhDkqRs(), "Close ".Trim() + "Handle"), typeof(yyVBrstaZqxEPNHbn5C.sDuaHImvSR7Iho0kL9x));
			}
			return yyVBrstaZqxEPNHbn5C.bFpmsy2KaX(\u0020);
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x00031F18 File Offset: 0x00030118
		private static IntPtr F6BhDkqRs()
		{
			if (yyVBrstaZqxEPNHbn5C.JGHmHuoe0X == IntPtr.Zero)
			{
				yyVBrstaZqxEPNHbn5C.JGHmHuoe0X = yyVBrstaZqxEPNHbn5C.dUOc4RogRt("kernel ".Trim() + "32.dll");
			}
			return yyVBrstaZqxEPNHbn5C.JGHmHuoe0X;
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x00031F54 File Offset: 0x00030154
		private static byte[] neVcoCGIQC(string \u0020)
		{
			byte[] array;
			using (FileStream fileStream = new FileStream(\u0020, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				int num = 0;
				int i = (int)fileStream.Length;
				array = new byte[i];
				while (i > 0)
				{
					int num2 = fileStream.Read(array, num, i);
					num += num2;
					i -= num2;
				}
			}
			return array;
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x00031FC0 File Offset: 0x000301C0
		internal static Stream khFc9XDIVm()
		{
			return new MemoryStream();
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x00031FC8 File Offset: 0x000301C8
		internal static byte[] IP0cQrQE6S(Stream \u0020)
		{
			return ((MemoryStream)\u0020).ToArray();
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00031FD8 File Offset: 0x000301D8
		private static byte[] VwGcgPcLar(byte[] \u0020)
		{
			Stream stream = yyVBrstaZqxEPNHbn5C.khFc9XDIVm();
			SymmetricAlgorithm symmetricAlgorithm = yyVBrstaZqxEPNHbn5C.WrMc0geB2w();
			symmetricAlgorithm.Key = new byte[]
			{
				159,
				119,
				250,
				142,
				59,
				137,
				210,
				38,
				44,
				43,
				162,
				187,
				179,
				74,
				209,
				58,
				57,
				31,
				53,
				163,
				92,
				180,
				15,
				175,
				203,
				75,
				208,
				55,
				151,
				204,
				231,
				104
			};
			symmetricAlgorithm.IV = new byte[]
			{
				229,
				95,
				209,
				171,
				55,
				183,
				15,
				33,
				110,
				68,
				0,
				75,
				161,
				84,
				245,
				112
			};
			CryptoStream cryptoStream = new CryptoStream(stream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
			cryptoStream.Write(\u0020, 0, \u0020.Length);
			cryptoStream.Close();
			byte[] result = yyVBrstaZqxEPNHbn5C.IP0cQrQE6S(stream);
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			return result;
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0003204C File Offset: 0x0003024C
		private byte[] pXEcYcw8mN()
		{
			return null;
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x0003205C File Offset: 0x0003025C
		private byte[] abFclCeg4q()
		{
			return null;
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x0003206C File Offset: 0x0003026C
		private byte[] jhTcV8AbVr()
		{
			int length = "IGIjaDPoV2x50V2F".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x0003208C File Offset: 0x0003028C
		private byte[] fIrcDi9Onu()
		{
			int length = "w1eIx54qhVpsY6u".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x000320AC File Offset: 0x000302AC
		private byte[] BcQc6llf8S()
		{
			int length = "LN33rk665D9YcXkaA".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x000320CC File Offset: 0x000302CC
		private byte[] xsUcOBpdBL()
		{
			int length = "QfiguokentM53gZ".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x000320EC File Offset: 0x000302EC
		internal byte[] oAMcfvVE7e()
		{
			int length = "wocOSN7MtAKc84DSsG7".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x0003210C File Offset: 0x0003030C
		internal byte[] cGWcid5Jtj()
		{
			int length = "zODokBF7Vb3GX2vpyck2".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x0003212C File Offset: 0x0003032C
		internal byte[] dSfcU116iB()
		{
			return null;
		}

		// Token: 0x060004AE RID: 1198 RVA: 0x0003213C File Offset: 0x0003033C
		internal byte[] sC0cuOVeBy()
		{
			return null;
		}

		// Token: 0x060004AF RID: 1199 RVA: 0x0003214C File Offset: 0x0003034C
		internal static object tNPGhDKza9257vceh2t(object A_0)
		{
			return A_0.vh0ry9Sq2v();
		}

		// Token: 0x060004B0 RID: 1200 RVA: 0x00032158 File Offset: 0x00030358
		internal static void mOaosD28oyTM2eW7JC1(object A_0, long A_1)
		{
			A_0.Position = A_1;
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x00032168 File Offset: 0x00030368
		internal static long BI4VFF2hyCKmWGmphd2(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x00032174 File Offset: 0x00030374
		internal static object yNRN8w2kXs6e54HhoYp(object A_0, int \u0020)
		{
			return A_0.tOsmYdnGw3(\u0020);
		}

		// Token: 0x060004B3 RID: 1203 RVA: 0x00032184 File Offset: 0x00030384
		internal static void cRPRnj2woc0K4YOESd8(object A_0)
		{
			A_0.eBCmDZug2e();
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x00032190 File Offset: 0x00030390
		internal static void jOJsLI2b6R7ivqBQK3b(object A_0)
		{
			Array.Reverse(A_0);
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0003219C File Offset: 0x0003039C
		internal static object rAsQag2JpVAJ0bUJP3o(object A_0)
		{
			return A_0.GetName();
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x000321A8 File Offset: 0x000303A8
		internal static object EdjIIF2xNJ4mKrmZsAG(object A_0)
		{
			return A_0.GetPublicKeyToken();
		}

		// Token: 0x060004B7 RID: 1207 RVA: 0x000321B4 File Offset: 0x000303B4
		internal static object e0F4UI210lo7XeDNwgc()
		{
			return yyVBrstaZqxEPNHbn5C.WrMc0geB2w();
		}

		// Token: 0x060004B8 RID: 1208 RVA: 0x000321BC File Offset: 0x000303BC
		internal static void HdYneq200c4awElfuZG(object A_0, CipherMode A_1)
		{
			A_0.Mode = A_1;
		}

		// Token: 0x060004B9 RID: 1209 RVA: 0x000321CC File Offset: 0x000303CC
		internal static object gxMujP2XlXQiNX1F8Se(object A_0, object A_1, object A_2)
		{
			return A_0.CreateDecryptor(A_1, A_2);
		}

		// Token: 0x060004BA RID: 1210 RVA: 0x000321E0 File Offset: 0x000303E0
		internal static object gsOZwG2j9jObMpYRCxg()
		{
			return yyVBrstaZqxEPNHbn5C.khFc9XDIVm();
		}

		// Token: 0x060004BB RID: 1211 RVA: 0x000321E8 File Offset: 0x000303E8
		internal static void aH3krl25yq5HEWCPdfL(object A_0, object A_1, int A_2, int A_3)
		{
			A_0.Write(A_1, A_2, A_3);
		}

		// Token: 0x060004BC RID: 1212 RVA: 0x00032200 File Offset: 0x00030400
		internal static void rBX8FM2ymd2JWCh1BFT(object A_0)
		{
			A_0.FlushFinalBlock();
		}

		// Token: 0x060004BD RID: 1213 RVA: 0x0003220C File Offset: 0x0003040C
		internal static object egvayX2ZTP05HTX02Vm(object A_0)
		{
			return yyVBrstaZqxEPNHbn5C.IP0cQrQE6S(A_0);
		}

		// Token: 0x060004BE RID: 1214 RVA: 0x00032218 File Offset: 0x00030418
		internal static void bVZ7tL2MIEIev1h1N2e(object A_0)
		{
			A_0.Close();
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x00032224 File Offset: 0x00030424
		internal static object bgt7pl2CZZML2AHYunm(object A_0)
		{
			return A_0.EntryPoint;
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x00032230 File Offset: 0x00030430
		internal static bool HwsgoL2Sdjd24jys481(object A_0, object A_1)
		{
			return A_0 == A_1;
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x00032240 File Offset: 0x00030440
		internal static bool sDpa5tKRvepKx5SNwnl()
		{
			return null == null;
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x00032248 File Offset: 0x00030448
		internal static object wFbn7yKapKMU7WDUwnP()
		{
			return null;
		}

		// Token: 0x040003FF RID: 1023
		private static uint[] NJJcpnqrI3;

		// Token: 0x04000400 RID: 1024
		private static bool lfjcdQBE7R;

		// Token: 0x04000401 RID: 1025
		private static object AwUcnVYrkv;

		// Token: 0x04000402 RID: 1026
		private static int zoZc3ePHTK;

		// Token: 0x04000403 RID: 1027
		private static List<int> WO4cRVDiFj;

		// Token: 0x04000404 RID: 1028
		private static byte[] kIlcaXkDo5;

		// Token: 0x04000405 RID: 1029
		private static int[] kaXmwCGWl1;

		// Token: 0x04000406 RID: 1030
		private static SortedList gu4mxLc34w;

		// Token: 0x04000407 RID: 1031
		private static int AAom1riiMD;

		// Token: 0x04000408 RID: 1032
		internal static yyVBrstaZqxEPNHbn5C.aoYJGTmACLWiSQqBFgq GRmmXUF3Cw;

		// Token: 0x04000409 RID: 1033
		internal static yyVBrstaZqxEPNHbn5C.aoYJGTmACLWiSQqBFgq BmOmjFbnC4;

		// Token: 0x0400040A RID: 1034
		private static bool RDCmMjhDeI;

		// Token: 0x0400040B RID: 1035
		private static IntPtr qnnmSwhXd1;

		// Token: 0x0400040C RID: 1036
		internal static Hashtable Garmc6k3DI;

		// Token: 0x0400040D RID: 1037
		private static yyVBrstaZqxEPNHbn5C.MQxiDVmfPReIdXYAX0C e93mK8HDSw;

		// Token: 0x0400040E RID: 1038
		private static yyVBrstaZqxEPNHbn5C.jbyKqgmU3D3GRHUQJtX fB3mrWuR3b;

		// Token: 0x0400040F RID: 1039
		private static yyVBrstaZqxEPNHbn5C.i86nB2mu0prWMMjZsM7 oWsmN0o9vZ;

		// Token: 0x04000410 RID: 1040
		private static yyVBrstaZqxEPNHbn5C.sDuaHImvSR7Iho0kL9x bFpmsy2KaX;

		// Token: 0x04000411 RID: 1041
		private static bool r9RcFG2wYm;

		// Token: 0x04000412 RID: 1042
		[yyVBrstaZqxEPNHbn5C.Gd9ktTmGlr6PkWKR3gS(typeof(yyVBrstaZqxEPNHbn5C.Gd9ktTmGlr6PkWKR3gS.pQS9KhmTnUYG1p0DSYX<object>[]))]
		private static bool kKAmtIRglY;

		// Token: 0x04000413 RID: 1043
		private static Dictionary<int, int> bRuceGMPSP;

		// Token: 0x04000414 RID: 1044
		private static long q85m5cJlFU;

		// Token: 0x04000415 RID: 1045
		private static yyVBrstaZqxEPNHbn5C.RovhC5mOLBIYKy9NRco YwummnZKMS;

		// Token: 0x04000416 RID: 1046
		private static bool C61cvR2qKt = false;

		// Token: 0x04000417 RID: 1047
		private static object Rq0mkBLmHb;

		// Token: 0x04000418 RID: 1048
		internal static RSACryptoServiceProvider FMCcW9IUJ4;

		// Token: 0x04000419 RID: 1049
		private static long Oq9m08NeoQ;

		// Token: 0x0400041A RID: 1050
		private static IntPtr JGHmHuoe0X;

		// Token: 0x0400041B RID: 1051
		private static bool nNvmJXatcK;

		// Token: 0x0400041C RID: 1052
		private static int zVhmbS9Lig;

		// Token: 0x0400041D RID: 1053
		private static IntPtr W6ym8PjvYr;

		// Token: 0x0400041E RID: 1054
		private static byte[] ohncz9H3bn;

		// Token: 0x0400041F RID: 1055
		private static int pj3mye07i6;

		// Token: 0x04000420 RID: 1056
		private static bool bd8mZJRG7T;

		// Token: 0x04000421 RID: 1057
		private static yyVBrstaZqxEPNHbn5C.vF6LKumio4k77aXj3CL X30m2agtVR;

		// Token: 0x04000422 RID: 1058
		private static IntPtr l4Rmh5RuEH;

		// Token: 0x04000423 RID: 1059
		internal static Assembly KwAcEu78rH = typeof(yyVBrstaZqxEPNHbn5C).Assembly;

		// Token: 0x04000424 RID: 1060
		private static object Y92cLIjNTp;

		// Token: 0x04000425 RID: 1061
		private static List<string> xpYcI36CGF;

		// Token: 0x04000426 RID: 1062
		private static int plGmCGaGGP;

		// Token: 0x020000E3 RID: 227
		// (Invoke) Token: 0x060004C4 RID: 1220
		private delegate void gMffLCm4HXLe2DADd9w(object o);

		// Token: 0x020000E4 RID: 228
		internal class Gd9ktTmGlr6PkWKR3gS : Attribute
		{
			// Token: 0x060004C7 RID: 1223 RVA: 0x0003224C File Offset: 0x0003044C
			public Gd9ktTmGlr6PkWKR3gS(object \u0020)
			{
			}

			// Token: 0x020000E5 RID: 229
			internal class pQS9KhmTnUYG1p0DSYX<vJO9PImBhIUPwnwjh1y>
			{
				// Token: 0x060004C8 RID: 1224 RVA: 0x00032254 File Offset: 0x00030454
				public pQS9KhmTnUYG1p0DSYX()
				{
					yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
					NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
					base..ctor();
				}
			}
		}

		// Token: 0x020000E6 RID: 230
		internal class i7cTjdmqEUXSDr1OX4F
		{
			// Token: 0x060004C9 RID: 1225 RVA: 0x00032268 File Offset: 0x00030468
			internal static string aRXm7aU8qs(string \u0020, string \u0020)
			{
				byte[] bytes = Encoding.Unicode.GetBytes(\u0020);
				byte[] key = new byte[]
				{
					82,
					102,
					104,
					110,
					32,
					77,
					24,
					34,
					118,
					181,
					51,
					17,
					18,
					51,
					12,
					109,
					10,
					32,
					77,
					24,
					34,
					158,
					161,
					41,
					97,
					28,
					118,
					181,
					5,
					25,
					1,
					88
				};
				byte[] iv = yyVBrstaZqxEPNHbn5C.wwccjpAgAx(Encoding.Unicode.GetBytes(\u0020));
				MemoryStream memoryStream = new MemoryStream();
				SymmetricAlgorithm symmetricAlgorithm = yyVBrstaZqxEPNHbn5C.WrMc0geB2w();
				symmetricAlgorithm.Key = key;
				symmetricAlgorithm.IV = iv;
				CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
				cryptoStream.Write(bytes, 0, bytes.Length);
				cryptoStream.Close();
				return Convert.ToBase64String(memoryStream.ToArray());
			}
		}

		// Token: 0x020000E7 RID: 231
		// (Invoke) Token: 0x060004CC RID: 1228
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		internal delegate uint aoYJGTmACLWiSQqBFgq(IntPtr classthis, IntPtr comp, IntPtr info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

		// Token: 0x020000E8 RID: 232
		// (Invoke) Token: 0x060004D0 RID: 1232
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr HY39N2mPwOnXVAR6P3K();

		// Token: 0x020000E9 RID: 233
		internal struct S8yUpnmoMe9w7vIhvvU
		{
			// Token: 0x04000427 RID: 1063
			internal bool Yl3m9j4isV;

			// Token: 0x04000428 RID: 1064
			internal byte[] VmRmQdXxWw;
		}

		// Token: 0x020000EA RID: 234
		internal class JeCFqRmg7B63R4bEDl8
		{
			// Token: 0x060004D3 RID: 1235 RVA: 0x000322F0 File Offset: 0x000304F0
			public JeCFqRmg7B63R4bEDl8(Stream \u0020)
			{
				this.pVUm6tQClM = new BinaryReader(\u0020);
			}

			// Token: 0x060004D4 RID: 1236 RVA: 0x00032304 File Offset: 0x00030504
			internal Stream vh0ry9Sq2v()
			{
				return this.pVUm6tQClM.BaseStream;
			}

			// Token: 0x060004D5 RID: 1237 RVA: 0x00032314 File Offset: 0x00030514
			internal byte[] tOsmYdnGw3(int \u0020)
			{
				return this.pVUm6tQClM.ReadBytes(\u0020);
			}

			// Token: 0x060004D6 RID: 1238 RVA: 0x00032324 File Offset: 0x00030524
			internal int xWxml0H3GI(byte[] \u0020, int \u0020, int \u0020)
			{
				return this.pVUm6tQClM.Read(\u0020, \u0020, \u0020);
			}

			// Token: 0x060004D7 RID: 1239 RVA: 0x00032334 File Offset: 0x00030534
			internal int Ak7mVtyscl()
			{
				return this.pVUm6tQClM.ReadInt32();
			}

			// Token: 0x060004D8 RID: 1240 RVA: 0x00032344 File Offset: 0x00030544
			internal void eBCmDZug2e()
			{
				this.pVUm6tQClM.Close();
			}

			// Token: 0x04000429 RID: 1065
			private BinaryReader pVUm6tQClM;
		}

		// Token: 0x020000EB RID: 235
		// (Invoke) Token: 0x060004DA RID: 1242
		[UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)]
		private delegate IntPtr RovhC5mOLBIYKy9NRco(IntPtr hModule, string lpName, uint lpType);

		// Token: 0x020000EC RID: 236
		// (Invoke) Token: 0x060004DE RID: 1246
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr MQxiDVmfPReIdXYAX0C(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x020000ED RID: 237
		// (Invoke) Token: 0x060004E2 RID: 1250
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int vF6LKumio4k77aXj3CL(IntPtr hProcess, IntPtr lpBaseAddress, [In] [Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

		// Token: 0x020000EE RID: 238
		// (Invoke) Token: 0x060004E6 RID: 1254
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int jbyKqgmU3D3GRHUQJtX(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);

		// Token: 0x020000EF RID: 239
		// (Invoke) Token: 0x060004EA RID: 1258
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr i86nB2mu0prWMMjZsM7(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

		// Token: 0x020000F0 RID: 240
		// (Invoke) Token: 0x060004EE RID: 1262
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int sDuaHImvSR7Iho0kL9x(IntPtr ptr);

		// Token: 0x020000F1 RID: 241
		[Flags]
		private enum Bmmqk2mELOg9HofGMBk
		{

		}
	}
}
