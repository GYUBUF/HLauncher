﻿namespace gpm15skv4ndlJ0bmJ30
{
	// Token: 0x02000037 RID: 55
	internal partial class yPEIdHku1BhompHOFRp : global::System.Windows.Forms.Form
	{
		// Token: 0x0600013E RID: 318 RVA: 0x00005ED0 File Offset: 0x000040D0
		protected override void Dispose(bool \u0020)
		{
			if (\u0020)
			{
				global::System.Drawing.Bitmap tsxke5FUFD = this.Tsxke5FUFD;
				if (tsxke5FUFD != null)
				{
					tsxke5FUFD.Dispose();
				}
			}
			base.Dispose(\u0020);
		}

		// Token: 0x040000D6 RID: 214
		private global::System.Drawing.Bitmap Tsxke5FUFD;
	}
}
