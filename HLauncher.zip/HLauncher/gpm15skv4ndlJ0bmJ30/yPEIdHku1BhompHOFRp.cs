﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;
using uR6iUfk3GIX55MYPkNT;

namespace gpm15skv4ndlJ0bmJ30
{
	// Token: 0x02000037 RID: 55
	internal partial class yPEIdHku1BhompHOFRp : Form
	{
		// Token: 0x0600013A RID: 314 RVA: 0x00005C20 File Offset: 0x00003E20
		public yPEIdHku1BhompHOFRp(Form \u0020, int \u0020, int \u0020)
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
			this.igSkF6uwk9 = \u0020;
			this.SKvkdr1xeE = \u0020;
			this.Ve3kWaaqpc = \u0020;
			base.Owner = \u0020;
			base.FormBorderStyle = FormBorderStyle.None;
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.Manual;
			this.DoubleBuffered = true;
			base.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.UpdateStyles();
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x0600013B RID: 315 RVA: 0x00005C88 File Offset: 0x00003E88
		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams createParams = base.CreateParams;
				createParams.ExStyle |= 134742048;
				return createParams;
			}
		}

		// Token: 0x0600013C RID: 316 RVA: 0x00005CA4 File Offset: 0x00003EA4
		public void GibkE18f7m()
		{
			if (this.igSkF6uwk9.WindowState == FormWindowState.Normal && this.igSkF6uwk9.Visible)
			{
				base.Location = new Point(this.igSkF6uwk9.Left - this.Ve3kWaaqpc, this.igSkF6uwk9.Top - this.Ve3kWaaqpc);
			}
		}

		// Token: 0x0600013D RID: 317 RVA: 0x00005D00 File Offset: 0x00003F00
		public void AwKkpdv9t2()
		{
			if (this.igSkF6uwk9.Width <= 0 || this.igSkF6uwk9.Height <= 0)
			{
				return;
			}
			int width = this.igSkF6uwk9.Width + this.Ve3kWaaqpc * 2;
			int height = this.igSkF6uwk9.Height + this.Ve3kWaaqpc * 2;
			base.Size = new Size(width, height);
			Bitmap tsxke5FUFD = this.Tsxke5FUFD;
			if (tsxke5FUFD != null)
			{
				tsxke5FUFD.Dispose();
			}
			this.Tsxke5FUFD = new Bitmap(width, height, PixelFormat.Format32bppArgb);
			using (Graphics graphics = Graphics.FromImage(this.Tsxke5FUFD))
			{
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				for (int i = this.Ve3kWaaqpc - 1; i >= 0; i--)
				{
					double num = (double)i / (double)this.Ve3kWaaqpc;
					int num2 = (int)(12.0 * Math.Pow(1.0 - num, 3.5));
					if (num2 > 0)
					{
						int num3 = this.Ve3kWaaqpc - i;
						using (GraphicsPath graphicsPath = U10J3wknhsfdKLH2ygX.TSVwjEEDOA(new Rectangle(num3, num3, this.igSkF6uwk9.Width + i * 2, this.igSkF6uwk9.Height + i * 2), this.SKvkdr1xeE - 8))
						{
							using (Pen pen = new Pen(Color.FromArgb(num2, Color.Black), 2.5f))
							{
								graphics.DrawPath(pen, graphicsPath);
							}
						}
					}
				}
			}
			U10J3wknhsfdKLH2ygX.VRkwXVPq1l(base.Handle, this.Tsxke5FUFD, base.Left, base.Top);
		}

		// Token: 0x040000D3 RID: 211
		private readonly Form igSkF6uwk9;

		// Token: 0x040000D4 RID: 212
		private readonly int SKvkdr1xeE;

		// Token: 0x040000D5 RID: 213
		private readonly int Ve3kWaaqpc;
	}
}
