﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ro2IpYtzntGHp8CGrmT;
using y0ve6F17gu3T12r7mYI;

namespace HLauncher
{
	// Token: 0x0200007E RID: 126
	public static class MessageOverlay
	{
		// Token: 0x0600027C RID: 636 RVA: 0x0000F1E0 File Offset: 0x0000D3E0
		public static void ShowMessage(Form parentForm, string title, string message, string buttonText = "OK", Action onButtonClick = null)
		{
			MessageOverlay.<>c__DisplayClass0_0 CS$<>8__locals1 = new MessageOverlay.<>c__DisplayClass0_0();
			CS$<>8__locals1.VwxZ1B0TRa = onButtonClick;
			CS$<>8__locals1.TG1Z0otvdq = parentForm;
			if (CS$<>8__locals1.TG1Z0otvdq == null || CS$<>8__locals1.TG1Z0otvdq.IsDisposed)
			{
				return;
			}
			int num = 350;
			int num2 = 135;
			CS$<>8__locals1.QhFZXfAxWr = MessageOverlay.OMdJ6dO0xM(CS$<>8__locals1.TG1Z0otvdq, num, num2);
			Label label = MessageOverlay.wdLJOXXyvV(title, 10, 10);
			Label label2 = MessageOverlay.iYBJful3t1(message, 10, 40, num - 20, 40);
			Button button = MessageOverlay.UEmJiJFuxR(buttonText, num - 110, num2 - 40, 100, 30, Color.FromArgb(60, 120, 230));
			button.Click += CS$<>8__locals1.mWnZxx3xQU;
			CS$<>8__locals1.QhFZXfAxWr.Controls.AddRange(new Control[]
			{
				label,
				label2,
				button
			});
			CS$<>8__locals1.TG1Z0otvdq.Controls.Add(CS$<>8__locals1.QhFZXfAxWr);
			CS$<>8__locals1.QhFZXfAxWr.BringToFront();
		}

		// Token: 0x0600027D RID: 637 RVA: 0x0000F2D4 File Offset: 0x0000D4D4
		public static void ShowConfirm(Form parentForm, string title, string message, string confirmText = "Да", string cancelText = "Нет", Action onConfirm = null, Action onCancel = null)
		{
			MessageOverlay.<>c__DisplayClass1_0 CS$<>8__locals1 = new MessageOverlay.<>c__DisplayClass1_0();
			CS$<>8__locals1.UvbZyxMOuP = onConfirm;
			CS$<>8__locals1.rmRZZ2BJK5 = parentForm;
			CS$<>8__locals1.kdkZCvL4Wo = onCancel;
			if (CS$<>8__locals1.rmRZZ2BJK5 == null || CS$<>8__locals1.rmRZZ2BJK5.IsDisposed)
			{
				return;
			}
			int num = 400;
			int num2 = 145;
			CS$<>8__locals1.cbJZMqpKRt = MessageOverlay.OMdJ6dO0xM(CS$<>8__locals1.rmRZZ2BJK5, num, num2);
			Label label = MessageOverlay.wdLJOXXyvV(title, 10, 10);
			Label label2 = MessageOverlay.iYBJful3t1(message, 10, 40, num - 20, 60);
			Button button = MessageOverlay.UEmJiJFuxR(confirmText, num - 215, num2 - 40, 100, 30, Color.FromArgb(60, 120, 230));
			button.Click += CS$<>8__locals1.jHrZjoh3vf;
			Button button2 = MessageOverlay.UEmJiJFuxR(cancelText, num - 110, num2 - 40, 100, 30, Color.FromArgb(70, 70, 70));
			button2.Click += CS$<>8__locals1.w4aZ5VaAsy;
			CS$<>8__locals1.cbJZMqpKRt.Controls.AddRange(new Control[]
			{
				label,
				label2,
				button,
				button2
			});
			CS$<>8__locals1.rmRZZ2BJK5.Controls.Add(CS$<>8__locals1.cbJZMqpKRt);
			CS$<>8__locals1.cbJZMqpKRt.BringToFront();
		}

		// Token: 0x0600027E RID: 638 RVA: 0x0000F40C File Offset: 0x0000D60C
		public static void ShowModInstall(Form parentForm, string title, string message, string actionText = "Установить", string cancelText = "Отмена", Action onAction = null, Action onCancel = null)
		{
			MessageOverlay.<>c__DisplayClass2_0 CS$<>8__locals1 = new MessageOverlay.<>c__DisplayClass2_0();
			CS$<>8__locals1.lJwZcjFmP4 = onAction;
			CS$<>8__locals1.Ha6ZmXRfrK = parentForm;
			CS$<>8__locals1.GV7Z2bHjWE = onCancel;
			if (CS$<>8__locals1.Ha6ZmXRfrK == null || CS$<>8__locals1.Ha6ZmXRfrK.IsDisposed)
			{
				return;
			}
			int num = CS$<>8__locals1.Ha6ZmXRfrK.Width / 2;
			int num2 = 160;
			CS$<>8__locals1.B7ZZKliYMG = MessageOverlay.OMdJ6dO0xM(CS$<>8__locals1.Ha6ZmXRfrK, num, num2);
			Label label = MessageOverlay.wdLJOXXyvV(title, 10, 10);
			Label label2 = MessageOverlay.iYBJful3t1(message, 10, 40, num - 20, 60);
			Button button = MessageOverlay.UEmJiJFuxR(actionText, num - 215, num2 - 45, 100, 30, Color.FromArgb(60, 120, 230));
			button.Click += CS$<>8__locals1.hgPZS0PowZ;
			Button button2 = MessageOverlay.UEmJiJFuxR(cancelText, num - 110, num2 - 45, 100, 30, Color.FromArgb(70, 70, 70));
			button2.Click += CS$<>8__locals1.hCsZtsXeLx;
			CS$<>8__locals1.B7ZZKliYMG.Controls.AddRange(new Control[]
			{
				label,
				label2,
				button,
				button2
			});
			CS$<>8__locals1.Ha6ZmXRfrK.Controls.Add(CS$<>8__locals1.B7ZZKliYMG);
			CS$<>8__locals1.B7ZZKliYMG.BringToFront();
		}

		// Token: 0x0600027F RID: 639 RVA: 0x0000F54C File Offset: 0x0000D74C
		public static void ShowSupportOverlay(Form parentForm, string title, string description, string userIdLabelText, string copyBtnText, string copiedBtnText, string keyLabelText, string activateBtnText, string supportBtnText, string cancelBtnText, Action<string> onKeyActivate, Action onSupportClick)
		{
			MessageOverlay.<>c__DisplayClass3_0 CS$<>8__locals1 = new MessageOverlay.<>c__DisplayClass3_0();
			CS$<>8__locals1.RawZTBCltI = copiedBtnText;
			CS$<>8__locals1.RS3ZBaFKYb = copyBtnText;
			CS$<>8__locals1.eFOZ7AoAR4 = onKeyActivate;
			CS$<>8__locals1.UcMZAqiHN2 = onSupportClick;
			CS$<>8__locals1.KvlZPB7SgJ = parentForm;
			if (CS$<>8__locals1.KvlZPB7SgJ == null || CS$<>8__locals1.KvlZPB7SgJ.IsDisposed)
			{
				return;
			}
			int num = 420;
			int num2 = 220;
			CS$<>8__locals1.aGnZo8Jo9Y = MessageOverlay.OMdJ6dO0xM(CS$<>8__locals1.KvlZPB7SgJ, num, num2);
			Label label = MessageOverlay.wdLJOXXyvV(title, 15, 15);
			Label label2 = MessageOverlay.iYBJful3t1(description, 15, 45, num - 30, 30);
			CS$<>8__locals1.i5cZ47UxN3 = License.GetUserId();
			Label label3 = MessageOverlay.iYBJful3t1(userIdLabelText + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -219228001 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967) + CS$<>8__locals1.i5cZ47UxN3, 15, 80, num - 130, 20);
			label3.ForeColor = Color.CadetBlue;
			CS$<>8__locals1.FZOZGit30y = MessageOverlay.UEmJiJFuxR(CS$<>8__locals1.RS3ZBaFKYb, num - 115, 77, 100, 22, Color.FromArgb(80, 80, 80));
			CS$<>8__locals1.FZOZGit30y.Font = StyleManager.GetMainFont(7.5f);
			CS$<>8__locals1.FZOZGit30y.Click += CS$<>8__locals1.TqxZrw2LXk;
			Label label4 = MessageOverlay.iYBJful3t1(keyLabelText, 15, 110, num - 40, 20);
			label4.ForeColor = Color.FromArgb(214, 214, 214);
			CS$<>8__locals1.m8qZqOl1As = new CustomTextBox
			{
				ColorScheme = CustomTextBoxColorScheme.Dark,
				Location = new Point(15, 130),
				Size = new Size(num - 140, 23),
				BackColor = Color.FromArgb(60, 60, 65),
				ForeColor = Color.FromArgb(214, 214, 214),
				Font = StyleManager.GetMainFont(9.65f)
			};
			Button button = MessageOverlay.UEmJiJFuxR(activateBtnText, num - 115, 130, 100, 23, Color.FromArgb(40, 150, 70));
			button.Font = StyleManager.GetMainFont(7.65f);
			button.Click += CS$<>8__locals1.ofkZNK3AF6;
			Button button2 = MessageOverlay.UEmJiJFuxR(supportBtnText, 12, num2 - 40, 140, 26, Color.FromArgb(200, 150, 0));
			button2.Click += CS$<>8__locals1.KVCZs5pgEB;
			Button button3 = MessageOverlay.UEmJiJFuxR(cancelBtnText, num - 114, num2 - 40, 100, 26, Color.FromArgb(70, 70, 70));
			button3.Click += CS$<>8__locals1.bJ8ZHk5Unl;
			CS$<>8__locals1.aGnZo8Jo9Y.Controls.AddRange(new Control[]
			{
				label,
				label2,
				label3,
				CS$<>8__locals1.FZOZGit30y,
				label4,
				CS$<>8__locals1.m8qZqOl1As,
				button,
				button2,
				button3
			});
			CS$<>8__locals1.KvlZPB7SgJ.Controls.Add(CS$<>8__locals1.aGnZo8Jo9Y);
			CS$<>8__locals1.aGnZo8Jo9Y.BringToFront();
		}

		// Token: 0x06000280 RID: 640 RVA: 0x0000F850 File Offset: 0x0000DA50
		public static void ShowAccountManager(Form parentForm, HytaleAccountManager accountManager, Action onProfileChanged = null)
		{
			MessageOverlay.<>c__DisplayClass4_0 CS$<>8__locals1 = new MessageOverlay.<>c__DisplayClass4_0();
			CS$<>8__locals1.FLTZlvwBKs = parentForm;
			CS$<>8__locals1.i9rZ6dkYPO = accountManager;
			CS$<>8__locals1.j9LZO2mhVs = onProfileChanged;
			if (CS$<>8__locals1.FLTZlvwBKs == null || CS$<>8__locals1.FLTZlvwBKs.IsDisposed)
			{
				return;
			}
			int num = 500;
			int u = 415;
			CS$<>8__locals1.BeGZVh5PNY = MessageOverlay.OMdJ6dO0xM(CS$<>8__locals1.FLTZlvwBKs, num, u);
			Button button = new CustomButton
			{
				Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(759808410 ^ 234560196 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_52dac0565f7f422e80cc0f27df2b90e5),
				Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-696204499 - -557025 ^ -914189081 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3), 11f),
				Size = new Size(25, 25),
				Location = new Point(num - 40, 5),
				FlatStyle = FlatStyle.Flat,
				ForeColor = Color.Gray,
				FlatAppearance = 
				{
					BorderSize = 0,
					MouseOverBackColor = Color.Transparent,
					MouseDownBackColor = Color.Transparent
				},
				Cursor = Cursors.Hand,
				AutoSize = true
			};
			button.Click += CS$<>8__locals1.B60Z9XuBux;
			Label label = MessageOverlay.wdLJOXXyvV(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(607992573 ^ 308033213 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df), 15, 15);
			CS$<>8__locals1.xhXZDhQOSX = new Panel
			{
				Location = new Point(15, 50),
				Size = new Size(num - 30, 260),
				BackColor = Color.FromArgb(35, 35, 40),
				AutoScroll = true,
				BorderStyle = BorderStyle.FixedSingle
			};
			CS$<>8__locals1.vxwZfa6PRa = new CustomTextBox
			{
				Location = new Point(15, 325),
				Size = new Size(num - 270, 28),
				BackColor = Color.FromArgb(60, 60, 65),
				Font = StyleManager.GetMainFont(8.65f),
				ForeColor = Color.White,
				Placeholder = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1583188517 ^ 811797786 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c)
			};
			CS$<>8__locals1.xYgZiuSriM = new Label
			{
				Location = new Point(15, 354),
				Size = new Size(num - 15, 15),
				ForeColor = Color.Salmon,
				Font = StyleManager.GetMainFont(7.5f),
				TextAlign = ContentAlignment.MiddleCenter,
				AutoSize = false,
				Text = ""
			};
			CS$<>8__locals1.BeGZVh5PNY.Controls.Add(CS$<>8__locals1.xYgZiuSriM);
			Button button2 = MessageOverlay.UEmJiJFuxR(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1822672301 ^ -136199670 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d), num - 245, 325, 230, 28, Color.FromArgb(60, 120, 230));
			CS$<>8__locals1.r3aZUq4GiU = new Action(CS$<>8__locals1.L1KZQl9rxe);
			CS$<>8__locals1.xhXZDhQOSX.Tag = CS$<>8__locals1.r3aZUq4GiU;
			button2.Click += CS$<>8__locals1.yQbZgY6o1i;
			CS$<>8__locals1.llqZuoJDkj = MessageOverlay.UEmJiJFuxR(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1292352855 ^ -555027724 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264), 15, 369, num - 30, 30, Color.FromArgb(40, 150, 70));
			CS$<>8__locals1.llqZuoJDkj.Click += CS$<>8__locals1.h1sZYpM04i;
			bpJXyX1qocPR5dVW9GD.Q40191tEbG(CS$<>8__locals1.xhXZDhQOSX.Handle, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -391072081 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18), null);
			CS$<>8__locals1.BeGZVh5PNY.Controls.AddRange(new Control[]
			{
				label,
				CS$<>8__locals1.xhXZDhQOSX,
				CS$<>8__locals1.vxwZfa6PRa,
				button2,
				CS$<>8__locals1.llqZuoJDkj,
				button
			});
			CS$<>8__locals1.FLTZlvwBKs.Controls.Add(CS$<>8__locals1.BeGZVh5PNY);
			CS$<>8__locals1.BeGZVh5PNY.BringToFront();
			CS$<>8__locals1.r3aZUq4GiU();
		}

		// Token: 0x06000281 RID: 641 RVA: 0x0000FC64 File Offset: 0x0000DE64
		private static Panel sU7JY0TK9w(int \u0020, int \u0020, bool \u0020)
		{
			MessageOverlay.<>c__DisplayClass5_0 CS$<>8__locals1 = new MessageOverlay.<>c__DisplayClass5_0();
			CS$<>8__locals1.l41MXFvjVT = new Panel
			{
				Size = new Size(\u0020, 40),
				Location = new Point(5, \u0020),
				BackColor = (\u0020 ? Color.FromArgb(50, 50, 60) : Color.FromArgb(40, 40, 45))
			};
			if (\u0020)
			{
				CS$<>8__locals1.l41MXFvjVT.Paint += CS$<>8__locals1.ycWM0KeGkK;
			}
			return CS$<>8__locals1.l41MXFvjVT;
		}

		// Token: 0x06000282 RID: 642 RVA: 0x0000FCE8 File Offset: 0x0000DEE8
		private static Label ffUJldsbZv(string \u0020, int \u0020, int \u0020)
		{
			return new Label
			{
				Text = \u0020,
				ForeColor = Color.Gray,
				Font = StyleManager.GetMainFont(8f),
				Location = new Point(\u0020, \u0020),
				AutoSize = true
			};
		}

		// Token: 0x06000283 RID: 643 RVA: 0x0000FD28 File Offset: 0x0000DF28
		private static Label LThJVypKAF(string \u0020, int \u0020, int \u0020, bool \u0020)
		{
			return new Label
			{
				Text = \u0020,
				ForeColor = (\u0020 ? Color.White : Color.Gray),
				Font = StyleManager.GetMainFont(\u0020 ? 9.5f : 7.5f),
				Location = new Point(\u0020, \u0020),
				AutoSize = true
			};
		}

		// Token: 0x06000284 RID: 644 RVA: 0x0000FD90 File Offset: 0x0000DF90
		private static Label RH9JDk99M0(string \u0020, int \u0020, int \u0020, bool \u0020 = false)
		{
			string text = (!string.IsNullOrEmpty(\u0020)) ? \u0020.Substring(0, 1).ToUpper() : yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -1131060122 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df);
			return new Label
			{
				Text = text,
				Size = new Size(30, 30),
				Location = new Point(\u0020, \u0020),
				BackColor = (\u0020 ? Color.FromArgb(70, 70, 70) : Color.FromArgb(20, 100, 160)),
				ForeColor = Color.White,
				TextAlign = ContentAlignment.MiddleCenter,
				Font = StyleManager.GetMainFont(12f)
			};
		}

		// Token: 0x06000285 RID: 645 RVA: 0x0000FE54 File Offset: 0x0000E054
		private static Panel OMdJ6dO0xM(Form \u0020, int \u0020, int \u0020)
		{
			return new Panel
			{
				Size = new Size(\u0020, \u0020),
				Location = new Point((\u0020.Width - \u0020) / 2, (\u0020.Height - \u0020) / 2),
				BackColor = Color.FromArgb(45, 45, 50),
				BorderStyle = BorderStyle.FixedSingle,
				Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1876786663 ^ -1581891470 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20)
			};
		}

		// Token: 0x06000286 RID: 646 RVA: 0x0000FECC File Offset: 0x0000E0CC
		private static Label wdLJOXXyvV(string \u0020, int \u0020, int \u0020)
		{
			return new Label
			{
				Text = \u0020,
				Font = StyleManager.GetMainFont(11f),
				ForeColor = Color.White,
				Location = new Point(\u0020, \u0020),
				AutoSize = true
			};
		}

		// Token: 0x06000287 RID: 647 RVA: 0x0000FF0C File Offset: 0x0000E10C
		private static Label iYBJful3t1(string \u0020, int \u0020, int \u0020, int \u0020, int \u0020)
		{
			return new Label
			{
				Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1577388857 >> 1 ^ -982221735 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a),
				Text = \u0020,
				Font = StyleManager.GetMainFont(9f),
				ForeColor = Color.LightGray,
				Location = new Point(\u0020, \u0020),
				AutoSize = true,
				MaximumSize = new Size(\u0020, 0)
			};
		}

		// Token: 0x06000288 RID: 648 RVA: 0x0000FF88 File Offset: 0x0000E188
		private static CustomButton UEmJiJFuxR(string \u0020, int \u0020, int \u0020, int \u0020, int \u0020, Color \u0020)
		{
			return new CustomButton
			{
				Text = \u0020,
				Size = new Size(\u0020, \u0020),
				Location = new Point(\u0020, \u0020),
				Height = \u0020,
				Font = StyleManager.GetMainFont(8.5f),
				FlatStyle = FlatStyle.Flat,
				BackColor = \u0020,
				ForeColor = Color.White,
				DisabledForeColor = Color.FromArgb(255, 255, 255),
				FlatAppearance = 
				{
					BorderSize = 0
				},
				Cursor = Cursors.Hand,
				AutoSize = true
			};
		}
	}
}
