﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x0200004D RID: 77
	[ToolboxItem(true)]
	public class CustomProgressBar : Control
	{
		// Token: 0x17000056 RID: 86
		// (get) Token: 0x06000197 RID: 407 RVA: 0x00007E44 File Offset: 0x00006044
		// (set) Token: 0x06000198 RID: 408 RVA: 0x00007E4C File Offset: 0x0000604C
		[Category("Appearance")]
		public Color ProgressColor { get; set; }

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000199 RID: 409 RVA: 0x00007E58 File Offset: 0x00006058
		// (set) Token: 0x0600019A RID: 410 RVA: 0x00007E60 File Offset: 0x00006060
		[Category("Appearance")]
		public Color BackgroundBarColor { get; set; }

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x0600019B RID: 411 RVA: 0x00007E6C File Offset: 0x0000606C
		// (set) Token: 0x0600019C RID: 412 RVA: 0x00007E74 File Offset: 0x00006074
		[Category("Behavior")]
		public bool IsMarquee
		{
			get
			{
				return this.IILbw1BMDQ;
			}
			set
			{
				this.IILbw1BMDQ = value;
				if (!this.IILbw1BMDQ)
				{
					this.vXXbhx0eCf = -150f;
				}
				base.Invalidate();
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x0600019D RID: 413 RVA: 0x00007E9C File Offset: 0x0000609C
		// (set) Token: 0x0600019E RID: 414 RVA: 0x00007EA4 File Offset: 0x000060A4
		[Category("Behavior")]
		public int Value
		{
			get
			{
				return this.z1WwzJCer1;
			}
			set
			{
				this.z1WwzJCer1 = Math.Max(0, Math.Min(this.CQHb8p2Uob, value));
				base.Invalidate();
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x0600019F RID: 415 RVA: 0x00007EC4 File Offset: 0x000060C4
		// (set) Token: 0x060001A0 RID: 416 RVA: 0x00007ECC File Offset: 0x000060CC
		[Category("Behavior")]
		public int Maximum
		{
			get
			{
				return this.CQHb8p2Uob;
			}
			set
			{
				this.CQHb8p2Uob = value;
				base.Invalidate();
			}
		}

		// Token: 0x060001A1 RID: 417 RVA: 0x00007EDC File Offset: 0x000060DC
		public CustomProgressBar()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.CQHb8p2Uob = 100;
			this.vXXbhx0eCf = -150f;
			this.IILbw1BMDQ = true;
			this.ProgressColor = Color.FromArgb(255, 0, 128, 255);
			this.BackgroundBarColor = Color.FromArgb(220, 30, 30, 30);
			base..ctor();
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.Size = new Size(200, 6);
			this.kGlbklVQ4e = new Timer
			{
				Interval = 15
			};
			this.kGlbklVQ4e.Tick += this.tWiwaUfgGg;
			if (!base.DesignMode)
			{
				this.kGlbklVQ4e.Start();
			}
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x00007FA4 File Offset: 0x000061A4
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			using (SolidBrush solidBrush = new SolidBrush(this.BackgroundBarColor))
			{
				graphics.FillRectangle(solidBrush, 0, 0, base.Width, base.Height);
			}
			using (SolidBrush solidBrush2 = new SolidBrush(this.ProgressColor))
			{
				if (this.IILbw1BMDQ)
				{
					graphics.FillRectangle(solidBrush2, this.vXXbhx0eCf, 0f, 150f, (float)base.Height);
				}
				else
				{
					float num = (this.CQHb8p2Uob > 0) ? ((float)this.z1WwzJCer1 / (float)this.CQHb8p2Uob) : 0f;
					int num2 = (int)((float)base.Width * num);
					if (num2 > 0)
					{
						graphics.FillRectangle(solidBrush2, 0, 0, num2, base.Height);
					}
				}
			}
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x000080A0 File Offset: 0x000062A0
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				Timer timer = this.kGlbklVQ4e;
				if (timer != null)
				{
					timer.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x000080C8 File Offset: 0x000062C8
		[CompilerGenerated]
		private void tWiwaUfgGg(object \u0020, EventArgs \u0020)
		{
			if (this.IILbw1BMDQ)
			{
				this.vXXbhx0eCf += 8f;
				if (this.vXXbhx0eCf > (float)base.Width)
				{
					this.vXXbhx0eCf = -150f;
				}
				base.Invalidate();
			}
		}

		// Token: 0x04000118 RID: 280
		private int z1WwzJCer1;

		// Token: 0x04000119 RID: 281
		private int CQHb8p2Uob;

		// Token: 0x0400011A RID: 282
		private float vXXbhx0eCf;

		// Token: 0x0400011B RID: 283
		private readonly Timer kGlbklVQ4e;

		// Token: 0x0400011C RID: 284
		private bool IILbw1BMDQ;

		// Token: 0x0400011D RID: 285
		[CompilerGenerated]
		private Color juFbb0qrX8;

		// Token: 0x0400011E RID: 286
		[CompilerGenerated]
		private Color TevbJ09DNY;
	}
}
