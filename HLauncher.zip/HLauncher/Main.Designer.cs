﻿namespace HLauncher
{
	// Token: 0x0200008E RID: 142
	public partial class Main : global::RoundedForm
	{
		// Token: 0x060002E1 RID: 737 RVA: 0x00012A6C File Offset: 0x00010C6C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.s88xztVemL != null)
			{
				this.s88xztVemL.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x04000260 RID: 608
		private global::System.ComponentModel.IContainer s88xztVemL;
	}
}
