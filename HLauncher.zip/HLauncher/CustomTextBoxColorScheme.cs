﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x0200004E RID: 78
	public class CustomTextBoxColorScheme
	{
		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060001A5 RID: 421 RVA: 0x00008118 File Offset: 0x00006318
		// (set) Token: 0x060001A6 RID: 422 RVA: 0x00008120 File Offset: 0x00006320
		public Color BackColor { get; set; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x0000812C File Offset: 0x0000632C
		// (set) Token: 0x060001A8 RID: 424 RVA: 0x00008134 File Offset: 0x00006334
		public Color BorderColor { get; set; }

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x00008140 File Offset: 0x00006340
		// (set) Token: 0x060001AA RID: 426 RVA: 0x00008148 File Offset: 0x00006348
		public Color SelectionColor { get; set; }

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060001AB RID: 427 RVA: 0x00008154 File Offset: 0x00006354
		// (set) Token: 0x060001AC RID: 428 RVA: 0x0000815C File Offset: 0x0000635C
		public Color CursorColor { get; set; }

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060001AD RID: 429 RVA: 0x00008168 File Offset: 0x00006368
		// (set) Token: 0x060001AE RID: 430 RVA: 0x00008170 File Offset: 0x00006370
		public Color ForeColor { get; set; }

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060001AF RID: 431 RVA: 0x0000817C File Offset: 0x0000637C
		// (set) Token: 0x060001B0 RID: 432 RVA: 0x00008184 File Offset: 0x00006384
		public Color PlaceholderColor { get; set; }

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060001B1 RID: 433 RVA: 0x00008190 File Offset: 0x00006390
		public static CustomTextBoxColorScheme Default
		{
			get
			{
				return new CustomTextBoxColorScheme
				{
					BackColor = Color.FromArgb(50, 110, 160),
					BorderColor = Color.FromArgb(60, 140, 200),
					SelectionColor = Color.FromArgb(100, 255, 255, 255),
					CursorColor = Color.FromArgb(255, 255, 255),
					ForeColor = Color.FromArgb(255, 255, 255),
					PlaceholderColor = Color.FromArgb(128, 144, 144)
				};
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x00008238 File Offset: 0x00006438
		public static CustomTextBoxColorScheme Dark
		{
			get
			{
				return new CustomTextBoxColorScheme
				{
					BackColor = Color.FromArgb(45, 45, 48),
					BorderColor = Color.FromArgb(100, 100, 100),
					SelectionColor = Color.FromArgb(100, 70, 130, 180),
					CursorColor = Color.FromArgb(255, 255, 255),
					ForeColor = Color.FromArgb(220, 220, 220),
					PlaceholderColor = Color.FromArgb(220, 220, 220)
				};
			}
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x000082D4 File Offset: 0x000064D4
		public CustomTextBoxColorScheme()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x0400011F RID: 287
		[CompilerGenerated]
		private Color jdBbxiTc0i;

		// Token: 0x04000120 RID: 288
		[CompilerGenerated]
		private Color Vxlb1qxiaS;

		// Token: 0x04000121 RID: 289
		[CompilerGenerated]
		private Color Lllb0weYOI;

		// Token: 0x04000122 RID: 290
		[CompilerGenerated]
		private Color JVybXiIqv7;

		// Token: 0x04000123 RID: 291
		[CompilerGenerated]
		private Color yb7bjjAShG;

		// Token: 0x04000124 RID: 292
		[CompilerGenerated]
		private Color mvZb5wAVqA;
	}
}
