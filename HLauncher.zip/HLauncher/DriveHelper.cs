﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using ro2IpYtzntGHp8CGrmT;
using y0ve6F17gu3T12r7mYI;

namespace HLauncher
{
	// Token: 0x020000B2 RID: 178
	public static class DriveHelper
	{
		// Token: 0x0600037A RID: 890 RVA: 0x00016124 File Offset: 0x00014324
		public static char GetFreeDriveLetter()
		{
			List<char> list = DriveInfo.GetDrives().Select(new Func<DriveInfo, char>(DriveHelper.<>c.JitCvHiK71.o5RCu76ao9)).ToList<char>();
			for (char c = 'Z'; c >= 'A'; c -= '\u0001')
			{
				if (!list.Contains(c))
				{
					return c;
				}
			}
			throw new Exception(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1984943586 ^ 512065033 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091));
		}

		// Token: 0x0600037B RID: 891 RVA: 0x000161A8 File Offset: 0x000143A8
		public static void RunSubst(char letter, string path, bool mount)
		{
			string arguments = mount ? string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -310256896 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d), letter, path) : string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-583370756 + -1440598365 ^ -658554542 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e), letter);
			using (Process process = Process.Start(new ProcessStartInfo
			{
				FileName = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1867100645 ^ -36740547 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b),
				Arguments = arguments,
				CreateNoWindow = true,
				UseShellExecute = false
			}))
			{
				if (process != null)
				{
					process.WaitForExit();
				}
			}
		}

		// Token: 0x0600037C RID: 892 RVA: 0x00016290 File Offset: 0x00014490
		public static void CleanupOrphanedDrives(string launcherPath)
		{
			launcherPath = Path.GetFullPath(launcherPath).TrimEnd(new char[]
			{
				'\\'
			});
			for (char c = 'A'; c <= 'Z'; c += '\u0001')
			{
				string text = DriveHelper.NmG1UsrA7E(c);
				if (text != null && text.Equals(launcherPath, StringComparison.OrdinalIgnoreCase))
				{
					DriveHelper.RunSubst(c, null, false);
				}
			}
		}

		// Token: 0x0600037D RID: 893 RVA: 0x000162EC File Offset: 0x000144EC
		private static string NmG1UsrA7E(char \u0020)
		{
			StringBuilder stringBuilder = new StringBuilder(260);
			if (bpJXyX1qocPR5dVW9GD.bdI1Qn0Pf5(string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2039334965 ^ -736974041 ^ -1676957501 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20), \u0020), stringBuilder, stringBuilder.Capacity) != 0U)
			{
				string text = stringBuilder.ToString();
				if (text.StartsWith(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1169289335 ^ -1044392695 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0)))
				{
					return text.Substring(4);
				}
			}
			return null;
		}
	}
}
