﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x0200002C RID: 44
public class GameSessionResponse
{
	// Token: 0x17000033 RID: 51
	// (get) Token: 0x060000CF RID: 207 RVA: 0x00004BD8 File Offset: 0x00002DD8
	// (set) Token: 0x060000D0 RID: 208 RVA: 0x00004BE0 File Offset: 0x00002DE0
	[JsonProperty("expiresAt")]
	public DateTime ExpiresAt { get; set; }

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x060000D1 RID: 209 RVA: 0x00004BEC File Offset: 0x00002DEC
	// (set) Token: 0x060000D2 RID: 210 RVA: 0x00004BF4 File Offset: 0x00002DF4
	[JsonProperty("identityToken")]
	public string IdentityIdToken { get; set; }

	// Token: 0x17000035 RID: 53
	// (get) Token: 0x060000D3 RID: 211 RVA: 0x00004C00 File Offset: 0x00002E00
	// (set) Token: 0x060000D4 RID: 212 RVA: 0x00004C08 File Offset: 0x00002E08
	[JsonProperty("sessionToken")]
	public string SessionToken { get; set; }

	// Token: 0x060000D5 RID: 213 RVA: 0x00004C14 File Offset: 0x00002E14
	public GameSessionResponse()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
	}

	// Token: 0x040000AA RID: 170
	[CompilerGenerated]
	private DateTime m0VhqeamOT;

	// Token: 0x040000AB RID: 171
	[CompilerGenerated]
	private string cLZh7tSSUe;

	// Token: 0x040000AC RID: 172
	[CompilerGenerated]
	private string q9phA1heD3;
}
