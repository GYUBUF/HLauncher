﻿using System;
using System.Drawing;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000018 RID: 24
public class CustomContextMenu : ProfessionalColorTable
{
	// Token: 0x1700002A RID: 42
	// (get) Token: 0x0600008F RID: 143 RVA: 0x000043A8 File Offset: 0x000025A8
	public override Color MenuBorder
	{
		get
		{
			return Color.FromArgb(60, 140, 200);
		}
	}

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x06000090 RID: 144 RVA: 0x000043BC File Offset: 0x000025BC
	public override Color MenuItemBorder
	{
		get
		{
			return Color.FromArgb(60, 140, 200);
		}
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x06000091 RID: 145 RVA: 0x000043D0 File Offset: 0x000025D0
	public override Color MenuItemSelectedGradientBegin
	{
		get
		{
			return Color.FromArgb(70, 160, 230);
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000092 RID: 146 RVA: 0x000043E4 File Offset: 0x000025E4
	public override Color MenuItemSelectedGradientEnd
	{
		get
		{
			return Color.FromArgb(70, 160, 230);
		}
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000093 RID: 147 RVA: 0x000043F8 File Offset: 0x000025F8
	public override Color MenuItemSelected
	{
		get
		{
			return Color.FromArgb(70, 160, 230);
		}
	}

	// Token: 0x06000094 RID: 148 RVA: 0x0000440C File Offset: 0x0000260C
	public CustomContextMenu()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
	}
}
