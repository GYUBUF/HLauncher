﻿using System;

namespace HLauncher
{
	// Token: 0x0200005E RID: 94
	public enum HytaleScope
	{
		// Token: 0x04000180 RID: 384
		Client,
		// Token: 0x04000181 RID: 385
		Server,
		// Token: 0x04000182 RID: 386
		Editor
	}
}
