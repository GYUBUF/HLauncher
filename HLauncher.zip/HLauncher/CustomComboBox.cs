﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000017 RID: 23
public class CustomComboBox : ComboBox
{
	// Token: 0x06000084 RID: 132 RVA: 0x00003EC4 File Offset: 0x000020C4
	public CustomComboBox()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		base.DrawMode = DrawMode.OwnerDrawFixed;
		base.DropDownStyle = ComboBoxStyle.DropDownList;
		base.Size = new Size(200, 22);
		this.BackColor = Color.FromArgb(50, 110, 160);
		this.ForeColor = Color.FromArgb(230, 240, 255);
		this.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-571302991 + -886974362 ^ -1220601086 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562), 10f);
		this.FcthJlc7Ar();
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00003F74 File Offset: 0x00002174
	private void FcthJlc7Ar()
	{
		SolidBrush abmh1yUZKS = this.ABmh1yUZKS;
		if (abmh1yUZKS != null)
		{
			abmh1yUZKS.Dispose();
		}
		SolidBrush xxyh03qfZk = this.Xxyh03qfZk;
		if (xxyh03qfZk != null)
		{
			xxyh03qfZk.Dispose();
		}
		Pen pen = this.th5hXBZb0J;
		if (pen != null)
		{
			pen.Dispose();
		}
		Pen pen2 = this.z83hjIOEmN;
		if (pen2 != null)
		{
			pen2.Dispose();
		}
		this.ABmh1yUZKS = new SolidBrush(this.BackColor);
		this.Xxyh03qfZk = new SolidBrush(this.ForeColor);
		this.th5hXBZb0J = new Pen(Color.FromArgb(60, 140, 200), 2f);
		this.z83hjIOEmN = new Pen(Color.FromArgb(70, 160, 230), 2f);
	}

	// Token: 0x06000086 RID: 134 RVA: 0x00004044 File Offset: 0x00002244
	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		graphics.FillRectangle(this.ABmh1yUZKS, base.ClientRectangle);
		Rectangle bounds = new Rectangle(7, 0, base.Width - 30, base.Height);
		string text = (this.SelectedIndex >= 0) ? base.Items[this.SelectedIndex].ToString() : this.Text;
		TextRenderer.DrawText(graphics, text, this.Font, bounds, this.ForeColor, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
		int num = 20;
		Rectangle rectangle = new Rectangle(base.Width - num, 0, num, base.Height);
		int num2 = rectangle.X + rectangle.Width / 2;
		int num3 = rectangle.Y + rectangle.Height / 2;
		Point[] points = new Point[]
		{
			new Point(num2 - 4, num3 - 2),
			new Point(num2 + 4, num3 - 2),
			new Point(num2, num3 + 3)
		};
		using (SolidBrush solidBrush = new SolidBrush((this.Focused || this.iqXhxeMcll) ? Color.White : Color.FromArgb(185, 209, 234)))
		{
			graphics.FillPolygon(solidBrush, points);
		}
		Pen pen = this.Focused ? this.z83hjIOEmN : this.th5hXBZb0J;
		graphics.DrawRectangle(pen, 1, 1, base.Width - 2, base.Height - 2);
	}

	// Token: 0x06000087 RID: 135 RVA: 0x000041FC File Offset: 0x000023FC
	protected override void OnDrawItem(DrawItemEventArgs e)
	{
		if (e.Index < 0)
		{
			return;
		}
		bool flag = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
		using (SolidBrush solidBrush = new SolidBrush(flag ? Color.FromArgb(80, 180, 255) : this.BackColor))
		{
			e.Graphics.FillRectangle(solidBrush, e.Bounds);
		}
		TextRenderer.DrawText(e.Graphics, base.Items[e.Index].ToString(), this.Font, e.Bounds, this.ForeColor, TextFormatFlags.VerticalCenter);
		if (flag)
		{
			e.DrawFocusRectangle();
		}
	}

	// Token: 0x06000088 RID: 136 RVA: 0x000042C0 File Offset: 0x000024C0
	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			SolidBrush abmh1yUZKS = this.ABmh1yUZKS;
			if (abmh1yUZKS != null)
			{
				abmh1yUZKS.Dispose();
			}
			SolidBrush xxyh03qfZk = this.Xxyh03qfZk;
			if (xxyh03qfZk != null)
			{
				xxyh03qfZk.Dispose();
			}
			Pen pen = this.th5hXBZb0J;
			if (pen != null)
			{
				pen.Dispose();
			}
			Pen pen2 = this.z83hjIOEmN;
			if (pen2 != null)
			{
				pen2.Dispose();
			}
		}
		base.Dispose(disposing);
	}

	// Token: 0x06000089 RID: 137 RVA: 0x00004338 File Offset: 0x00002538
	protected override void OnBackColorChanged(EventArgs e)
	{
		this.FcthJlc7Ar();
		base.OnBackColorChanged(e);
	}

	// Token: 0x0600008A RID: 138 RVA: 0x00004348 File Offset: 0x00002548
	protected override void OnForeColorChanged(EventArgs e)
	{
		this.FcthJlc7Ar();
		base.OnForeColorChanged(e);
	}

	// Token: 0x0600008B RID: 139 RVA: 0x00004358 File Offset: 0x00002558
	protected override void OnMouseEnter(EventArgs e)
	{
		this.iqXhxeMcll = true;
		base.Invalidate();
		base.OnMouseEnter(e);
	}

	// Token: 0x0600008C RID: 140 RVA: 0x00004370 File Offset: 0x00002570
	protected override void OnMouseLeave(EventArgs e)
	{
		this.iqXhxeMcll = false;
		base.Invalidate();
		base.OnMouseLeave(e);
	}

	// Token: 0x0600008D RID: 141 RVA: 0x00004388 File Offset: 0x00002588
	protected override void OnGotFocus(EventArgs e)
	{
		base.Invalidate();
		base.OnGotFocus(e);
	}

	// Token: 0x0600008E RID: 142 RVA: 0x00004398 File Offset: 0x00002598
	protected override void OnLostFocus(EventArgs e)
	{
		base.Invalidate();
		base.OnLostFocus(e);
	}

	// Token: 0x04000047 RID: 71
	private bool iqXhxeMcll;

	// Token: 0x04000048 RID: 72
	private SolidBrush ABmh1yUZKS;

	// Token: 0x04000049 RID: 73
	private SolidBrush Xxyh03qfZk;

	// Token: 0x0400004A RID: 74
	private Pen th5hXBZb0J;

	// Token: 0x0400004B RID: 75
	private Pen z83hjIOEmN;
}
