﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000016 RID: 22
public class CustomCheckBox : Control
{
	// Token: 0x14000001 RID: 1
	// (add) Token: 0x06000079 RID: 121 RVA: 0x00003A2C File Offset: 0x00001C2C
	// (remove) Token: 0x0600007A RID: 122 RVA: 0x00003A64 File Offset: 0x00001C64
	public event EventHandler CheckedChanged
	{
		[CompilerGenerated]
		add
		{
			EventHandler eventHandler = this.gtihbeeVBD;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.gtihbeeVBD, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
		[CompilerGenerated]
		remove
		{
			EventHandler eventHandler = this.gtihbeeVBD;
			EventHandler eventHandler2;
			do
			{
				eventHandler2 = eventHandler;
				EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
				eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.gtihbeeVBD, value2, eventHandler2);
			}
			while (eventHandler != eventHandler2);
		}
	}

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x0600007B RID: 123 RVA: 0x00003A9C File Offset: 0x00001C9C
	// (set) Token: 0x0600007C RID: 124 RVA: 0x00003AA4 File Offset: 0x00001CA4
	public bool Checked
	{
		get
		{
			return this.JNyzlf0pd;
		}
		set
		{
			if (this.JNyzlf0pd != value)
			{
				this.JNyzlf0pd = value;
				EventHandler eventHandler = this.gtihbeeVBD;
				if (eventHandler != null)
				{
					eventHandler(this, EventArgs.Empty);
				}
				base.Invalidate();
			}
		}
	}

	// Token: 0x0600007D RID: 125 RVA: 0x00003ADC File Offset: 0x00001CDC
	public CustomCheckBox()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		this.tH0h8nqtSt = Color.FromArgb(50, 110, 160);
		this.mnfhhIwWb0 = Color.FromArgb(215, 228, 242);
		this.ssxhkaRxh5 = Color.FromArgb(215, 228, 242);
		this.qOIhw17Alo = Color.FromArgb(60, 140, 200);
		base..ctor();
		base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		this.BackColor = Color.Transparent;
		base.Size = new Size(160, 24);
		this.ForeColor = this.ssxhkaRxh5;
		this.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-374163162 ^ -1855269149 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770), 10f);
		this.Cursor = Cursors.Hand;
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00003BC4 File Offset: 0x00001DC4
	protected override void OnPaint(PaintEventArgs e)
	{
		Graphics graphics = e.Graphics;
		graphics.SmoothingMode = SmoothingMode.AntiAlias;
		graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
		int num = 18;
		int y = (base.Height - num) / 2;
		Rectangle rect = new Rectangle(1, y, num, num);
		using (SolidBrush solidBrush = new SolidBrush(this.tH0h8nqtSt))
		{
			graphics.FillRectangle(solidBrush, rect);
		}
		using (Pen pen = new Pen(this.qOIhw17Alo, 2f))
		{
			pen.Alignment = PenAlignment.Inset;
			graphics.DrawRectangle(pen, rect);
		}
		if (this.JNyzlf0pd)
		{
			using (Pen pen2 = new Pen(this.mnfhhIwWb0, 2.5f))
			{
				pen2.StartCap = LineCap.Round;
				pen2.EndCap = LineCap.Round;
				pen2.LineJoin = LineJoin.Round;
				PointF[] points = new PointF[]
				{
					new PointF((float)rect.X + (float)rect.Width * 0.25f, (float)rect.Y + (float)rect.Height * 0.5f),
					new PointF((float)rect.X + (float)rect.Width * 0.45f, (float)rect.Y + (float)rect.Height * 0.75f),
					new PointF((float)rect.X + (float)rect.Width * 0.8f, (float)rect.Y + (float)rect.Height * 0.25f)
				};
				graphics.DrawLines(pen2, points);
			}
		}
		Rectangle bounds = new Rectangle(num + 8, 0, base.Width - num - 8, base.Height);
		TextFormatFlags flags = TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak | TextFormatFlags.NoPadding;
		TextRenderer.DrawText(graphics, this.Text, this.Font, bounds, this.ForeColor, flags);
	}

	// Token: 0x0600007F RID: 127 RVA: 0x00003DD0 File Offset: 0x00001FD0
	protected override void OnClick(EventArgs e)
	{
		this.Checked = !this.Checked;
		base.Focus();
		base.OnClick(e);
	}

	// Token: 0x06000080 RID: 128 RVA: 0x00003DF0 File Offset: 0x00001FF0
	protected override void OnKeyDown(KeyEventArgs e)
	{
		if (e.KeyCode == Keys.Space)
		{
			this.Checked = !this.Checked;
		}
		base.OnKeyDown(e);
	}

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000081 RID: 129 RVA: 0x00003E18 File Offset: 0x00002018
	// (set) Token: 0x06000082 RID: 130 RVA: 0x00003E20 File Offset: 0x00002020
	public override string Text
	{
		get
		{
			return base.Text;
		}
		set
		{
			base.Text = value;
			this.NsraE94R0();
		}
	}

	// Token: 0x06000083 RID: 131 RVA: 0x00003E30 File Offset: 0x00002030
	private void NsraE94R0()
	{
		if (string.IsNullOrEmpty(this.Text) || this.Font == null)
		{
			return;
		}
		Size size = TextRenderer.MeasureText(this.Text, this.Font);
		int num = 18;
		int num2 = 8;
		int num3 = Math.Max(24, size.Height + 4);
		int num4 = num + num2 + size.Width + 4;
		if (base.Size.Width != num4 || base.Size.Height != num3)
		{
			base.Size = new Size(num4, num3);
		}
	}

	// Token: 0x04000041 RID: 65
	private bool JNyzlf0pd;

	// Token: 0x04000042 RID: 66
	private readonly Color tH0h8nqtSt;

	// Token: 0x04000043 RID: 67
	private readonly Color mnfhhIwWb0;

	// Token: 0x04000044 RID: 68
	private readonly Color ssxhkaRxh5;

	// Token: 0x04000045 RID: 69
	private readonly Color qOIhw17Alo;

	// Token: 0x04000046 RID: 70
	[CompilerGenerated]
	private EventHandler gtihbeeVBD;
}
