﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000034 RID: 52
public class PatchResponse
{
	// Token: 0x17000054 RID: 84
	// (get) Token: 0x06000120 RID: 288 RVA: 0x00004FE4 File Offset: 0x000031E4
	// (set) Token: 0x06000121 RID: 289 RVA: 0x00004FEC File Offset: 0x000031EC
	[JsonProperty("steps")]
	public List<PatchStep> Steps { get; set; }

	// Token: 0x06000122 RID: 290 RVA: 0x00004FF8 File Offset: 0x000031F8
	public PatchResponse()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
	}

	// Token: 0x040000CD RID: 205
	[CompilerGenerated]
	private List<PatchStep> aJBkqGjWRD;
}
