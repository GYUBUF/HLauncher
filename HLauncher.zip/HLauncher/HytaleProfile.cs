﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000030 RID: 48
public class HytaleProfile
{
	// Token: 0x17000047 RID: 71
	// (get) Token: 0x060000FC RID: 252 RVA: 0x00004E54 File Offset: 0x00003054
	// (set) Token: 0x060000FD RID: 253 RVA: 0x00004E5C File Offset: 0x0000305C
	[JsonProperty("uuid")]
	public string Id { get; set; }

	// Token: 0x17000048 RID: 72
	// (get) Token: 0x060000FE RID: 254 RVA: 0x00004E68 File Offset: 0x00003068
	// (set) Token: 0x060000FF RID: 255 RVA: 0x00004E70 File Offset: 0x00003070
	[JsonProperty("username")]
	public string Name { get; set; }

	// Token: 0x17000049 RID: 73
	// (get) Token: 0x06000100 RID: 256 RVA: 0x00004E7C File Offset: 0x0000307C
	// (set) Token: 0x06000101 RID: 257 RVA: 0x00004E84 File Offset: 0x00003084
	[JsonProperty("skin")]
	public string SkinJson { get; set; }

	// Token: 0x1700004A RID: 74
	// (get) Token: 0x06000102 RID: 258 RVA: 0x00004E90 File Offset: 0x00003090
	// (set) Token: 0x06000103 RID: 259 RVA: 0x00004E98 File Offset: 0x00003098
	[JsonProperty("createdAt")]
	public DateTime CreatedAt { get; set; }

	// Token: 0x1700004B RID: 75
	// (get) Token: 0x06000104 RID: 260 RVA: 0x00004EA4 File Offset: 0x000030A4
	// (set) Token: 0x06000105 RID: 261 RVA: 0x00004EAC File Offset: 0x000030AC
	[JsonProperty("entitlements")]
	public List<string> Entitlements { get; set; }

	// Token: 0x1700004C RID: 76
	// (get) Token: 0x06000106 RID: 262 RVA: 0x00004EB8 File Offset: 0x000030B8
	// (set) Token: 0x06000107 RID: 263 RVA: 0x00004EC0 File Offset: 0x000030C0
	[JsonProperty("nextNameChangeAt")]
	public DateTime? NextNameChangeAt { get; set; }

	// Token: 0x06000108 RID: 264 RVA: 0x00004ECC File Offset: 0x000030CC
	public HytaleProfile()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
	}

	// Token: 0x040000BD RID: 189
	[CompilerGenerated]
	private string YQlhFbl78f;

	// Token: 0x040000BE RID: 190
	[CompilerGenerated]
	private string nikhd3O94y;

	// Token: 0x040000BF RID: 191
	[CompilerGenerated]
	private string GOmhWtnTi7;

	// Token: 0x040000C0 RID: 192
	[CompilerGenerated]
	private DateTime vkIheOqlfD;

	// Token: 0x040000C1 RID: 193
	[CompilerGenerated]
	private List<string> JRUhnG5LD5;

	// Token: 0x040000C2 RID: 194
	[CompilerGenerated]
	private DateTime? omih3JbCJC;
}
