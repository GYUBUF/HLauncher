﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using AGSw7LJMkp5usDW1gK1;
using gt2OLuXUIOYbfABBoJo;
using HLauncher.Properties;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;
using y0ve6F17gu3T12r7mYI;

namespace HLauncher
{
	// Token: 0x0200008E RID: 142
	public partial class Main : RoundedForm
	{
		// Token: 0x060002AF RID: 687 RVA: 0x00010028 File Offset: 0x0000E228
		public Main()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.w4UxiE1Enf = new ToolTip();
			this.CmkxF65BH2 = new HytaleAccountManager();
			base..ctor();
			Directory.SetCurrentDirectory(AppContext.BaseDirectory);
			this.e4dxTkglkD();
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer, true);
			base.UpdateStyles();
			base.AutoScaleMode = AutoScaleMode.None;
			base.AutoScaleDimensions = new SizeF(100f, 100f);
			this.mbv1xj0auj.Image = yNhAJGXiuLnPpwrVl1j.gQ7XvmxHkE(Assembly.GetEntryAssembly().Location, 16);
			this.x1A1t8whsW.Renderer = new ToolStripProfessionalRenderer(new CustomContextMenu());
			string text = Main.zdmx6d1IAa ? yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1876786663 ^ -1270763070 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8) : "";
			string text2 = yNhAJGXiuLnPpwrVl1j.g8fXe2k6p6() ? yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1222915046 >> 5 ^ -1407918339 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1d30fd1b0072480a959ab725d2c0b406) : "";
			string text3 = string.Concat(new string[]
			{
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1577388857 >> 1 ^ -577128132 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3423fe0bd378445e9a426e728c08b0d3),
				Assembly.GetExecutingAssembly().GetName().Version.ToString(3),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-382924511 ^ -1919881502 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d),
				text,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1487526596 - 1491293507 ^ -949604966 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7),
				text2
			}).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2069130535 + -961544443 ^ 1411256166 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-551092600 ^ 1412615215 ^ -6971781 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a)).Trim();
			this.Text = text3;
			this.SaJ1J3Tac0.Text = text3;
			this.Q4q1hb8iU8.Text = "";
			this.hGr10Itn8r.Text = "";
			this.btX1rOiDVU.IsMarquee = false;
			AppSettings settings = SettingsManager.Settings;
			double num = settings.TransparencyEnabled ? 0.95 : 1.0;
			i18n.Initialize(settings.Language);
			i18n.LanguageChanged += this.TV4JuHgIoj;
			if (string.IsNullOrEmpty(settings.Language))
			{
				SettingsManager.Settings.Language = i18n.CurrentLanguage;
			}
			this.GvDJWsZO6k();
			this.aiwJprfnjt();
			this.yWVJdCIlSc();
			if (settings.AnimationsEnabled)
			{
				this.gGPxeWDVEP = FormAnimations.AnimateFormAppearance(this, num, null);
			}
			else
			{
				base.Opacity = num;
			}
			if (yNhAJGXiuLnPpwrVl1j.ix5XW29DPS() && !settings.IgnoreNetAlert)
			{
				MessageOverlay.ShowConfirm(this, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 375621763 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a1f1dffb08f44e581e0c0e6fac695b4)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1366522423 ^ -1845971842 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(819711667 ^ 1493104556 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1877665038 - 1504633712 ^ 782027777 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7)), new Action(Main.<>c.QkSMmxACsq.HRkMZfedYj), null);
			}
			this.A40xvwHqfS = this.oqb1s1mNQr.Left;
			this.nbgxEDL3GM = -this.oqb1s1mNQr.Width - 8;
			MethodInfo method = typeof(Control).GetMethod(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1406576133 >> 4 ^ -454447366 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562), BindingFlags.Instance | BindingFlags.NonPublic);
			if (method != null)
			{
				method.Invoke(this.oqb1s1mNQr, new object[]
				{
					ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer,
					true
				});
			}
			this.ogixbOuuit(SettingsManager.Settings.MainBoxHidden, false);
			this.e9nxLpj4fy = new FormDrags(this);
			this.e9nxLpj4fy.AttachToControl(this.yx818kJA68);
			this.e9nxLpj4fy.AttachToControl(this.SaJ1J3Tac0);
			this.eLAJUYwbY5(this.I7h1bkVyu9.Text);
			if (Main.zdmx6d1IAa)
			{
				CleanManager.Clean();
				this.HFF1Td7WHu.Visible = true;
			}
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x000104AC File Offset: 0x0000E6AC
		private void eLAJUYwbY5(string \u0020)
		{
			Main.<>c__DisplayClass12_0 CS$<>8__locals1 = new Main.<>c__DisplayClass12_0();
			CS$<>8__locals1.NMGMGANPFt = this;
			CS$<>8__locals1.gwaMTBCxHw = \u0020;
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(CS$<>8__locals1.m4IM42G1FB));
				return;
			}
			try
			{
				AppSettings settings = SettingsManager.Settings;
				string text = null;
				if (settings.IsOnlineMode && !string.IsNullOrEmpty(settings.SelectedProfileId))
				{
					text = settings.SelectedProfileId;
				}
				else if (!string.IsNullOrWhiteSpace(CS$<>8__locals1.gwaMTBCxHw))
				{
					text = UUID.Generate(CS$<>8__locals1.gwaMTBCxHw);
				}
				if (string.IsNullOrEmpty(text))
				{
					this.CeT1HYBqh5.Image = null;
					this.EnGxdDyjWi = false;
					base.Invalidate();
				}
				else
				{
					string text2 = PathHelper.Combine(new string[]
					{
						RJG3u8JZLa1autEARgF.METJ4myejd,
						yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-203770899 ^ -1405544570 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e),
						yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -1605676482 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc),
						text + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-626376545 ^ -213259946 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18)
					});
					if (PathHelper.FileExists(text2))
					{
						using (FileStream fileStream = new FileStream(Path.GetFullPath(text2), FileMode.Open, FileAccess.Read))
						{
							Image image = this.CeT1HYBqh5.Image;
							Bitmap bitmap = new Bitmap(fileStream);
							bitmap.MakeTransparent(Color.FromArgb(47, 58, 79));
							this.CeT1HYBqh5.Image = bitmap;
							if (image != null)
							{
								image.Dispose();
							}
						}
						this.CeT1HYBqh5.SizeMode = PictureBoxSizeMode.CenterImage;
						this.EnGxdDyjWi = true;
					}
					else
					{
						Image image2 = this.CeT1HYBqh5.Image;
						this.CeT1HYBqh5.Image = null;
						if (image2 != null)
						{
							image2.Dispose();
						}
						this.EnGxdDyjWi = false;
					}
					if (this.CeT1HYBqh5 != null)
					{
						int num = 70;
						int height = 24;
						int x = this.CeT1HYBqh5.Left + (this.CeT1HYBqh5.Width - num) / 2;
						int y = this.CeT1HYBqh5.Bottom - 14;
						Rectangle b = new Rectangle(x, y, num, height);
						Rectangle rc = Rectangle.Union(this.CeT1HYBqh5.Bounds, b);
						rc.Inflate(2, 2);
						base.Invalidate(rc);
						base.Update();
						this.CeT1HYBqh5.Refresh();
					}
				}
			}
			catch
			{
				this.CeT1HYBqh5.Image = null;
				this.EnGxdDyjWi = false;
				base.Invalidate();
			}
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x0001076C File Offset: 0x0000E96C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (this.EnGxdDyjWi && this.CeT1HYBqh5 != null)
			{
				using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(128, 10, 15, 20)))
				{
					e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
					int num = 70;
					int height = 24;
					int x = this.CeT1HYBqh5.Left + (this.CeT1HYBqh5.Width - num) / 2;
					int y = this.CeT1HYBqh5.Bottom - 14;
					e.Graphics.FillEllipse(solidBrush, new Rectangle(x, y, num, height));
				}
			}
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00010824 File Offset: 0x0000EA24
		protected override void WndProc(ref Message m)
		{
			if (m.Msg == bpJXyX1qocPR5dVW9GD.b841VILlRi)
			{
				Tray.Show(this, this.nKS1GlWP6n);
				bpJXyX1qocPR5dVW9GD.N9k1olbldd(base.Handle);
				Rectangle workingArea = Screen.FromPoint(Cursor.Position).WorkingArea;
				base.Location = new Point(workingArea.Left + (workingArea.Width - base.Width) / 2, workingArea.Top + (workingArea.Height - base.Height) / 2);
			}
			base.WndProc(ref m);
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x000108AC File Offset: 0x0000EAAC
		private void TV4JuHgIoj(string \u0020)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(this.xyjxBkqTGa));
				return;
			}
			this.aiwJprfnjt();
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x000108D4 File Offset: 0x0000EAD4
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			Main.<OnFormClosing>d__17 <OnFormClosing>d__;
			<OnFormClosing>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<OnFormClosing>d__.<>4__this = this;
			<OnFormClosing>d__.e = e;
			<OnFormClosing>d__.<>1__state = -1;
			<OnFormClosing>d__.<>t__builder.Start<Main.<OnFormClosing>d__17>(ref <OnFormClosing>d__);
		}

		// Token: 0x060002B5 RID: 693 RVA: 0x00010914 File Offset: 0x0000EB14
		private void gQmJvJuni3(string \u0020, bool \u0020 = false)
		{
			Main.<>c__DisplayClass18_0 CS$<>8__locals1 = new Main.<>c__DisplayClass18_0();
			CS$<>8__locals1.X2DMqBZEW7 = this;
			CS$<>8__locals1.jC8M7ZAv9O = \u0020;
			CS$<>8__locals1.Cv0MAXnTML = \u0020;
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(CS$<>8__locals1.rtLMB4ZGSZ));
				return;
			}
			Panel panel = base.Controls.Find(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -817168682 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22), true).FirstOrDefault<Control>() as Panel;
			if (panel != null)
			{
				Label label = panel.Controls.Find(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1402547601 ^ -196664452 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a), true).FirstOrDefault<Control>() as Label;
				if (label != null)
				{
					label.Text = CS$<>8__locals1.jC8M7ZAv9O;
					label.Refresh();
				}
				if (CS$<>8__locals1.Cv0MAXnTML)
				{
					Button button = panel.Controls.Find(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1699465266 ^ -230626163 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc), true).FirstOrDefault<Control>() as Button;
					if (button != null)
					{
						button.Visible = false;
					}
				}
			}
		}

		// Token: 0x060002B6 RID: 694 RVA: 0x00010A30 File Offset: 0x0000EC30
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			i18n.LanguageChanged -= this.TV4JuHgIoj;
			FormAnimations.StopAnimation(this.gGPxeWDVEP);
			FormAnimations.StopAnimation(this.tHbxUMsubx);
			FormDrags formDrags = this.e9nxLpj4fy;
			if (formDrags != null)
			{
				formDrags.DetachFromControl(this.yx818kJA68);
			}
			FormDrags formDrags2 = this.e9nxLpj4fy;
			if (formDrags2 != null)
			{
				formDrags2.DetachFromControl(this.SaJ1J3Tac0);
			}
			base.OnFormClosed(e);
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x00010AA8 File Offset: 0x0000ECA8
		private void XCyJEdJRB7(object \u0020, EventArgs \u0020)
		{
			Main.<Main_LoadAsync>d__20 <Main_LoadAsync>d__;
			<Main_LoadAsync>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<Main_LoadAsync>d__.<>4__this = this;
			<Main_LoadAsync>d__.<>1__state = -1;
			<Main_LoadAsync>d__.<>t__builder.Start<Main.<Main_LoadAsync>d__20>(ref <Main_LoadAsync>d__);
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x00010AE0 File Offset: 0x0000ECE0
		private void aiwJprfnjt()
		{
			this.KA91KR1HT3.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~234019875 ^ -2102180611 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add));
			this.oUB1cv1mHR.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1397297908 ^ 1810491022 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7));
			this.G9V14qXxIv.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-626376545 ^ -502615260 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7));
			this.GHn1kSMykE.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-907199388 - -1774585445 ^ 1460524631 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1c66e07149574924b7cd3da5aa89d5a4));
			this.SY61wv959Y.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(339415119 ^ 1778716027 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25));
			this.qkc1mdcGNq.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(133603179 ^ 1774743956 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c));
			this.X1y1X0lluq.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-551092600 ^ 1412615215 ^ -72720270 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add));
			this.Abb12SSsH2.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1479692193 ^ 1571245320 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a1f1dffb08f44e581e0c0e6fac695b4));
			this.o7O1yRJB3K.Text = (GameManager.IsGameRunning ? i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-203770899 ^ -430707159 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a)) : i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1721586492 ^ 925967805 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1d30fd1b0072480a959ab725d2c0b406)));
			if (this.Rkd1ZHfnT8 != null)
			{
				this.Rkd1ZHfnT8.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(607992573 ^ 531524070 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790)) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1955617249 >> 6 ^ 809933886 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20);
			}
			if (this.f6M1CAxqn9 != null)
			{
				this.f6M1CAxqn9.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--238918963 ^ 1887567616 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbea00432075407aa72d35bfa93254e3)) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(759808410 ^ 1164746097 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f);
			}
			this.w4UxiE1Enf.SetToolTip(this.qkc1mdcGNq, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -255335269 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20)));
			this.w4UxiE1Enf.SetToolTip(this.X1y1X0lluq, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-203770899 ^ -977550647 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df)));
			this.w4UxiE1Enf.SetToolTip(this.Abb12SSsH2, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-866207546 ^ -398595963 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8)));
			this.w4UxiE1Enf.SetToolTip(this.MLK1SmC0fp, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-704542734 ^ -1875302417 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70)));
			this.w4UxiE1Enf.SetToolTip(this.f6M1CAxqn9, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 1944397368 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25)));
			this.w4UxiE1Enf.SetToolTip(this.DTS1N5UREm, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1366522423 ^ -1007303877 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b)));
			this.w4UxiE1Enf.SetToolTip(this.HFF1Td7WHu, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(931021470 ^ 1370897965 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22)));
			if (this.UlQxIj8Dtx != null)
			{
				this.UlQxIj8Dtx.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(217283769 ^ 1657639686 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c));
			}
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x00010EF0 File Offset: 0x0000F0F0
		private void UKlJFwiZXG(Dictionary<string, VersionInfo> \u0020)
		{
			if (\u0020 == null)
			{
				return;
			}
			string text = string.Join(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -2047727741 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94), \u0020.Values.Select(new Func<VersionInfo, string>(Main.<>c.QkSMmxACsq.LfsMCrUsfr)));
			if (text == this.Ln1xfmldC5)
			{
				return;
			}
			this.Ln1xfmldC5 = text;
			this.qf6xO3gdmw = new Dictionary<string, VersionDataInternal>();
			List<string> list = new List<string>();
			foreach (KeyValuePair<string, VersionInfo> keyValuePair in \u0020)
			{
				string key = keyValuePair.Key;
				VersionInfo value = keyValuePair.Value;
				string branch = (key == yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1193207239 - -1972173397 ^ 1347422698 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25)) ? yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-269698511 ^ -795296812 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410) : yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-382924511 ^ -56337983 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a);
				string text2 = key;
				if (key != yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2039334965 ^ -736974041 ^ -652311034 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a) && key != yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-269698511 ^ -103989071 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8))
				{
					text2 = value.Version + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(575497718 << 5 ^ 1026362606 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a) + key;
				}
				this.qf6xO3gdmw.Add(text2, new VersionDataInternal
				{
					Version = value.Version,
					Name = value.Name,
					Date = value.Date,
					Branch = branch
				});
				list.Add(text2);
			}
			this.LH711m4nqc.Items.Clear();
			string[] array = list.OrderBy(new Func<string, int>(Main.<>c.QkSMmxACsq.HIDMSpswSE)).ThenByDescending(new Func<string, string>(this.Kt5xQorrL9)).ToArray<string>();
			ComboBox.ObjectCollection items = this.LH711m4nqc.Items;
			object[] items2 = array;
			items.AddRange(items2);
			string selectedVersionName = SettingsManager.Settings.SelectedVersionName;
			int num = -1;
			if (!string.IsNullOrEmpty(selectedVersionName))
			{
				num = this.LH711m4nqc.FindStringExact(selectedVersionName);
			}
			if (num != -1)
			{
				this.LH711m4nqc.SelectedIndex = num;
				return;
			}
			if (this.LH711m4nqc.Items.Count > 0)
			{
				this.LH711m4nqc.SelectedIndex = 0;
			}
		}

		// Token: 0x060002BA RID: 698 RVA: 0x000111E4 File Offset: 0x0000F3E4
		private void yWVJdCIlSc()
		{
			Main.<>c__DisplayClass26_0 CS$<>8__locals1 = new Main.<>c__DisplayClass26_0();
			CS$<>8__locals1.YSvM6hvDun = this;
			this.SaJ1J3Tac0.Font = (this.Q4q1hb8iU8.Font = (this.hGr10Itn8r.Font = StyleManager.GetMainFont(8.25f)));
			this.SY61wv959Y.Font = (this.qkc1mdcGNq.Font = (this.X1y1X0lluq.Font = (this.Abb12SSsH2.Font = StyleManager.GetMainFont(7.25f))));
			this.LH711m4nqc.Font = (this.I7h1bkVyu9.Font = StyleManager.GetMainFont(8.65f));
			string systemIconFont = StyleManager.GetSystemIconFont();
			if (this.cw115lVbpK != null)
			{
				this.cw115lVbpK.Text = "";
				this.cw115lVbpK.Image = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-529730567 ^ -318230248 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3423fe0bd378445e9a426e728c08b0d3), systemIconFont, 12f, Color.White, 20, 0, 2);
				this.cw115lVbpK.ImageAlign = ContentAlignment.MiddleCenter;
			}
			if (this.GTL1jrPtBB != null)
			{
				this.GTL1jrPtBB.Text = "";
				this.GTL1jrPtBB.Image = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1084619761 ^ -696034177 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_bcad499d901540f895e61fc7be5dbf2b), systemIconFont, 12f, Color.White, 20, 0, 6);
				this.GTL1jrPtBB.ImageAlign = ContentAlignment.MiddleCenter;
			}
			if (this.MLK1SmC0fp != null)
			{
				this.MLK1SmC0fp.Text = "";
				this.MLK1SmC0fp.Image = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1067281372 ^ -1529068098 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1c66e07149574924b7cd3da5aa89d5a4), systemIconFont, 11f, Color.White, 20, 1, 1);
				this.MLK1SmC0fp.ImageAlign = ContentAlignment.MiddleCenter;
			}
			if (this.HFF1Td7WHu != null)
			{
				this.HFF1Td7WHu.Text = "";
				this.HFF1Td7WHu.Image = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1727091913 << 3 ^ 150921591 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410), systemIconFont, 11f, Color.White, 20, 1, 1);
				this.HFF1Td7WHu.ImageAlign = ContentAlignment.MiddleCenter;
			}
			if (this.Rkd1ZHfnT8 != null)
			{
				this.Rkd1ZHfnT8.Font = this.SaJ1J3Tac0.Font;
				this.Rkd1ZHfnT8.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(582215781 ^ 1016633898 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562)) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~1397486621 ^ -683292770 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0);
				this.Rkd1ZHfnT8.Image = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1397297908 ^ 359833027 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e), systemIconFont, 11f, Color.White, 22, 0, 0);
				this.Rkd1ZHfnT8.TextImageRelation = TextImageRelation.TextBeforeImage;
				this.Rkd1ZHfnT8.ImageAlign = ContentAlignment.MiddleRight;
				this.Rkd1ZHfnT8.TextAlign = ContentAlignment.MiddleCenter;
			}
			if (this.Oij1MLZ0nH != null)
			{
				this.Oij1MLZ0nH.Text = "";
				CS$<>8__locals1.vcSMOqB8jx = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2107463719 ^ 283409493 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b), systemIconFont, 11f, Color.White, 20, 2, 3);
				this.Oij1MLZ0nH.Image = CS$<>8__locals1.vcSMOqB8jx;
				this.Oij1MLZ0nH.ImageAlign = ContentAlignment.MiddleCenter;
				if (this.bNexneFwHF == null)
				{
					CS$<>8__locals1.CYxMffZMTQ = 0f;
					this.bNexneFwHF = new Timer
					{
						Interval = 8
					};
					this.bNexneFwHF.Tick += CS$<>8__locals1.EtaMlFq50k;
					this.Oij1MLZ0nH.MouseEnter += CS$<>8__locals1.d34MVSBZti;
					this.Oij1MLZ0nH.MouseLeave += CS$<>8__locals1.ERUMDa0Y9Z;
				}
			}
			if (this.f6M1CAxqn9 != null)
			{
				this.f6M1CAxqn9.Font = this.SaJ1J3Tac0.Font;
				this.f6M1CAxqn9.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -161383548 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e)) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1163144385 ^ 692487018 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264);
				this.f6M1CAxqn9.Image = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1101117538 + -804724488 ^ 268752474 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b), systemIconFont, 12f, Color.White, 22, 0, 0);
				this.f6M1CAxqn9.TextImageRelation = TextImageRelation.TextBeforeImage;
				this.f6M1CAxqn9.ImageAlign = ContentAlignment.MiddleRight;
				this.f6M1CAxqn9.TextAlign = ContentAlignment.MiddleCenter;
			}
			if (this.DTS1N5UREm != null)
			{
				this.DTS1N5UREm.Text = "";
				this.DTS1N5UREm.ImageAlign = ContentAlignment.MiddleCenter;
				this.dsJxxJWth4(this.wjoxuFLUbn);
			}
			if (this.rS71BwocEN != null)
			{
				this.rS71BwocEN.Text = "";
				this.rS71BwocEN.ImageAlign = ContentAlignment.MiddleCenter;
				this.rS71BwocEN.Image = StyleManager.IconToBitmap(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1822672301 ^ -31121707 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b), systemIconFont, 10.75f, Color.White, 20, 1, 2);
			}
		}

		// Token: 0x060002BB RID: 699 RVA: 0x00011740 File Offset: 0x0000F940
		private void GvDJWsZO6k()
		{
			AppSettings settings = SettingsManager.Settings;
			this.qkc1mdcGNq.Checked = settings.RussianPath;
			this.X1y1X0lluq.Checked = settings.OnlineFixEnabled;
			this.Abb12SSsH2.Checked = settings.VirtualEnabled;
			this.OQOJn8XVh0();
		}

		// Token: 0x060002BC RID: 700 RVA: 0x0001178C File Offset: 0x0000F98C
		private void N7qJecMmSO(object \u0020, EventArgs \u0020)
		{
			MessageOverlay.ShowAccountManager(this, this.CmkxF65BH2, new Action(this.plBxgOBHCg));
		}

		// Token: 0x060002BD RID: 701 RVA: 0x000117A8 File Offset: 0x0000F9A8
		private void OQOJn8XVh0()
		{
			AppSettings settings = SettingsManager.Settings;
			if (string.IsNullOrEmpty(settings.SelectedProfileId) && string.IsNullOrEmpty(settings.Nickname))
			{
				this.I7h1bkVyu9.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1577388857 >> 1 ^ -425957279 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df);
			}
			else
			{
				this.I7h1bkVyu9.Text = settings.Nickname;
			}
			this.eLAJUYwbY5(this.I7h1bkVyu9.Text);
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00011830 File Offset: 0x0000FA30
		private void z2gJ3uTK3M(object \u0020, MouseEventArgs \u0020)
		{
			if (\u0020.Button == MouseButtons.Right)
			{
				this.x1A1t8whsW.Show(Cursor.Position);
			}
		}

		// Token: 0x060002BF RID: 703 RVA: 0x00011854 File Offset: 0x0000FA54
		private void xCOJLPZFPF(object \u0020, EventArgs \u0020)
		{
			Tray.Hide(this, this.nKS1GlWP6n);
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x00011864 File Offset: 0x0000FA64
		private void vgQJIAx2HL(object \u0020, EventArgs \u0020)
		{
			Application.Exit();
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x0001186C File Offset: 0x0000FA6C
		private void aW9JR6Gn6I(object \u0020, EventArgs \u0020)
		{
			Application.Exit();
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x00011874 File Offset: 0x0000FA74
		private void eqDJa8lq8x(object \u0020, LinkLabelLinkClickedEventArgs \u0020)
		{
			Main.<updateCheck_LinkClicked>d__35 <updateCheck_LinkClicked>d__;
			<updateCheck_LinkClicked>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<updateCheck_LinkClicked>d__.<>4__this = this;
			<updateCheck_LinkClicked>d__.<>1__state = -1;
			<updateCheck_LinkClicked>d__.<>t__builder.Start<Main.<updateCheck_LinkClicked>d__35>(ref <updateCheck_LinkClicked>d__);
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x000118AC File Offset: 0x0000FAAC
		private void D2QJzMBMIt(object \u0020, EventArgs \u0020)
		{
			if (this.LH711m4nqc.SelectedItem != null && this.qf6xO3gdmw != null)
			{
				string text = this.LH711m4nqc.SelectedItem.ToString();
				VersionDataInternal versionDataInternal;
				if (this.qf6xO3gdmw.TryGetValue(text, out versionDataInternal))
				{
					this.hGr10Itn8r.Text = versionDataInternal.Name + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -1259435352 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a) + versionDataInternal.Date;
					SettingsManager.Settings.SelectedVersionName = text;
					SettingsManager.Save();
				}
			}
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x00011948 File Offset: 0x0000FB48
		private void CPvx8fDhCw(object \u0020, EventArgs \u0020)
		{
			SettingsManager.Settings.RussianPath = this.qkc1mdcGNq.Checked;
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x00011960 File Offset: 0x0000FB60
		private void Q45xhmicgM(object \u0020, EventArgs \u0020)
		{
			SettingsManager.Settings.OnlineFixEnabled = this.X1y1X0lluq.Checked;
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x00011978 File Offset: 0x0000FB78
		private void Hb2xk5MwHM(object \u0020, EventArgs \u0020)
		{
			SettingsManager.Settings.VirtualEnabled = this.Abb12SSsH2.Checked;
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x00011990 File Offset: 0x0000FB90
		private void nkfxwlaa7g(object \u0020, EventArgs \u0020)
		{
			this.fM8xJ07PoT(!this.wjoxuFLUbn);
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x000119A4 File Offset: 0x0000FBA4
		private void ogixbOuuit(bool \u0020, bool \u0020)
		{
			this.wjoxuFLUbn = \u0020;
			if (!\u0020)
			{
				this.oqb1s1mNQr.Left = (\u0020 ? this.nbgxEDL3GM : this.A40xvwHqfS);
				this.dsJxxJWth4(\u0020);
				return;
			}
			this.fM8xJ07PoT(\u0020);
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x000119E4 File Offset: 0x0000FBE4
		private void fM8xJ07PoT(bool \u0020)
		{
			Main.<>c__DisplayClass42_0 CS$<>8__locals1 = new Main.<>c__DisplayClass42_0();
			CS$<>8__locals1.I9DMEBWAN9 = this;
			CS$<>8__locals1.SuiMpttDf5 = \u0020;
			if (this.tHbxUMsubx != null)
			{
				this.tHbxUMsubx.Stop();
				this.tHbxUMsubx.Dispose();
				this.tHbxUMsubx = null;
			}
			CS$<>8__locals1.YQ6MuBW4Eq = this.oqb1s1mNQr.Left;
			CS$<>8__locals1.RZAMvDMEhp = (CS$<>8__locals1.SuiMpttDf5 ? this.nbgxEDL3GM : this.A40xvwHqfS);
			if (CS$<>8__locals1.YQ6MuBW4Eq == CS$<>8__locals1.RZAMvDMEhp)
			{
				this.wjoxuFLUbn = CS$<>8__locals1.SuiMpttDf5;
				this.dsJxxJWth4(CS$<>8__locals1.SuiMpttDf5);
				return;
			}
			CS$<>8__locals1.R37MUXV8pO = Stopwatch.StartNew();
			this.tHbxUMsubx = new Timer
			{
				Interval = 1
			};
			this.tHbxUMsubx.Tick += CS$<>8__locals1.VoGMiSAk1L;
			this.tHbxUMsubx.Start();
		}

		// Token: 0x060002CA RID: 714 RVA: 0x00011ACC File Offset: 0x0000FCCC
		private void dsJxxJWth4(bool \u0020)
		{
			if (this.DTS1N5UREm == null)
			{
				return;
			}
			string systemIconFont = StyleManager.GetSystemIconFont();
			string icon = \u0020 ? yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -1196889808 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20) : yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1006549809 >> 1 ^ -2119521193 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a47c6b8b4ef4b4fb7822db54ad2e527);
			this.DTS1N5UREm.Image = StyleManager.IconToBitmap(icon, systemIconFont, 12f, Color.White, 20, -1, 1);
		}

		// Token: 0x060002CB RID: 715 RVA: 0x00011B5C File Offset: 0x0000FD5C
		private void vgpx1nJWoT(object \u0020, EventArgs \u0020)
		{
			Main.<play_Click>d__44 <play_Click>d__;
			<play_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<play_Click>d__.<>4__this = this;
			<play_Click>d__.<>1__state = -1;
			<play_Click>d__.<>t__builder.Start<Main.<play_Click>d__44>(ref <play_Click>d__);
		}

		// Token: 0x060002CC RID: 716 RVA: 0x00011B94 File Offset: 0x0000FD94
		private Task Wtqx0ct7dY(bool \u0020 = false)
		{
			Main.<StartGame>d__45 <StartGame>d__;
			<StartGame>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<StartGame>d__.<>4__this = this;
			<StartGame>d__.fromTray = \u0020;
			<StartGame>d__.<>1__state = -1;
			<StartGame>d__.<>t__builder.Start<Main.<StartGame>d__45>(ref <StartGame>d__);
			return <StartGame>d__.<>t__builder.Task;
		}

		// Token: 0x060002CD RID: 717 RVA: 0x00011BE0 File Offset: 0x0000FDE0
		private void LGJxXoOb7b(object \u0020, EventArgs \u0020)
		{
			try
			{
				string text = PathHelper.Combine(new string[]
				{
					RJG3u8JZLa1autEARgF.METJ4myejd,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1406576133 >> 4 ^ -883551192 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20)
				});
				if (!PathHelper.DirectoryExists(text))
				{
					this.Q4q1hb8iU8.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-693780468 ^ -372116195 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410));
				}
				else
				{
					Process.Start(text);
				}
			}
			catch (Exception ex)
			{
				this.Q4q1hb8iU8.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-917748829 ^ -1217247567 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25)) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 1841877241 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25) + ex.Message;
			}
		}

		// Token: 0x060002CE RID: 718 RVA: 0x00011CDC File Offset: 0x0000FEDC
		private void B9XxjdLMMT(object \u0020, DragEventArgs \u0020)
		{
			if (\u0020.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string[] array = (string[])\u0020.Data.GetData(DataFormats.FileDrop);
				if (array.Length != 0 && Path.GetExtension(array[0]).ToLower() == yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--132453396 ^ 660050890 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_52dac0565f7f422e80cc0f27df2b90e5))
				{
					\u0020.Effect = DragDropEffects.Copy;
					this.QI9xMN5yLX(true);
				}
			}
		}

		// Token: 0x060002CF RID: 719 RVA: 0x00011D5C File Offset: 0x0000FF5C
		private void oJ3x5ToIMy(object \u0020, DragEventArgs \u0020)
		{
			this.QI9xMN5yLX(false);
			string[] array = (string[])\u0020.Data.GetData(DataFormats.FileDrop);
			if (array.Length != 0)
			{
				this.Nb2xZO8IdU(array[0]);
			}
		}

		// Token: 0x060002D0 RID: 720 RVA: 0x00011D98 File Offset: 0x0000FF98
		private void tNlxycQ2Qm(object \u0020, EventArgs \u0020)
		{
			this.QI9xMN5yLX(false);
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x00011DA4 File Offset: 0x0000FFA4
		private void Nb2xZO8IdU(string \u0020)
		{
			Main.PluginManifest pluginManifest = this.Aqjx2R1Mtq(\u0020);
			if (pluginManifest == null)
			{
				this.Q4q1hb8iU8.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -1543613921 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4));
				return;
			}
			string u = null;
			Main.PluginManifest pluginManifest2 = null;
			if (PathHelper.DirectoryExists(Main.UBNxamdXSV))
			{
				string b = this.hWnxmVJBl2(\u0020);
				foreach (string text in PathHelper.GetFiles(Main.UBNxamdXSV, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-529730567 ^ -1684201081 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0), SearchOption.TopDirectoryOnly))
				{
					if (this.hWnxmVJBl2(text) == b)
					{
						u = text;
						pluginManifest2 = this.Aqjx2R1Mtq(text);
						break;
					}
				}
			}
			if (pluginManifest2 != null)
			{
				string a = yNhAJGXiuLnPpwrVl1j.xEuXElSa2T(\u0020);
				string b2 = yNhAJGXiuLnPpwrVl1j.xEuXElSa2T(u);
				if (pluginManifest.Version == pluginManifest2.Version && a == b2)
				{
					MessageOverlay.ShowMessage(this, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1822672301 ^ -1409484904 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7)).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-907199388 - -1774585445 ^ 1965739752 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed), pluginManifest.Name), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -1625428503 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8)).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-583370756 + -1440598365 ^ -1650749681 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), pluginManifest.Version), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(598276251 ^ 2026152737 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967)), null);
					return;
				}
			}
			this.pDhxKs1xEu(pluginManifest, \u0020, u, pluginManifest2, null);
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00011F80 File Offset: 0x00010180
		private void QI9xMN5yLX(bool \u0020)
		{
			if (\u0020)
			{
				this.BackgroundImage = Resources.clear_background;
				if (this.UlQxIj8Dtx == null)
				{
					this.UlQxIj8Dtx = new Label
					{
						Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -1994428431 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3)),
						Font = StyleManager.GetMainFont(14f),
						TextAlign = ContentAlignment.MiddleCenter,
						BackColor = Color.FromArgb(140, 0, 0, 0),
						ForeColor = Color.White,
						Dock = DockStyle.Fill,
						Cursor = Cursors.Default
					};
					base.Controls.Add(this.UlQxIj8Dtx);
				}
				this.UlQxIj8Dtx.Visible = true;
				this.UlQxIj8Dtx.BringToFront();
				return;
			}
			this.BackgroundImage = Resources.background;
			if (this.UlQxIj8Dtx != null)
			{
				this.UlQxIj8Dtx.Visible = false;
			}
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x00012070 File Offset: 0x00010270
		private void IF9xCvs1JU(object \u0020, EventArgs \u0020)
		{
			using (Settings settings = new Settings(this))
			{
				settings.ShowDialog(this);
			}
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x000120B0 File Offset: 0x000102B0
		private void lZQxSlLvwO(object \u0020, EventArgs \u0020)
		{
			Process.Start(new ProcessStartInfo(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(326126308 >> 6 ^ 1483485534 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a))
			{
				UseShellExecute = true
			});
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x000120E8 File Offset: 0x000102E8
		private void p1WxthUMui(object \u0020, EventArgs \u0020)
		{
			SettingsManager.Save();
			if (this.dpmxRVtaPi == null || this.dpmxRVtaPi.IsDisposed)
			{
				this.dpmxRVtaPi = new ConsoleForm();
				this.dpmxRVtaPi.Show();
				return;
			}
			this.dpmxRVtaPi.BringToFront();
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x00012138 File Offset: 0x00010338
		private void YQ2xcvIb2n()
		{
			Main.<UpdateAsync>d__58 <UpdateAsync>d__;
			<UpdateAsync>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<UpdateAsync>d__.<>4__this = this;
			<UpdateAsync>d__.<>1__state = -1;
			<UpdateAsync>d__.<>t__builder.Start<Main.<UpdateAsync>d__58>(ref <UpdateAsync>d__);
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x00012170 File Offset: 0x00010370
		private string hWnxmVJBl2(string \u0020)
		{
			return Regex.Replace(Path.GetFileNameWithoutExtension(\u0020), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-225059726 ^ -1943419301 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbea00432075407aa72d35bfa93254e3), "", RegexOptions.IgnoreCase).ToLower();
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x000121A4 File Offset: 0x000103A4
		private void pDhxKs1xEu(Main.PluginManifest \u0020, string \u0020, string \u0020 = null, Main.PluginManifest \u0020 = null, string \u0020 = null)
		{
			Main.<>c__DisplayClass61_0 CS$<>8__locals1 = new Main.<>c__DisplayClass61_0();
			CS$<>8__locals1.dLrMRfsSDH = \u0020;
			CS$<>8__locals1.asrMarKVbB = \u0020;
			CS$<>8__locals1.CttMzDb9Yk = this;
			CS$<>8__locals1.D84MIXqE2g = (\u0020 != null);
			bool flag = CS$<>8__locals1.asrMarKVbB == null;
			string title;
			string message;
			string text;
			if (flag)
			{
				title = \u0020.Name;
				message = \u0020.Description;
				text = (\u0020 ?? i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1084619761 ^ -588222055 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a47c6b8b4ef4b4fb7822db54ad2e527)));
			}
			else if (CS$<>8__locals1.D84MIXqE2g)
			{
				title = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2041937264 ^ -1723761877 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3)).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578000518 << 2 ^ -1969037017 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3423fe0bd378445e9a426e728c08b0d3), \u0020.Name);
				message = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(339415119 ^ 799567894 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790)).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(598276251 ^ 1017324914 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3), \u0020.Version).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-693780468 ^ -865944382 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), \u0020.Version);
				text = (\u0020 ?? i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~515955376 ^ -1035324770 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62)));
			}
			else
			{
				title = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2039334965 ^ -736974041 ^ -1897237265 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62)).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1556297093 ^ 855503408 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c), \u0020.Name);
				message = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1441071425 ^ -773107331 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0)).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -1619186038 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a), \u0020.Name).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-529730567 ^ -1021731382 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62), \u0020.Version).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -931891104 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1), \u0020.Description);
				text = (\u0020 ?? i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1984943586 ^ 813131927 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70)));
			}
			if (flag)
			{
				MessageOverlay.ShowMessage(this, title, message, text, null);
				return;
			}
			MessageOverlay.ShowModInstall(this, title, message, text, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1139840332 ^ 1023687758 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0)), new Action(CS$<>8__locals1.sUwMLBwVIp), null);
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x00012478 File Offset: 0x00010678
		private Main.PluginManifest Aqjx2R1Mtq(string \u0020)
		{
			Main.PluginManifest result;
			try
			{
				using (ZipArchive zipArchive = PathHelper.OpenZipRead(\u0020))
				{
					ZipArchiveEntry entry = zipArchive.GetEntry(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-551092600 ^ 1412615215 ^ -751468420 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a));
					if (entry == null)
					{
						result = null;
					}
					else
					{
						using (StreamReader streamReader = new StreamReader(entry.Open()))
						{
							result = JsonConvert.DeserializeObject<Main.PluginManifest>(streamReader.ReadToEnd());
						}
					}
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060002DA RID: 730 RVA: 0x0001252C File Offset: 0x0001072C
		private void e8GxrV9AxY(object \u0020, EventArgs \u0020)
		{
			string fileName = Process.GetCurrentProcess().MainModule.FileName;
			string fileName2 = Path.GetFileName(fileName);
			string directoryName = Path.GetDirectoryName(fileName);
			if (fileName2.ToLower().Contains(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1363603166 ^ -1742123949 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0)))
			{
				return;
			}
			string text = Path.GetFileNameWithoutExtension(fileName) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(198208080 ^ 1134310605 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3) + Path.GetExtension(fileName);
			string text2 = PathHelper.Combine(new string[]
			{
				directoryName,
				text
			});
			yNhAJGXiuLnPpwrVl1j.BsjXuMVO9f(string.Concat(new string[]
			{
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1367514771 ^ -159211016 ^ 14562126 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a),
				fileName2,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -821761612 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70),
				fileName,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(759808410 ^ 179595895 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3),
				text,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--238918963 ^ 1786800002 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d),
				text2,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -266378392 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7)
			}), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(575497718 << 5 ^ 255160171 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed));
		}

		// Token: 0x060002DB RID: 731 RVA: 0x000126AC File Offset: 0x000108AC
		private void PXxxNQnnW4(object \u0020, EventArgs \u0020)
		{
			SettingsManager.Reset();
			string fileName = Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);
			yNhAJGXiuLnPpwrVl1j.BsjXuMVO9f(string.Concat(new string[]
			{
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1366522423 ^ -567106786 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add),
				fileName,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--132453396 ^ 1811392253 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264),
				fileName,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -1408732422 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f)
			}), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(931021470 ^ 116032139 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20));
		}

		// Token: 0x060002DC RID: 732 RVA: 0x0001276C File Offset: 0x0001096C
		private void HAjxs6ETR8(object \u0020, EventArgs \u0020)
		{
			if (!Main.zdmx6d1IAa)
			{
				MessageOverlay.ShowSupportOverlay(this, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-352509668 ^ -1396258726 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1163144385 ^ 1157236111 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -543078051 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-585837924 ^ -427315695 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-511847524 ^ -454508312 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a1f1dffb08f44e581e0c0e6fac695b4)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-382924511 ^ -936441951 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8fc27a48c0ce461586dd8068b3daaced)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-704542734 ^ -156014118 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_52dac0565f7f422e80cc0f27df2b90e5)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1877665038 - 1504633712 ^ 395454356 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1477603883 ^ -706166947 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0)), new Action<string>(this.E9VxlmVqPo), new Action(Main.<>c.QkSMmxACsq.iwnMc0sWNa));
				return;
			}
			MessageOverlay.ShowMessage(this, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1084619761 ^ -1516432403 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-529730567 ^ -1732992994 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770)), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1727091913 << 3 ^ 1907516463 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70), null);
		}

		// Token: 0x060002DD RID: 733 RVA: 0x0001294C File Offset: 0x00010B4C
		private Task<LocalServer> E1IxHa1QwS(string \u0020)
		{
			Main.<SetupServer>d__66 <SetupServer>d__;
			<SetupServer>d__.<>t__builder = AsyncTaskMethodBuilder<LocalServer>.Create();
			<SetupServer>d__.<>4__this = this;
			<SetupServer>d__.username = \u0020;
			<SetupServer>d__.<>1__state = -1;
			<SetupServer>d__.<>t__builder.Start<Main.<SetupServer>d__66>(ref <SetupServer>d__);
			return <SetupServer>d__.<>t__builder.Task;
		}

		// Token: 0x060002DE RID: 734 RVA: 0x00012998 File Offset: 0x00010B98
		private void j8yx4aKtmA(object \u0020, MouseEventArgs \u0020)
		{
			if (\u0020.Button == MouseButtons.Left)
			{
				Tray.Show(this, this.nKS1GlWP6n);
				return;
			}
			if (\u0020.Button == MouseButtons.Middle)
			{
				this.Wtqx0ct7dY(true);
				return;
			}
			if (\u0020.Button == MouseButtons.Right)
			{
				Application.Exit();
			}
		}

		// Token: 0x060002DF RID: 735 RVA: 0x000129F0 File Offset: 0x00010BF0
		private void n0cxGhSdmN(object \u0020, EventArgs \u0020)
		{
			Main.<cleanMemory_Click>d__68 <cleanMemory_Click>d__;
			<cleanMemory_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<cleanMemory_Click>d__.<>4__this = this;
			<cleanMemory_Click>d__.<>1__state = -1;
			<cleanMemory_Click>d__.<>t__builder.Start<Main.<cleanMemory_Click>d__68>(ref <cleanMemory_Click>d__);
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x00012A28 File Offset: 0x00010C28
		public Task RepairGame()
		{
			Main.<RepairGame>d__69 <RepairGame>d__;
			<RepairGame>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<RepairGame>d__.<>4__this = this;
			<RepairGame>d__.<>1__state = -1;
			<RepairGame>d__.<>t__builder.Start<Main.<RepairGame>d__69>(ref <RepairGame>d__);
			return <RepairGame>d__.<>t__builder.Task;
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x00012A94 File Offset: 0x00010C94
		private void e4dxTkglkD()
		{
			this.s88xztVemL = new Container();
			CustomTextBoxColorScheme customTextBoxColorScheme = new CustomTextBoxColorScheme();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Main));
			this.GTL1jrPtBB = new CustomButton();
			this.cw115lVbpK = new CustomButton();
			this.o7O1yRJB3K = new CustomButton();
			this.yx818kJA68 = new Panel();
			this.Oij1MLZ0nH = new CustomButton();
			this.SaJ1J3Tac0 = new Label();
			this.mbv1xj0auj = new PictureBox();
			this.GHn1kSMykE = new LinkLabel();
			this.Q4q1hb8iU8 = new Label();
			this.SY61wv959Y = new Label();
			this.hGr10Itn8r = new Label();
			this.LH711m4nqc = new CustomComboBox();
			this.I7h1bkVyu9 = new CustomTextBox();
			this.X1y1X0lluq = new CustomCheckBox();
			this.Rkd1ZHfnT8 = new CustomButton();
			this.f6M1CAxqn9 = new CustomButton();
			this.MLK1SmC0fp = new CustomButton();
			this.x1A1t8whsW = new ContextMenuStrip(this.s88xztVemL);
			this.oUB1cv1mHR = new ToolStripMenuItem();
			this.KA91KR1HT3 = new ToolStripMenuItem();
			this.G9V14qXxIv = new ToolStripMenuItem();
			this.qkc1mdcGNq = new CustomCheckBox();
			this.Abb12SSsH2 = new CustomCheckBox();
			this.btX1rOiDVU = new CustomProgressBar();
			this.DTS1N5UREm = new CustomButton();
			this.oqb1s1mNQr = new Panel();
			this.CeT1HYBqh5 = new PictureBox();
			this.nKS1GlWP6n = new NotifyIcon(this.s88xztVemL);
			this.HFF1Td7WHu = new CustomButton();
			this.rS71BwocEN = new CustomButton();
			this.yx818kJA68.SuspendLayout();
			((ISupportInitialize)this.mbv1xj0auj).BeginInit();
			this.x1A1t8whsW.SuspendLayout();
			this.oqb1s1mNQr.SuspendLayout();
			((ISupportInitialize)this.CeT1HYBqh5).BeginInit();
			base.SuspendLayout();
			this.GTL1jrPtBB.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.GTL1jrPtBB.BackColor = Color.Transparent;
			this.GTL1jrPtBB.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.GTL1jrPtBB.FlatAppearance.BorderSize = 0;
			this.GTL1jrPtBB.FlatAppearance.MouseDownBackColor = Color.Transparent;
			this.GTL1jrPtBB.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.GTL1jrPtBB.FlatStyle = FlatStyle.Flat;
			this.GTL1jrPtBB.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-752914475 ^ -1592117513 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0), 22f, FontStyle.Bold);
			this.GTL1jrPtBB.ForeColor = SystemColors.ControlDarkDark;
			this.GTL1jrPtBB.Location = new Point(952, 0);
			this.GTL1jrPtBB.Margin = new Padding(0);
			this.GTL1jrPtBB.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--1651549092 ^ 1424031631 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0);
			this.GTL1jrPtBB.Size = new Size(30, 30);
			this.GTL1jrPtBB.TabIndex = 0;
			this.GTL1jrPtBB.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-34176907 ^ -644486198 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8);
			this.GTL1jrPtBB.UseVisualStyleBackColor = false;
			this.GTL1jrPtBB.Click += this.xCOJLPZFPF;
			this.cw115lVbpK.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.cw115lVbpK.BackColor = Color.Transparent;
			this.cw115lVbpK.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.cw115lVbpK.FlatAppearance.BorderSize = 0;
			this.cw115lVbpK.FlatAppearance.MouseDownBackColor = Color.Transparent;
			this.cw115lVbpK.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.cw115lVbpK.FlatStyle = FlatStyle.Flat;
			this.cw115lVbpK.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1699465266 ^ -755472343 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3), 12f, FontStyle.Bold);
			this.cw115lVbpK.ForeColor = SystemColors.ControlDarkDark;
			this.cw115lVbpK.Location = new Point(988, 0);
			this.cw115lVbpK.Margin = new Padding(0);
			this.cw115lVbpK.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1283755699 ^ -1494078777 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a);
			this.cw115lVbpK.Size = new Size(30, 30);
			this.cw115lVbpK.TabIndex = 1;
			this.cw115lVbpK.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1037188186 + 1115589290 ^ -1636041189 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562);
			this.cw115lVbpK.UseVisualStyleBackColor = false;
			this.cw115lVbpK.Click += this.vgQJIAx2HL;
			this.o7O1yRJB3K.BackColor = Color.FromArgb(50, 110, 160);
			this.o7O1yRJB3K.DisabledForeColor = Color.FromArgb(30, 30, 30);
			this.o7O1yRJB3K.FlatAppearance.BorderColor = Color.FromArgb(60, 140, 200);
			this.o7O1yRJB3K.FlatAppearance.BorderSize = 2;
			this.o7O1yRJB3K.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 160, 230);
			this.o7O1yRJB3K.FlatStyle = FlatStyle.Flat;
			this.o7O1yRJB3K.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-866207546 ^ -749389521 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3), 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.o7O1yRJB3K.ForeColor = Color.FromArgb(215, 228, 242);
			this.o7O1yRJB3K.Location = new Point(138, 334);
			this.o7O1yRJB3K.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1084619761 ^ -676405772 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc);
			this.o7O1yRJB3K.Size = new Size(124, 40);
			this.o7O1yRJB3K.TabIndex = 2;
			this.o7O1yRJB3K.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(723568593 ^ 691194596 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb);
			this.o7O1yRJB3K.UseVisualStyleBackColor = false;
			this.o7O1yRJB3K.Click += this.vgpx1nJWoT;
			this.yx818kJA68.Anchor = AnchorStyles.Top;
			this.yx818kJA68.BackColor = Color.Transparent;
			this.yx818kJA68.Controls.Add(this.Oij1MLZ0nH);
			this.yx818kJA68.Controls.Add(this.SaJ1J3Tac0);
			this.yx818kJA68.Controls.Add(this.mbv1xj0auj);
			this.yx818kJA68.Controls.Add(this.GHn1kSMykE);
			this.yx818kJA68.ForeColor = Color.Transparent;
			this.yx818kJA68.Location = new Point(0, 0);
			this.yx818kJA68.Margin = new Padding(0);
			this.yx818kJA68.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1139840332 ^ 780776424 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b);
			this.yx818kJA68.Size = new Size(1026, 30);
			this.yx818kJA68.TabIndex = 3;
			this.Oij1MLZ0nH.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.Oij1MLZ0nH.BackColor = Color.Transparent;
			this.Oij1MLZ0nH.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.Oij1MLZ0nH.FlatAppearance.BorderSize = 0;
			this.Oij1MLZ0nH.FlatAppearance.MouseDownBackColor = Color.Transparent;
			this.Oij1MLZ0nH.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.Oij1MLZ0nH.FlatStyle = FlatStyle.Flat;
			this.Oij1MLZ0nH.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -421084091 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264), 12f, FontStyle.Bold);
			this.Oij1MLZ0nH.ForeColor = SystemColors.ControlDarkDark;
			this.Oij1MLZ0nH.Location = new Point(916, 0);
			this.Oij1MLZ0nH.Margin = new Padding(0);
			this.Oij1MLZ0nH.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2107463719 ^ 283410067 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b);
			this.Oij1MLZ0nH.Size = new Size(30, 30);
			this.Oij1MLZ0nH.TabIndex = 19;
			this.Oij1MLZ0nH.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 1273008326 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e);
			this.Oij1MLZ0nH.UseVisualStyleBackColor = false;
			this.Oij1MLZ0nH.Click += this.IF9xCvs1JU;
			this.SaJ1J3Tac0.Anchor = AnchorStyles.Left;
			this.SaJ1J3Tac0.AutoSize = true;
			this.SaJ1J3Tac0.Location = new Point(28, 10);
			this.SaJ1J3Tac0.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1414349225 >> 4 ^ 67831910 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_63317b19592040989f1b836b90b41752);
			this.SaJ1J3Tac0.Size = new Size(60, 13);
			this.SaJ1J3Tac0.TabIndex = 12;
			this.SaJ1J3Tac0.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1363603166 ^ -796453136 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25);
			this.mbv1xj0auj.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
			this.mbv1xj0auj.Location = new Point(9, 7);
			this.mbv1xj0auj.Margin = new Padding(0);
			this.mbv1xj0auj.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1363603166 ^ -1742123587 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0);
			this.mbv1xj0auj.Size = new Size(16, 16);
			this.mbv1xj0auj.TabIndex = 11;
			this.mbv1xj0auj.TabStop = false;
			this.mbv1xj0auj.DoubleClick += this.aW9JR6Gn6I;
			this.mbv1xj0auj.MouseClick += this.z2gJ3uTK3M;
			this.GHn1kSMykE.ActiveLinkColor = Color.Gainsboro;
			this.GHn1kSMykE.AutoSize = true;
			this.GHn1kSMykE.LinkColor = Color.Silver;
			this.GHn1kSMykE.Location = new Point(256, 9);
			this.GHn1kSMykE.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1315026565 ^ 2013323623 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df);
			this.GHn1kSMykE.Size = new Size(125, 13);
			this.GHn1kSMykE.TabIndex = 1;
			this.GHn1kSMykE.TabStop = true;
			this.GHn1kSMykE.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2132757131 ^ -401331298 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc);
			this.GHn1kSMykE.VisitedLinkColor = Color.Silver;
			this.GHn1kSMykE.LinkClicked += this.eqDJa8lq8x;
			this.Q4q1hb8iU8.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
			this.Q4q1hb8iU8.AutoSize = true;
			this.Q4q1hb8iU8.BackColor = Color.Transparent;
			this.Q4q1hb8iU8.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1441071425 ^ -1327660105 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), 8.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.Q4q1hb8iU8.ForeColor = Color.White;
			this.Q4q1hb8iU8.Location = new Point(137, 378);
			this.Q4q1hb8iU8.MaximumSize = new Size(126, 160);
			this.Q4q1hb8iU8.MinimumSize = new Size(126, 20);
			this.Q4q1hb8iU8.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(432533716 ^ 109210772 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7);
			this.Q4q1hb8iU8.Size = new Size(126, 20);
			this.Q4q1hb8iU8.TabIndex = 4;
			this.Q4q1hb8iU8.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -564618299 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3);
			this.Q4q1hb8iU8.TextAlign = ContentAlignment.MiddleCenter;
			this.SY61wv959Y.AutoSize = true;
			this.SY61wv959Y.BackColor = Color.Transparent;
			this.SY61wv959Y.ForeColor = Color.Gainsboro;
			this.SY61wv959Y.Location = new Point(140, 260);
			this.SY61wv959Y.MaximumSize = new Size(120, 24);
			this.SY61wv959Y.MinimumSize = new Size(120, 24);
			this.SY61wv959Y.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-361965784 ^ -2074998777 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c);
			this.SY61wv959Y.Size = new Size(120, 24);
			this.SY61wv959Y.TabIndex = 8;
			this.SY61wv959Y.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-551092600 ^ 1412615215 ^ -721956460 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e);
			this.SY61wv959Y.TextAlign = ContentAlignment.BottomCenter;
			this.hGr10Itn8r.AutoSize = true;
			this.hGr10Itn8r.BackColor = Color.Transparent;
			this.hGr10Itn8r.ForeColor = Color.Gainsboro;
			this.hGr10Itn8r.Location = new Point(265, 603);
			this.hGr10Itn8r.MaximumSize = new Size(100, 25);
			this.hGr10Itn8r.MinimumSize = new Size(100, 25);
			this.hGr10Itn8r.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -4313992 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790);
			this.hGr10Itn8r.Size = new Size(100, 25);
			this.hGr10Itn8r.TabIndex = 13;
			this.hGr10Itn8r.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1512690999 ^ -874865109 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156);
			this.hGr10Itn8r.TextAlign = ContentAlignment.BottomRight;
			this.LH711m4nqc.BackColor = Color.FromArgb(50, 110, 160);
			this.LH711m4nqc.DrawMode = DrawMode.OwnerDrawFixed;
			this.LH711m4nqc.DropDownStyle = ComboBoxStyle.DropDownList;
			this.LH711m4nqc.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(339415119 ^ 1715358061 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0), 7.65f);
			this.LH711m4nqc.ForeColor = Color.FromArgb(230, 240, 255);
			this.LH711m4nqc.FormattingEnabled = true;
			this.LH711m4nqc.Location = new Point(138, 310);
			this.LH711m4nqc.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1867100645 ^ -1972292435 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142);
			this.LH711m4nqc.Size = new Size(101, 20);
			this.LH711m4nqc.TabIndex = 12;
			this.LH711m4nqc.SelectedIndexChanged += this.D2QJzMBMIt;
			customTextBoxColorScheme.BackColor = Color.FromArgb(50, 110, 160);
			customTextBoxColorScheme.BorderColor = Color.FromArgb(60, 140, 200);
			customTextBoxColorScheme.CursorColor = Color.FromArgb(255, 255, 255);
			customTextBoxColorScheme.ForeColor = Color.FromArgb(255, 255, 255);
			customTextBoxColorScheme.PlaceholderColor = Color.Empty;
			customTextBoxColorScheme.SelectionColor = Color.FromArgb(100, 255, 255, 255);
			this.I7h1bkVyu9.ColorScheme = customTextBoxColorScheme;
			this.I7h1bkVyu9.Cursor = Cursors.IBeam;
			this.I7h1bkVyu9.Enabled = false;
			this.I7h1bkVyu9.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1814540806 ^ 2041493412 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a), 7.65f);
			this.I7h1bkVyu9.Location = new Point(138, 286);
			this.I7h1bkVyu9.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1815417748 >> 5 ^ 1477283178 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967);
			this.I7h1bkVyu9.PasswordChar = '\0';
			this.I7h1bkVyu9.Placeholder = "";
			this.I7h1bkVyu9.Size = new Size(101, 20);
			this.I7h1bkVyu9.TabIndex = 9;
			this.X1y1X0lluq.BackColor = Color.Transparent;
			this.X1y1X0lluq.Checked = false;
			this.X1y1X0lluq.Cursor = Cursors.Hand;
			this.X1y1X0lluq.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-585837924 ^ -2038913436 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967), 10f);
			this.X1y1X0lluq.ForeColor = Color.FromArgb(230, 240, 255);
			this.X1y1X0lluq.Location = new Point(2, 24);
			this.X1y1X0lluq.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1402547601 ^ -1002203734 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f);
			this.X1y1X0lluq.Size = new Size(121, 24);
			this.X1y1X0lluq.TabIndex = 17;
			this.X1y1X0lluq.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2041937264 ^ -1978417713 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1);
			this.X1y1X0lluq.Click += this.Q45xhmicgM;
			this.Rkd1ZHfnT8.BackColor = Color.FromArgb(50, 110, 160);
			this.Rkd1ZHfnT8.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.Rkd1ZHfnT8.FlatAppearance.BorderColor = Color.FromArgb(60, 140, 200);
			this.Rkd1ZHfnT8.FlatAppearance.BorderSize = 2;
			this.Rkd1ZHfnT8.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 160, 230);
			this.Rkd1ZHfnT8.FlatStyle = FlatStyle.Flat;
			this.Rkd1ZHfnT8.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~234019875 ^ -1698200637 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091), 8.249999f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.Rkd1ZHfnT8.ForeColor = Color.FromArgb(215, 228, 242);
			this.Rkd1ZHfnT8.Location = new Point(12, 598);
			this.Rkd1ZHfnT8.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1951063772 ^ -443826875 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c);
			this.Rkd1ZHfnT8.Size = new Size(138, 30);
			this.Rkd1ZHfnT8.TabIndex = 18;
			this.Rkd1ZHfnT8.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1307286652 - 1848242595 ^ -1041573748 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562);
			this.Rkd1ZHfnT8.UseVisualStyleBackColor = false;
			this.Rkd1ZHfnT8.Click += this.LGJxXoOb7b;
			this.f6M1CAxqn9.BackColor = Color.FromArgb(50, 110, 160);
			this.f6M1CAxqn9.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.f6M1CAxqn9.FlatAppearance.BorderColor = Color.FromArgb(60, 140, 200);
			this.f6M1CAxqn9.FlatAppearance.BorderSize = 2;
			this.f6M1CAxqn9.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 160, 230);
			this.f6M1CAxqn9.FlatStyle = FlatStyle.Flat;
			this.f6M1CAxqn9.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(326126308 >> 6 ^ 1208065664 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3), 8.249999f, FontStyle.Bold);
			this.f6M1CAxqn9.ForeColor = Color.FromArgb(215, 228, 242);
			this.f6M1CAxqn9.Location = new Point(46, 564);
			this.f6M1CAxqn9.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1414349225 >> 4 ^ 82484898 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b);
			this.f6M1CAxqn9.Size = new Size(104, 30);
			this.f6M1CAxqn9.TabIndex = 20;
			this.f6M1CAxqn9.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-164665627 ^ -1707234086 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264);
			this.f6M1CAxqn9.UseVisualStyleBackColor = false;
			this.f6M1CAxqn9.Click += this.lZQxSlLvwO;
			this.MLK1SmC0fp.BackColor = Color.FromArgb(50, 110, 160);
			this.MLK1SmC0fp.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.MLK1SmC0fp.FlatAppearance.BorderColor = Color.FromArgb(60, 140, 200);
			this.MLK1SmC0fp.FlatAppearance.BorderSize = 2;
			this.MLK1SmC0fp.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 160, 230);
			this.MLK1SmC0fp.FlatStyle = FlatStyle.Flat;
			this.MLK1SmC0fp.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 1936131585 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbea00432075407aa72d35bfa93254e3), 8.249999f, FontStyle.Bold);
			this.MLK1SmC0fp.ForeColor = Color.FromArgb(215, 228, 242);
			this.MLK1SmC0fp.Location = new Point(12, 564);
			this.MLK1SmC0fp.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-654387379 >> 4 ^ -490047970 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7);
			this.MLK1SmC0fp.Size = new Size(30, 30);
			this.MLK1SmC0fp.TabIndex = 21;
			this.MLK1SmC0fp.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1812406875 << 5 ^ -286720220 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156);
			this.MLK1SmC0fp.UseVisualStyleBackColor = false;
			this.MLK1SmC0fp.Click += this.p1WxthUMui;
			this.x1A1t8whsW.BackColor = Color.FromArgb(50, 110, 160);
			this.x1A1t8whsW.Items.AddRange(new ToolStripItem[]
			{
				this.oUB1cv1mHR,
				this.KA91KR1HT3,
				this.G9V14qXxIv
			});
			this.x1A1t8whsW.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-361965784 ^ -1014007021 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18);
			this.x1A1t8whsW.ShowImageMargin = false;
			this.x1A1t8whsW.Size = new Size(193, 70);
			this.oUB1cv1mHR.ForeColor = Color.FromArgb(215, 228, 242);
			this.oUB1cv1mHR.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -1726753976 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1d30fd1b0072480a959ab725d2c0b406);
			this.oUB1cv1mHR.Size = new Size(192, 22);
			this.oUB1cv1mHR.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(133603179 ^ 597028748 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8);
			this.oUB1cv1mHR.Click += this.e8GxrV9AxY;
			this.KA91KR1HT3.ForeColor = Color.FromArgb(215, 228, 242);
			this.KA91KR1HT3.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-269698511 ^ -302078370 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb);
			this.KA91KR1HT3.Size = new Size(192, 22);
			this.KA91KR1HT3.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1951063772 ^ -1110150896 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df);
			this.KA91KR1HT3.Click += this.PXxxNQnnW4;
			this.G9V14qXxIv.ForeColor = Color.FromArgb(215, 228, 242);
			this.G9V14qXxIv.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1973790299 ^ 1548094252 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18);
			this.G9V14qXxIv.Size = new Size(192, 22);
			this.G9V14qXxIv.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2039334965 ^ -736974041 ^ -1406047906 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b);
			this.G9V14qXxIv.Click += this.HAjxs6ETR8;
			this.qkc1mdcGNq.BackColor = Color.Transparent;
			this.qkc1mdcGNq.Checked = false;
			this.qkc1mdcGNq.Cursor = Cursors.Hand;
			this.qkc1mdcGNq.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(494588051 << 1 ^ 752109932 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8), 10f);
			this.qkc1mdcGNq.ForeColor = Color.FromArgb(230, 240, 255);
			this.qkc1mdcGNq.Location = new Point(2, 2);
			this.qkc1mdcGNq.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -782575122 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770);
			this.qkc1mdcGNq.Size = new Size(122, 24);
			this.qkc1mdcGNq.TabIndex = 23;
			this.qkc1mdcGNq.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1424072547 ^ 966315049 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b);
			this.qkc1mdcGNq.Click += this.CPvx8fDhCw;
			this.Abb12SSsH2.BackColor = Color.Transparent;
			this.Abb12SSsH2.Checked = false;
			this.Abb12SSsH2.Cursor = Cursors.Hand;
			this.Abb12SSsH2.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-382924511 ^ -2131491467 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_bcad499d901540f895e61fc7be5dbf2b), 10f);
			this.Abb12SSsH2.ForeColor = Color.FromArgb(230, 240, 255);
			this.Abb12SSsH2.Location = new Point(2, 46);
			this.Abb12SSsH2.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(723568593 ^ 889977776 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562);
			this.Abb12SSsH2.Size = new Size(134, 24);
			this.Abb12SSsH2.TabIndex = 24;
			this.Abb12SSsH2.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -1959901868 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb);
			this.Abb12SSsH2.Click += this.Hb2xk5MwHM;
			this.btX1rOiDVU.BackgroundBarColor = Color.FromArgb(220, 30, 30, 30);
			this.btX1rOiDVU.IsMarquee = true;
			this.btX1rOiDVU.Location = new Point(0, 637);
			this.btX1rOiDVU.Maximum = 100;
			this.btX1rOiDVU.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(217283769 ^ 1636458395 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b);
			this.btX1rOiDVU.ProgressColor = Color.FromArgb(0, 128, 255);
			this.btX1rOiDVU.Size = new Size(1026, 3);
			this.btX1rOiDVU.TabIndex = 25;
			this.btX1rOiDVU.Value = 0;
			this.DTS1N5UREm.BackColor = Color.FromArgb(50, 110, 160);
			this.DTS1N5UREm.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.DTS1N5UREm.FlatAppearance.BorderColor = Color.FromArgb(60, 140, 200);
			this.DTS1N5UREm.FlatAppearance.BorderSize = 2;
			this.DTS1N5UREm.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 160, 230);
			this.DTS1N5UREm.FlatStyle = FlatStyle.Flat;
			this.DTS1N5UREm.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2107463719 ^ 220430316 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add), 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.DTS1N5UREm.ForeColor = Color.FromArgb(215, 228, 242);
			this.DTS1N5UREm.Location = new Point(242, 310);
			this.DTS1N5UREm.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1424072547 ^ 1887611464 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8);
			this.DTS1N5UREm.Size = new Size(20, 20);
			this.DTS1N5UREm.TabIndex = 27;
			this.DTS1N5UREm.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578000518 << 2 ^ -14794465 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770);
			this.DTS1N5UREm.UseVisualStyleBackColor = false;
			this.DTS1N5UREm.Click += this.nkfxwlaa7g;
			this.oqb1s1mNQr.BackColor = Color.Transparent;
			this.oqb1s1mNQr.Controls.Add(this.X1y1X0lluq);
			this.oqb1s1mNQr.Controls.Add(this.qkc1mdcGNq);
			this.oqb1s1mNQr.Controls.Add(this.Abb12SSsH2);
			this.oqb1s1mNQr.ForeColor = Color.Transparent;
			this.oqb1s1mNQr.Location = new Point(9, 490);
			this.oqb1s1mNQr.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1899508754 ^ 922991644 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e);
			this.oqb1s1mNQr.Size = new Size(140, 74);
			this.oqb1s1mNQr.TabIndex = 28;
			this.CeT1HYBqh5.BackColor = Color.Transparent;
			this.CeT1HYBqh5.Location = new Point(30, 255);
			this.CeT1HYBqh5.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(931021470 ^ 896294341 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb);
			this.CeT1HYBqh5.Size = new Size(92, 149);
			this.CeT1HYBqh5.TabIndex = 29;
			this.CeT1HYBqh5.TabStop = false;
			this.nKS1GlWP6n.Icon = (Icon)componentResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -514033592 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18));
			this.nKS1GlWP6n.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 1640625339 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264);
			this.nKS1GlWP6n.MouseClick += this.j8yx4aKtmA;
			this.HFF1Td7WHu.BackColor = Color.FromArgb(50, 110, 160);
			this.HFF1Td7WHu.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.HFF1Td7WHu.FlatAppearance.BorderColor = Color.FromArgb(60, 140, 200);
			this.HFF1Td7WHu.FlatAppearance.BorderSize = 2;
			this.HFF1Td7WHu.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 160, 230);
			this.HFF1Td7WHu.FlatStyle = FlatStyle.Flat;
			this.HFF1Td7WHu.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1193207239 - -1972173397 ^ 1352319644 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0), 8.249999f, FontStyle.Bold);
			this.HFF1Td7WHu.ForeColor = Color.FromArgb(215, 228, 242);
			this.HFF1Td7WHu.Location = new Point(154, 564);
			this.HFF1Td7WHu.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(326126308 >> 6 ^ 607057050 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8);
			this.HFF1Td7WHu.Size = new Size(30, 30);
			this.HFF1Td7WHu.TabIndex = 30;
			this.HFF1Td7WHu.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-907199388 - -1774585445 ^ 1590321523 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b);
			this.HFF1Td7WHu.UseVisualStyleBackColor = false;
			this.HFF1Td7WHu.Visible = false;
			this.HFF1Td7WHu.Click += this.n0cxGhSdmN;
			this.rS71BwocEN.BackColor = Color.FromArgb(50, 110, 160);
			this.rS71BwocEN.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.rS71BwocEN.FlatAppearance.BorderColor = Color.FromArgb(60, 140, 200);
			this.rS71BwocEN.FlatAppearance.BorderSize = 2;
			this.rS71BwocEN.FlatAppearance.MouseDownBackColor = Color.FromArgb(70, 160, 230);
			this.rS71BwocEN.FlatStyle = FlatStyle.Flat;
			this.rS71BwocEN.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1051507632 ^ -1560721276 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a47c6b8b4ef4b4fb7822db54ad2e527), 12f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.rS71BwocEN.ForeColor = Color.FromArgb(215, 228, 242);
			this.rS71BwocEN.Location = new Point(242, 286);
			this.rS71BwocEN.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1487526596 - 1491293507 ^ -370721161 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8);
			this.rS71BwocEN.Size = new Size(20, 20);
			this.rS71BwocEN.TabIndex = 33;
			this.rS71BwocEN.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1487851180 ^ -1114224288 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142);
			this.rS71BwocEN.UseVisualStyleBackColor = false;
			this.rS71BwocEN.Click += this.N7qJecMmSO;
			this.AllowDrop = true;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Black;
			this.BackgroundImage = (Image)componentResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-582625272 ^ 1552186307 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25));
			this.BackgroundImageLayout = ImageLayout.Center;
			base.ClientSize = new Size(1026, 640);
			base.ControlBox = false;
			base.Controls.Add(this.rS71BwocEN);
			base.Controls.Add(this.HFF1Td7WHu);
			base.Controls.Add(this.Q4q1hb8iU8);
			base.Controls.Add(this.CeT1HYBqh5);
			base.Controls.Add(this.oqb1s1mNQr);
			base.Controls.Add(this.DTS1N5UREm);
			base.Controls.Add(this.btX1rOiDVU);
			base.Controls.Add(this.MLK1SmC0fp);
			base.Controls.Add(this.f6M1CAxqn9);
			base.Controls.Add(this.Rkd1ZHfnT8);
			base.Controls.Add(this.hGr10Itn8r);
			base.Controls.Add(this.LH711m4nqc);
			base.Controls.Add(this.I7h1bkVyu9);
			base.Controls.Add(this.SY61wv959Y);
			base.Controls.Add(this.cw115lVbpK);
			base.Controls.Add(this.GTL1jrPtBB);
			base.Controls.Add(this.yx818kJA68);
			base.Controls.Add(this.o7O1yRJB3K);
			base.Icon = (Icon)componentResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(255309438 ^ 1804155684 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1c66e07149574924b7cd3da5aa89d5a4));
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			this.MinimumSize = new Size(1026, 640);
			base.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-316901148 - -1443672473 ^ 1925050250 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20);
			base.Opacity = 0.95;
			this.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-361965784 ^ -1628603404 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a);
			base.Load += this.XCyJEdJRB7;
			base.DragDrop += this.oJ3x5ToIMy;
			base.DragEnter += this.B9XxjdLMMT;
			base.DragLeave += this.tNlxycQ2Qm;
			this.yx818kJA68.ResumeLayout(false);
			this.yx818kJA68.PerformLayout();
			((ISupportInitialize)this.mbv1xj0auj).EndInit();
			this.x1A1t8whsW.ResumeLayout(false);
			this.oqb1s1mNQr.ResumeLayout(false);
			((ISupportInitialize)this.CeT1HYBqh5).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x00014F70 File Offset: 0x00013170
		// Note: this type is marked as 'beforefieldinit'.
		static Main()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			Main.zdmx6d1IAa = global::License.IsActivated();
			Main.UBNxamdXSV = PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.METJ4myejd,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--1651549092 ^ 2100657996 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(219099983 << 4 ^ -209297415 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62)
			});
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x00014FEC File Offset: 0x000131EC
		[CompilerGenerated]
		private void xyjxBkqTGa()
		{
			this.aiwJprfnjt();
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x00014FF4 File Offset: 0x000131F4
		[CompilerGenerated]
		private void BiExqCb4hV()
		{
			Tray.Hide(this, this.nKS1GlWP6n);
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x00015004 File Offset: 0x00013204
		[CompilerGenerated]
		private Task fyFx7flIy4()
		{
			Main.<<Main_LoadAsync>b__20_3>d <<Main_LoadAsync>b__20_3>d;
			<<Main_LoadAsync>b__20_3>d.<>t__builder = AsyncTaskMethodBuilder.Create();
			<<Main_LoadAsync>b__20_3>d.<>4__this = this;
			<<Main_LoadAsync>b__20_3>d.<>1__state = -1;
			<<Main_LoadAsync>b__20_3>d.<>t__builder.Start<Main.<<Main_LoadAsync>b__20_3>d>(ref <<Main_LoadAsync>b__20_3>d);
			return <<Main_LoadAsync>b__20_3>d.<>t__builder.Task;
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x00015048 File Offset: 0x00013248
		[CompilerGenerated]
		private void C2ZxAxQrZP()
		{
			this.YQ2xcvIb2n();
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x00015050 File Offset: 0x00013250
		[CompilerGenerated]
		private void kd0xPonI4o(string \u0020)
		{
			Main.<>c__DisplayClass20_1 CS$<>8__locals1 = new Main.<>c__DisplayClass20_1();
			CS$<>8__locals1.zvcMYSHdlc = this;
			CS$<>8__locals1.fVhMguS8fx = \u0020;
			if (base.IsDisposed || !base.IsHandleCreated)
			{
				return;
			}
			base.Invoke(new Action(CS$<>8__locals1.JTrMQTCrPh));
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x0001509C File Offset: 0x0001329C
		[CompilerGenerated]
		private void HngxofZ9DJ()
		{
			base.BeginInvoke(new Action(this.qylx9x58A0));
			if (Main.zdmx6d1IAa)
			{
				CleanManager.Clean();
			}
		}

		// Token: 0x060002EA RID: 746 RVA: 0x000150C0 File Offset: 0x000132C0
		[CompilerGenerated]
		private void qylx9x58A0()
		{
			this.eLAJUYwbY5(this.I7h1bkVyu9.Text);
			this.o7O1yRJB3K.Enabled = true;
			this.MLK1SmC0fp.Enabled = true;
			this.o7O1yRJB3K.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-654387379 >> 4 ^ -402219734 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a));
			this.btX1rOiDVU.IsMarquee = false;
			this.btX1rOiDVU.Value = 0;
			if (this.VOxxpHk7jv != null)
			{
				this.VOxxpHk7jv.Dispose();
				this.VOxxpHk7jv = null;
			}
			TaskbarProgress.SetProgress(base.Handle, 0, 100);
			if (!GameManager.LaunchedFromTray)
			{
				Tray.Show(this, this.nKS1GlWP6n);
			}
		}

		// Token: 0x060002EB RID: 747 RVA: 0x00015180 File Offset: 0x00013380
		[CompilerGenerated]
		private string Kt5xQorrL9(string \u0020)
		{
			return this.qf6xO3gdmw[\u0020].Version;
		}

		// Token: 0x060002EC RID: 748 RVA: 0x00015194 File Offset: 0x00013394
		[CompilerGenerated]
		private void plBxgOBHCg()
		{
			this.OQOJn8XVh0();
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0001519C File Offset: 0x0001339C
		[CompilerGenerated]
		private void QFYxYlqRBx(int \u0020)
		{
			Main.<>c__DisplayClass45_1 CS$<>8__locals1 = new Main.<>c__DisplayClass45_1();
			CS$<>8__locals1.dh9M3jYmrf = this;
			CS$<>8__locals1.aQgMnExGOJ = \u0020;
			if (base.IsDisposed || !base.IsHandleCreated)
			{
				return;
			}
			base.Invoke(new Action(CS$<>8__locals1.iNVMe3Vm0q));
		}

		// Token: 0x060002EE RID: 750 RVA: 0x000151E8 File Offset: 0x000133E8
		[CompilerGenerated]
		private void E9VxlmVqPo(string \u0020)
		{
			string fileName = Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName);
			if (global::License.Activate(\u0020))
			{
				yNhAJGXiuLnPpwrVl1j.BsjXuMVO9f(string.Concat(new string[]
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 1218095203 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967),
					fileName,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1101117538 + -804724488 ^ 483285009 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3423fe0bd378445e9a426e728c08b0d3),
					fileName,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1721586492 ^ 507865949 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770)
				}), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2091326168 ^ -360595722 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_bcad499d901540f895e61fc7be5dbf2b));
				return;
			}
			MessageOverlay.ShowMessage(this, i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2060960577 >> 4 ^ 428224237 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562)), i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1583188517 ^ 1875451918 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20)), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1814540806 ^ 303688700 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25), null);
		}

		// Token: 0x060002EF RID: 751 RVA: 0x00015318 File Offset: 0x00013518
		[CompilerGenerated]
		private void BYbxVDsPks(int \u0020)
		{
			Main.<>c__DisplayClass68_0 CS$<>8__locals1 = new Main.<>c__DisplayClass68_0();
			CS$<>8__locals1.L9dCAW6vLd = this;
			CS$<>8__locals1.FyXC7G42xA = \u0020;
			if (base.IsDisposed || !base.IsHandleCreated)
			{
				return;
			}
			base.Invoke(new Action(CS$<>8__locals1.EZPCqfxdlU));
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x00015364 File Offset: 0x00013564
		[CompilerGenerated]
		private void AmyxDLjp10(int \u0020)
		{
			if (base.IsDisposed)
			{
				return;
			}
			if (\u0020 == -1)
			{
				this.btX1rOiDVU.IsMarquee = true;
				return;
			}
			this.btX1rOiDVU.IsMarquee = false;
			this.btX1rOiDVU.Value = \u0020;
			TaskbarProgress.SetProgress(base.Handle, \u0020, 100);
		}

		// Token: 0x0400024D RID: 589
		private static readonly bool zdmx6d1IAa;

		// Token: 0x0400024E RID: 590
		private Dictionary<string, VersionDataInternal> qf6xO3gdmw;

		// Token: 0x0400024F RID: 591
		private string Ln1xfmldC5;

		// Token: 0x04000250 RID: 592
		private readonly ToolTip w4UxiE1Enf;

		// Token: 0x04000251 RID: 593
		private Timer tHbxUMsubx;

		// Token: 0x04000252 RID: 594
		private bool wjoxuFLUbn;

		// Token: 0x04000253 RID: 595
		private readonly int A40xvwHqfS;

		// Token: 0x04000254 RID: 596
		private readonly int nbgxEDL3GM;

		// Token: 0x04000255 RID: 597
		private LocalServer VOxxpHk7jv;

		// Token: 0x04000256 RID: 598
		private readonly HytaleAccountManager CmkxF65BH2;

		// Token: 0x04000257 RID: 599
		private bool EnGxdDyjWi;

		// Token: 0x04000258 RID: 600
		private bool IXkxWKC4cN;

		// Token: 0x04000259 RID: 601
		private readonly Timer gGPxeWDVEP;

		// Token: 0x0400025A RID: 602
		private Timer bNexneFwHF;

		// Token: 0x0400025B RID: 603
		private float gN4x3laAYE;

		// Token: 0x0400025C RID: 604
		private readonly FormDrags e9nxLpj4fy;

		// Token: 0x0400025D RID: 605
		private Label UlQxIj8Dtx;

		// Token: 0x0400025E RID: 606
		private ConsoleForm dpmxRVtaPi;

		// Token: 0x0400025F RID: 607
		private static readonly string UBNxamdXSV;

		// Token: 0x04000261 RID: 609
		private Panel yx818kJA68;

		// Token: 0x04000262 RID: 610
		private Label Q4q1hb8iU8;

		// Token: 0x04000263 RID: 611
		private LinkLabel GHn1kSMykE;

		// Token: 0x04000264 RID: 612
		private Label SY61wv959Y;

		// Token: 0x04000265 RID: 613
		private CustomTextBox I7h1bkVyu9;

		// Token: 0x04000266 RID: 614
		private Label SaJ1J3Tac0;

		// Token: 0x04000267 RID: 615
		private PictureBox mbv1xj0auj;

		// Token: 0x04000268 RID: 616
		private CustomComboBox LH711m4nqc;

		// Token: 0x04000269 RID: 617
		private Label hGr10Itn8r;

		// Token: 0x0400026A RID: 618
		private CustomCheckBox X1y1X0lluq;

		// Token: 0x0400026B RID: 619
		private CustomButton GTL1jrPtBB;

		// Token: 0x0400026C RID: 620
		private CustomButton cw115lVbpK;

		// Token: 0x0400026D RID: 621
		private CustomButton o7O1yRJB3K;

		// Token: 0x0400026E RID: 622
		private CustomButton Rkd1ZHfnT8;

		// Token: 0x0400026F RID: 623
		private CustomButton Oij1MLZ0nH;

		// Token: 0x04000270 RID: 624
		private CustomButton f6M1CAxqn9;

		// Token: 0x04000271 RID: 625
		private CustomButton MLK1SmC0fp;

		// Token: 0x04000272 RID: 626
		private ContextMenuStrip x1A1t8whsW;

		// Token: 0x04000273 RID: 627
		private ToolStripMenuItem oUB1cv1mHR;

		// Token: 0x04000274 RID: 628
		private CustomCheckBox qkc1mdcGNq;

		// Token: 0x04000275 RID: 629
		private ToolStripMenuItem KA91KR1HT3;

		// Token: 0x04000276 RID: 630
		private CustomCheckBox Abb12SSsH2;

		// Token: 0x04000277 RID: 631
		private CustomProgressBar btX1rOiDVU;

		// Token: 0x04000278 RID: 632
		private CustomButton DTS1N5UREm;

		// Token: 0x04000279 RID: 633
		private Panel oqb1s1mNQr;

		// Token: 0x0400027A RID: 634
		private PictureBox CeT1HYBqh5;

		// Token: 0x0400027B RID: 635
		private ToolStripMenuItem G9V14qXxIv;

		// Token: 0x0400027C RID: 636
		private NotifyIcon nKS1GlWP6n;

		// Token: 0x0400027D RID: 637
		private CustomButton HFF1Td7WHu;

		// Token: 0x0400027E RID: 638
		private CustomButton rS71BwocEN;

		// Token: 0x0200008F RID: 143
		public class PluginManifest
		{
			// Token: 0x17000075 RID: 117
			// (get) Token: 0x060002F1 RID: 753 RVA: 0x00024D78 File Offset: 0x00022F78
			// (set) Token: 0x060002F2 RID: 754 RVA: 0x00024D80 File Offset: 0x00022F80
			public string Name { get; set; }

			// Token: 0x17000076 RID: 118
			// (get) Token: 0x060002F3 RID: 755 RVA: 0x00024D8C File Offset: 0x00022F8C
			// (set) Token: 0x060002F4 RID: 756 RVA: 0x00024D94 File Offset: 0x00022F94
			public string Version { get; set; }

			// Token: 0x17000077 RID: 119
			// (get) Token: 0x060002F5 RID: 757 RVA: 0x00024DA0 File Offset: 0x00022FA0
			// (set) Token: 0x060002F6 RID: 758 RVA: 0x00024DA8 File Offset: 0x00022FA8
			public string Description { get; set; }

			// Token: 0x060002F7 RID: 759 RVA: 0x00024DB4 File Offset: 0x00022FB4
			public PluginManifest()
			{
				yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
				base..ctor();
			}

			// Token: 0x0400027F RID: 639
			[CompilerGenerated]
			private string LnLMjkgB7A;

			// Token: 0x04000280 RID: 640
			[CompilerGenerated]
			private string donM5vNgcF;

			// Token: 0x04000281 RID: 641
			[CompilerGenerated]
			private string WqUMyJFTps;
		}
	}
}
