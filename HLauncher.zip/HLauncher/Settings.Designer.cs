﻿namespace HLauncher
{
	// Token: 0x020000BE RID: 190
	public partial class Settings : global::RoundedForm
	{
		// Token: 0x060003C3 RID: 963 RVA: 0x00018D24 File Offset: 0x00016F24
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.ltU0aTAMIx != null)
			{
				this.ltU0aTAMIx.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x04000355 RID: 853
		private global::System.ComponentModel.IContainer ltU0aTAMIx;
	}
}
