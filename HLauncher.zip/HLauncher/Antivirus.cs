﻿using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

// Token: 0x02000019 RID: 25
public static class Antivirus
{
	// Token: 0x06000095 RID: 149 RVA: 0x00004420 File Offset: 0x00002620
	public static Task<bool> AddFolderToExclusions(string folderPath)
	{
		Antivirus.<AddFolderToExclusions>d__0 <AddFolderToExclusions>d__;
		<AddFolderToExclusions>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
		<AddFolderToExclusions>d__.folderPath = folderPath;
		<AddFolderToExclusions>d__.<>1__state = -1;
		<AddFolderToExclusions>d__.<>t__builder.Start<Antivirus.<AddFolderToExclusions>d__0>(ref <AddFolderToExclusions>d__);
		return <AddFolderToExclusions>d__.<>t__builder.Task;
	}
}
