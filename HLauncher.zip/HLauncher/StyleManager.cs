﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using HLauncher.Properties;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000CB RID: 203
	public static class StyleManager
	{
		// Token: 0x0600041A RID: 1050
		[DllImport("gdi32.dll", EntryPoint = "AddFontMemResourceEx")]
		private static extern IntPtr F6vXDuymg7(IntPtr \u0020, uint \u0020, IntPtr \u0020, [In] ref uint \u0020);

		// Token: 0x0600041B RID: 1051 RVA: 0x00019B8C File Offset: 0x00017D8C
		public static void LoadFonts()
		{
			if (StyleManager.FontCollection.Families.Length != 0)
			{
				return;
			}
			try
			{
				byte[] minecraft = Resources.minecraft;
				IntPtr intPtr = Marshal.AllocCoTaskMem(minecraft.Length);
				Marshal.Copy(minecraft, 0, intPtr, minecraft.Length);
				StyleManager.FontCollection.AddMemoryFont(intPtr, minecraft.Length);
				uint num = 0U;
				StyleManager.F6vXDuymg7(intPtr, (uint)minecraft.Length, IntPtr.Zero, ref num);
				Marshal.FreeCoTaskMem(intPtr);
			}
			catch
			{
			}
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x00019C08 File Offset: 0x00017E08
		public static Font GetMainFont(float size)
		{
			if (StyleManager.FontCollection.Families.Length == 0)
			{
				return new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 1708463755 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215), size);
			}
			Font font;
			if (!StyleManager.KkDXOXemjB.TryGetValue(size, out font))
			{
				font = new Font(StyleManager.FontCollection.Families[0], size);
				StyleManager.KkDXOXemjB[size] = font;
			}
			return font;
		}

		// Token: 0x0600041D RID: 1053 RVA: 0x00019C80 File Offset: 0x00017E80
		public static Bitmap IconToBitmap(string icon, string fontName, float fontSize, Color color, int size = 16, int offsetX = 0, int offsetY = 0)
		{
			Bitmap bitmap = new Bitmap(size, size);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
				using (Font font = new Font(fontName, fontSize))
				{
					using (Brush brush = new SolidBrush(color))
					{
						graphics.DrawString(icon, font, brush, new PointF((float)(-1 + offsetX), (float)offsetY));
					}
				}
			}
			return bitmap;
		}

		// Token: 0x0600041E RID: 1054 RVA: 0x00019D20 File Offset: 0x00017F20
		public static void SetIcon(Button btn, string unicode, float size = 12f, Color? color = null)
		{
			string key = string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~433653721 ^ -676198349 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20), unicode, size, color);
			Bitmap bitmap;
			if (!StyleManager.tMnXfWF8wT.TryGetValue(key, out bitmap))
			{
				string systemIconFont = StyleManager.GetSystemIconFont();
				bitmap = StyleManager.IconToBitmap(unicode, systemIconFont, size, color ?? Color.White, 20, 0, 0);
				StyleManager.tMnXfWF8wT[key] = bitmap;
			}
			btn.Image = bitmap;
		}

		// Token: 0x0600041F RID: 1055 RVA: 0x00019DB4 File Offset: 0x00017FB4
		public static string GetSystemIconFont()
		{
			if (StyleManager.eITX6Otj4N(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~515955376 ^ -1892440337 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156)))
			{
				return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -1871525999 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20);
			}
			if (StyleManager.eITX6Otj4N(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1366522423 ^ -870198492 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4)))
			{
				return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1512690999 ^ -738864759 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215);
			}
			return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-571302991 + -886974362 ^ -999464373 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b);
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x00019E68 File Offset: 0x00018068
		private static bool eITX6Otj4N(string \u0020)
		{
			bool result;
			using (Font font = new Font(\u0020, 8f))
			{
				result = string.Equals(font.Name, \u0020, StringComparison.InvariantCultureIgnoreCase);
			}
			return result;
		}

		// Token: 0x06000421 RID: 1057 RVA: 0x00019EB4 File Offset: 0x000180B4
		public static void Cleanup()
		{
			foreach (Font font in StyleManager.KkDXOXemjB.Values)
			{
				font.Dispose();
			}
			StyleManager.KkDXOXemjB.Clear();
			StyleManager.tMnXfWF8wT.Clear();
			StyleManager.FontCollection.Dispose();
		}

		// Token: 0x06000422 RID: 1058 RVA: 0x00019F30 File Offset: 0x00018130
		// Note: this type is marked as 'beforefieldinit'.
		static StyleManager()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			StyleManager.FontCollection = new PrivateFontCollection();
			StyleManager.KkDXOXemjB = new Dictionary<float, Font>();
			StyleManager.tMnXfWF8wT = new Dictionary<string, Bitmap>();
		}

		// Token: 0x04000399 RID: 921
		public static readonly PrivateFontCollection FontCollection;

		// Token: 0x0400039A RID: 922
		private static readonly Dictionary<float, Font> KkDXOXemjB;

		// Token: 0x0400039B RID: 923
		private static readonly Dictionary<string, Bitmap> tMnXfWF8wT;
	}
}
