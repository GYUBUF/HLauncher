﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x0200002D RID: 45
public class LauncherDataResponse
{
	// Token: 0x17000036 RID: 54
	// (get) Token: 0x060000D6 RID: 214 RVA: 0x00004C28 File Offset: 0x00002E28
	// (set) Token: 0x060000D7 RID: 215 RVA: 0x00004C30 File Offset: 0x00002E30
	[JsonProperty("eula_accepted_at")]
	public DateTime? EulaAcceptedAt { get; set; }

	// Token: 0x17000037 RID: 55
	// (get) Token: 0x060000D8 RID: 216 RVA: 0x00004C3C File Offset: 0x00002E3C
	// (set) Token: 0x060000D9 RID: 217 RVA: 0x00004C44 File Offset: 0x00002E44
	[JsonProperty("owner")]
	public string Owner { get; set; }

	// Token: 0x17000038 RID: 56
	// (get) Token: 0x060000DA RID: 218 RVA: 0x00004C50 File Offset: 0x00002E50
	// (set) Token: 0x060000DB RID: 219 RVA: 0x00004C58 File Offset: 0x00002E58
	[JsonProperty("patchlines")]
	public Dictionary<string, PatchlineInfo> Patchlines { get; set; }

	// Token: 0x17000039 RID: 57
	// (get) Token: 0x060000DC RID: 220 RVA: 0x00004C64 File Offset: 0x00002E64
	// (set) Token: 0x060000DD RID: 221 RVA: 0x00004C6C File Offset: 0x00002E6C
	[JsonProperty("profiles")]
	public List<HytaleProfile> Profiles { get; set; }

	// Token: 0x060000DE RID: 222 RVA: 0x00004C78 File Offset: 0x00002E78
	public LauncherDataResponse()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
	}

	// Token: 0x040000AD RID: 173
	[CompilerGenerated]
	private DateTime? HG5hPQ5ZXJ;

	// Token: 0x040000AE RID: 174
	[CompilerGenerated]
	private string gKwhoASKNM;

	// Token: 0x040000AF RID: 175
	[CompilerGenerated]
	private Dictionary<string, PatchlineInfo> p3vh98draE;

	// Token: 0x040000B0 RID: 176
	[CompilerGenerated]
	private List<HytaleProfile> h5nhQvHt2d;
}
