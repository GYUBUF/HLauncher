﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows.Forms;
using HLauncher;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace gt2OLuXUIOYbfABBoJo
{
	// Token: 0x020000CC RID: 204
	internal class yNhAJGXiuLnPpwrVl1j
	{
		// Token: 0x06000423 RID: 1059 RVA: 0x00019F5C File Offset: 0x0001815C
		public static string BsjXuMVO9f(string \u0020, string \u0020 = "cmd")
		{
			string result;
			try
			{
				using (Process process = Process.Start(new ProcessStartInfo
				{
					FileName = \u0020,
					Arguments = ((\u0020 == yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1193207239 - -1972173397 ^ 1004998890 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a)) ? (yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-571302991 + -886974362 ^ -1042244352 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc) + \u0020) : (\u0020 ?? "")),
					RedirectStandardOutput = true,
					RedirectStandardError = true,
					UseShellExecute = false,
					CreateNoWindow = true
				}))
				{
					process.WaitForExit();
					string text = process.StandardOutput.ReadToEnd();
					process.StandardError.ReadToEnd();
					result = text;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1424072547 ^ 741971544 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770), ex.Message);
				result = ex.Message;
			}
			return result;
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x0001A084 File Offset: 0x00018284
		public static Image gQ7XvmxHkE(string \u0020, int \u0020)
		{
			if (!PathHelper.FileExists(\u0020))
			{
				return null;
			}
			Image result;
			using (Icon icon = Icon.ExtractAssociatedIcon(\u0020))
			{
				using (Bitmap bitmap = icon.ToBitmap())
				{
					Bitmap bitmap2 = new Bitmap(\u0020, \u0020, PixelFormat.Format32bppArgb);
					using (Graphics graphics = Graphics.FromImage(bitmap2))
					{
						graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
						graphics.SmoothingMode = SmoothingMode.HighQuality;
						graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
						graphics.CompositingQuality = CompositingQuality.HighQuality;
						graphics.DrawImage(bitmap, new Rectangle(0, 0, \u0020, \u0020));
						result = bitmap2;
					}
				}
			}
			return result;
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0001A148 File Offset: 0x00018348
		public static string xEuXElSa2T(string \u0020)
		{
			if (!PathHelper.FileExists(\u0020))
			{
				throw new FileNotFoundException(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2060960577 >> 4 ^ 1869076613 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091), \u0020);
			}
			string result;
			using (FileStream fileStream = new FileStream((Path.GetFullPath(\u0020).Length >= 260) ? (yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1223787438 ^ -1590704594 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8) + Path.GetFullPath(\u0020)) : Path.GetFullPath(\u0020), FileMode.Open, FileAccess.Read, FileShare.Read, 1048576, FileOptions.SequentialScan))
			{
				using (SHA1Cng sha1Cng = new SHA1Cng())
				{
					result = yNhAJGXiuLnPpwrVl1j.qmyXp7DWZ9(sha1Cng.ComputeHash(fileStream));
				}
			}
			return result;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0001A234 File Offset: 0x00018434
		private static string qmyXp7DWZ9(byte[] \u0020)
		{
			char[] array = new char[\u0020.Length * 2];
			for (int i = 0; i < \u0020.Length; i++)
			{
				byte b = (byte)(\u0020[i] >> 4);
				array[i * 2] = (char)((b > 9) ? (b + 55) : (b + 48));
				b = (\u0020[i] & 15);
				array[i * 2 + 1] = (char)((b > 9) ? (b + 55) : (b + 48));
			}
			return new string(array);
		}

		// Token: 0x06000427 RID: 1063 RVA: 0x0001A2B0 File Offset: 0x000184B0
		public static Task<yNhAJGXiuLnPpwrVl1j.aDKdORSQojqhMch5Fnd> M8vXFdvwbD()
		{
			yNhAJGXiuLnPpwrVl1j.<CheckForUpdatesAsync>d__5 <CheckForUpdatesAsync>d__;
			<CheckForUpdatesAsync>d__.<>t__builder = AsyncTaskMethodBuilder<yNhAJGXiuLnPpwrVl1j.aDKdORSQojqhMch5Fnd>.Create();
			<CheckForUpdatesAsync>d__.<>1__state = -1;
			<CheckForUpdatesAsync>d__.<>t__builder.Start<yNhAJGXiuLnPpwrVl1j.<CheckForUpdatesAsync>d__5>(ref <CheckForUpdatesAsync>d__);
			return <CheckForUpdatesAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0001A2EC File Offset: 0x000184EC
		public static Task<string> j1FXdDDCRJ()
		{
			yNhAJGXiuLnPpwrVl1j.<DownloadAndInstallAsync>d__6 <DownloadAndInstallAsync>d__;
			<DownloadAndInstallAsync>d__.<>t__builder = AsyncTaskMethodBuilder<string>.Create();
			<DownloadAndInstallAsync>d__.<>1__state = -1;
			<DownloadAndInstallAsync>d__.<>t__builder.Start<yNhAJGXiuLnPpwrVl1j.<DownloadAndInstallAsync>d__6>(ref <DownloadAndInstallAsync>d__);
			return <DownloadAndInstallAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000429 RID: 1065 RVA: 0x0001A328 File Offset: 0x00018528
		public static bool ix5XW29DPS()
		{
			bool result;
			try
			{
				IEnumerable<Process> processesByName = Process.GetProcessesByName(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -650317430 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add));
				Process[] processesByName2 = Process.GetProcessesByName(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1487526596 - 1491293507 ^ -224234106 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3423fe0bd378445e9a426e728c08b0d3));
				Process[] processesByName3 = Process.GetProcessesByName(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1955617249 >> 6 ^ 934502691 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df));
				result = (processesByName.Any<Process>() || processesByName2.Any<Process>() || processesByName3.Any<Process>());
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x0600042A RID: 1066 RVA: 0x0001A3EC File Offset: 0x000185EC
		public static bool g8fXe2k6p6()
		{
			return Path.GetFileName(Application.ExecutablePath).IndexOf(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1727091913 << 3 ^ 1602125337 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc), StringComparison.OrdinalIgnoreCase) >= 0;
		}

		// Token: 0x0600042B RID: 1067 RVA: 0x0001A428 File Offset: 0x00018628
		public yNhAJGXiuLnPpwrVl1j()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x020000CD RID: 205
		public class aDKdORSQojqhMch5Fnd
		{
			// Token: 0x0600042C RID: 1068 RVA: 0x0002A970 File Offset: 0x00028B70
			[CompilerGenerated]
			public bool WQsSgUlL2O()
			{
				return this.rMtSUjFNGQ;
			}

			// Token: 0x0600042D RID: 1069 RVA: 0x0002A978 File Offset: 0x00028B78
			[CompilerGenerated]
			public void aCnSY8f9Yx(bool \u0020)
			{
				this.rMtSUjFNGQ = \u0020;
			}

			// Token: 0x0600042E RID: 1070 RVA: 0x0002A984 File Offset: 0x00028B84
			[CompilerGenerated]
			public string NaISVotidH()
			{
				return this.G6ySuvqasr;
			}

			// Token: 0x0600042F RID: 1071 RVA: 0x0002A98C File Offset: 0x00028B8C
			[CompilerGenerated]
			public void axQSDUIina(string \u0020)
			{
				this.G6ySuvqasr = \u0020;
			}

			// Token: 0x06000430 RID: 1072 RVA: 0x0002A998 File Offset: 0x00028B98
			[CompilerGenerated]
			public string X5NSO60yUW()
			{
				return this.x0FSv6gMM5;
			}

			// Token: 0x06000431 RID: 1073 RVA: 0x0002A9A0 File Offset: 0x00028BA0
			[CompilerGenerated]
			public void eaKSfF3bNI(string \u0020)
			{
				this.x0FSv6gMM5 = \u0020;
			}

			// Token: 0x06000432 RID: 1074 RVA: 0x0002A9AC File Offset: 0x00028BAC
			public aDKdORSQojqhMch5Fnd()
			{
				yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
				base..ctor();
			}

			// Token: 0x0400039C RID: 924
			[CompilerGenerated]
			private bool rMtSUjFNGQ;

			// Token: 0x0400039D RID: 925
			[CompilerGenerated]
			private string G6ySuvqasr;

			// Token: 0x0400039E RID: 926
			[CompilerGenerated]
			private string x0FSv6gMM5;
		}
	}
}
