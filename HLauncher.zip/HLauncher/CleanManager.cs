﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AGSw7LJMkp5usDW1gK1;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x02000043 RID: 67
	public static class CleanManager
	{
		// Token: 0x0600017B RID: 379 RVA: 0x000077C0 File Offset: 0x000059C0
		public static void Clean()
		{
			string uemJT3Rkpy = RJG3u8JZLa1autEARgF.uemJT3Rkpy;
			if (!PathHelper.DirectoryExists(uemJT3Rkpy))
			{
				return;
			}
			CleanManager.YW2wuMg5eW(uemJT3Rkpy);
			CleanManager.Apwwv1bhLi(uemJT3Rkpy);
			CleanManager.xiBwEhXmLp(uemJT3Rkpy, 7);
		}

		// Token: 0x0600017C RID: 380 RVA: 0x000077F4 File Offset: 0x000059F4
		private static void YW2wuMg5eW(string \u0020)
		{
			foreach (string u in Directory.GetDirectories(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-352509668 ^ -1663126340 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215), SearchOption.AllDirectories).Where(new Func<string, bool>(CleanManager.<>c.EiY5tpqi7Q.pxa5Mru2h9)))
			{
				CleanManager.TKXwpuVl4d(u);
			}
		}

		// Token: 0x0600017D RID: 381 RVA: 0x00007890 File Offset: 0x00005A90
		private static void Apwwv1bhLi(string \u0020)
		{
			CleanManager.TKXwpuVl4d(PathHelper.Combine(new string[]
			{
				\u0020,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(372928822 + -1261521798 ^ -1526347578 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156)
			}));
		}

		// Token: 0x0600017E RID: 382 RVA: 0x000078CC File Offset: 0x00005ACC
		private static void xiBwEhXmLp(string \u0020, int \u0020)
		{
			DateTime t = DateTime.UtcNow.AddDays((double)(-(double)\u0020));
			string[] array = new string[]
			{
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-907199388 - -1774585445 ^ 1569556468 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1899508754 ^ 786140455 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 1675097042 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156)
			};
			string[] source = new string[]
			{
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763020866 ^ -176632107 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2107463719 ^ 1000720156 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70)
			};
			foreach (string text in array)
			{
				string p = PathHelper.Combine(new string[]
				{
					\u0020,
					text
				});
				if (PathHelper.Exists(p))
				{
					if (PathHelper.DirectoryExists(p))
					{
						string[] files = PathHelper.GetFiles(p, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-752914475 ^ -549029086 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1), SearchOption.AllDirectories);
						for (int j = 0; j < files.Length; j++)
						{
							CleanManager.<>c__DisplayClass3_0 CS$<>8__locals1 = new CleanManager.<>c__DisplayClass3_0();
							CS$<>8__locals1.vdJ5rYN5OD = files[j];
							if (!source.Any(new Func<string, bool>(CS$<>8__locals1.yd652uSmwW)) && PathHelper.GetLastWriteTimeUtc(CS$<>8__locals1.vdJ5rYN5OD) < t)
							{
								PathHelper.DeleteFile(CS$<>8__locals1.vdJ5rYN5OD);
							}
						}
					}
					else if (PathHelper.GetLastWriteTimeUtc(p) < t)
					{
						PathHelper.DeleteFile(p);
					}
				}
			}
		}

		// Token: 0x0600017F RID: 383 RVA: 0x00007A90 File Offset: 0x00005C90
		private static void TKXwpuVl4d(string \u0020)
		{
			if (!PathHelper.DirectoryExists(\u0020))
			{
				return;
			}
			List<FileInfo> list = PathHelper.GetFiles(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~234019875 ^ -1453236344 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967), SearchOption.TopDirectoryOnly).Select(new Func<string, FileInfo>(CleanManager.<>c.EiY5tpqi7Q.LLm5CC6gPT)).OrderByDescending(new Func<FileInfo, DateTime>(CleanManager.<>c.EiY5tpqi7Q.JqK5SVY82p)).ToList<FileInfo>();
			if (list.Count <= 1)
			{
				return;
			}
			foreach (FileInfo fileInfo in list.Skip(1))
			{
				try
				{
					PathHelper.DeleteFile(fileInfo.FullName);
				}
				catch
				{
				}
			}
		}
	}
}
