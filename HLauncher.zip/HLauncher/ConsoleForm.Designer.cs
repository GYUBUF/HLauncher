﻿namespace HLauncher
{
	// Token: 0x0200003E RID: 62
	public partial class ConsoleForm : global::RoundedForm
	{
		// Token: 0x0600016D RID: 365 RVA: 0x00006A2C File Offset: 0x00004C2C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.yj3wgaqkdv != null)
			{
				this.yj3wgaqkdv.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x040000E7 RID: 231
		private global::System.ComponentModel.IContainer yj3wgaqkdv;
	}
}
