﻿using System;
using System.Drawing;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000015 RID: 21
public class CustomButton : Button
{
	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000073 RID: 115 RVA: 0x0000388C File Offset: 0x00001A8C
	// (set) Token: 0x06000074 RID: 116 RVA: 0x00003894 File Offset: 0x00001A94
	public Color DisabledForeColor
	{
		get
		{
			return this.hbmRNdKKW;
		}
		set
		{
			this.hbmRNdKKW = value;
			base.Invalidate();
		}
	}

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000075 RID: 117 RVA: 0x000038A4 File Offset: 0x00001AA4
	protected override bool ShowFocusCues
	{
		get
		{
			return false;
		}
	}

	// Token: 0x06000076 RID: 118 RVA: 0x000038A8 File Offset: 0x00001AA8
	public override void NotifyDefault(bool value)
	{
		base.NotifyDefault(false);
	}

	// Token: 0x06000077 RID: 119 RVA: 0x000038B4 File Offset: 0x00001AB4
	protected override void OnPaint(PaintEventArgs pevent)
	{
		if (base.Enabled)
		{
			base.OnPaint(pevent);
			return;
		}
		Graphics graphics = pevent.Graphics;
		using (SolidBrush solidBrush = new SolidBrush(this.BackColor))
		{
			graphics.FillRectangle(solidBrush, base.ClientRectangle);
		}
		Size size = TextRenderer.MeasureText(this.Text, this.Font);
		int num = ((base.Image != null) ? base.Image.Width : 0) + ((base.Image != null) ? 2 : 0) + size.Width;
		int num2 = (base.Width - num) / 2;
		int height = base.Height;
		Image image = base.Image;
		int num3 = (height - Math.Max((image != null) ? image.Height : 0, size.Height)) / 2;
		if (base.Image != null)
		{
			ControlPaint.DrawImageDisabled(graphics, base.Image, num2 + 2, num3 + 2, this.BackColor);
			num2 += base.Image.Width + 4;
		}
		Rectangle bounds = new Rectangle(num2, 0, size.Width, base.Height);
		TextRenderer.DrawText(graphics, this.Text, this.Font, bounds, this.hbmRNdKKW, TextFormatFlags.VerticalCenter);
	}

	// Token: 0x06000078 RID: 120 RVA: 0x00003A04 File Offset: 0x00001C04
	public CustomButton()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		this.hbmRNdKKW = Color.FromArgb(100, 120, 150);
		base..ctor();
	}

	// Token: 0x04000040 RID: 64
	private Color hbmRNdKKW;
}
