﻿using System;
using System.IO;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using HLauncher;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000035 RID: 53
public static class License
{
	// Token: 0x06000123 RID: 291 RVA: 0x0000500C File Offset: 0x0000320C
	private static int[] dnck7BZqKM()
	{
		int[] array = new int[256];
		for (int i = 0; i < 256; i++)
		{
			array[i] = -1;
		}
		for (int j = 0; j < yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-169174967 ^ -1711767680 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264).Length; j++)
		{
			array[(int)yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2041937264 ^ -1978426257 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1)[j]] = j;
		}
		return array;
	}

	// Token: 0x06000124 RID: 292 RVA: 0x00005094 File Offset: 0x00003294
	public static string GetUserId()
	{
		string text = License.foRkgnB2R0();
		if (string.IsNullOrEmpty(text))
		{
			return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-866207546 ^ -753172642 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7);
		}
		string text2 = License.tJVk9KjHdi(License.xh2koyiGah(text + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(198208080 ^ 1027632421 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0)).Substring(0, 8), true);
		return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2011196192 ^ 1978804919 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb) + text2.Substring(0, 4) + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(339415119 ^ 1331128675 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967) + text2.Substring(4, 4);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x00005150 File Offset: 0x00003350
	public static bool Activate(string inputKey)
	{
		if (string.IsNullOrWhiteSpace(inputKey))
		{
			return false;
		}
		if (License.GetUserId() == yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-866207546 ^ -1130559963 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a))
		{
			return false;
		}
		if (License.IsActivated() && string.Equals(PathHelper.ReadAllText(License.kEwkVInWVC).Trim(), inputKey.Trim(), StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		if (License.sffkALArQw(inputKey))
		{
			try
			{
				string directoryName = Path.GetDirectoryName(License.kEwkVInWVC);
				if (!PathHelper.Exists(directoryName))
				{
					PathHelper.CreateDirectory(directoryName);
				}
				PathHelper.WriteAllText(License.kEwkVInWVC, inputKey.Trim().ToUpper());
				PathHelper.SetAttributes(License.kEwkVInWVC, FileAttributes.Hidden | FileAttributes.System);
				return true;
			}
			catch
			{
				return false;
			}
			return false;
		}
		return false;
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000522C File Offset: 0x0000342C
	public static bool IsActivated()
	{
		bool result;
		try
		{
			if (License.GetUserId() == yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(931021470 ^ 854289940 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a1f1dffb08f44e581e0c0e6fac695b4))
			{
				result = false;
			}
			else if (!PathHelper.Exists(License.kEwkVInWVC))
			{
				result = false;
			}
			else
			{
				result = License.sffkALArQw(PathHelper.ReadAllText(License.kEwkVInWVC));
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000127 RID: 295 RVA: 0x000052B0 File Offset: 0x000034B0
	private static bool sffkALArQw(string \u0020)
	{
		if (string.IsNullOrWhiteSpace(\u0020))
		{
			return false;
		}
		string a = \u0020.Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(931021470 ^ 116054229 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20), "").Trim().ToUpper();
		string userId = License.GetUserId();
		if (userId == yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1951784774 - -1203722840 ^ -411484098 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967))
		{
			return false;
		}
		string b = License.HYEkPUA2Rw(userId).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -865207151 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed), "");
		return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
	}

	// Token: 0x06000128 RID: 296 RVA: 0x0000536C File Offset: 0x0000356C
	internal static string HYEkPUA2Rw(string \u0020)
	{
		if (\u0020 == yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-693780468 ^ -620965617 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1))
		{
			return yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2119344876 ^ -1471238797 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18);
		}
		return License.GePkQhqBsT(License.tJVk9KjHdi(License.xh2koyiGah(\u0020.Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(372928822 + -1261521798 ^ -920951769 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb), "").Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(723568593 ^ 327166168 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7), "").Trim().ToUpper() + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 1798236670 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770)).Substring(8, 12), true));
	}

	// Token: 0x06000129 RID: 297 RVA: 0x00005454 File Offset: 0x00003654
	private static string xh2koyiGah(string \u0020)
	{
		string result;
		using (SHA256 sha = SHA256.Create())
		{
			byte[] bytes = Encoding.UTF8.GetBytes(\u0020);
			for (int i = 0; i < bytes.Length; i++)
			{
				byte[] array = bytes;
				int num = i;
				array[num] ^= (byte)((int)License.Venkl2k9sk ^ i);
			}
			byte[] array2 = sha.ComputeHash(bytes);
			StringBuilder stringBuilder = new StringBuilder(array2.Length * 2);
			foreach (byte b in array2)
			{
				stringBuilder.Append(b.ToString(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-511847524 ^ -1990669837 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f)));
			}
			result = stringBuilder.ToString();
		}
		return result;
	}

	// Token: 0x0600012A RID: 298 RVA: 0x00005524 File Offset: 0x00003724
	private static string tJVk9KjHdi(string \u0020, bool \u0020)
	{
		char[] array = \u0020.ToCharArray();
		for (int i = 0; i < array.Length; i++)
		{
			char c = char.ToUpper(array[i]);
			if (c != '-')
			{
				int num = License.h87kD8Li0p[(int)c];
				if (num != -1)
				{
					int num2 = 3 + i + (int)(License.Venkl2k9sk % 5);
					if (\u0020)
					{
						num = (num + num2) % yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-146310919 ^ -489805389 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a).Length;
					}
					else
					{
						num = (num - num2 % yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(219099983 << 4 ^ -1560921798 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0).Length + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1487526596 - 1491293507 ^ -1895484258 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a).Length) % yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1279801375 ^ -1833568599 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8fc27a48c0ce461586dd8068b3daaced).Length;
					}
					array[i] = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1921488460 ^ -8559490 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0)[num];
				}
			}
		}
		return new string(array);
	}

	// Token: 0x0600012B RID: 299 RVA: 0x00005648 File Offset: 0x00003848
	private static string GePkQhqBsT(string \u0020)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < \u0020.Length; i++)
		{
			if (i > 0 && i % 4 == 0)
			{
				stringBuilder.Append(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-169174967 ^ -2083977071 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215));
			}
			stringBuilder.Append(\u0020[i]);
		}
		return stringBuilder.ToString();
	}

	// Token: 0x0600012C RID: 300 RVA: 0x000056B8 File Offset: 0x000038B8
	private static string foRkgnB2R0()
	{
		string text = License.pSikYoBjoU(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-626376545 ^ -979264692 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1577388857 >> 1 ^ -1270817926 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d));
		string text2 = License.pSikYoBjoU(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-146310919 ^ -513368907 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1222915046 >> 5 ^ -1149040226 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e));
		if (text == null || text2 == null)
		{
			return null;
		}
		return text + text2;
	}

	// Token: 0x0600012D RID: 301 RVA: 0x00005760 File Offset: 0x00003960
	private static string pSikYoBjoU(string \u0020, string \u0020)
	{
		try
		{
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 1454859624 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967) + \u0020 + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(598276251 ^ 804382838 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1) + \u0020))
			{
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						object obj = enumerator.Current[\u0020];
						string text;
						if (obj == null)
						{
							text = null;
						}
						else
						{
							string text2 = obj.ToString();
							text = ((text2 != null) ? text2.Trim() : null);
						}
						string text3 = text;
						if (string.IsNullOrEmpty(text3) || text3.Equals(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1256492628 << 2 ^ -486686683 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0), StringComparison.OrdinalIgnoreCase) || text3.Equals(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1053457955 ^ -1587643253 ^ 209261739 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264), StringComparison.OrdinalIgnoreCase) || text3.Equals(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-800407371 ^ -788194865 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_63317b19592040989f1b836b90b41752), StringComparison.OrdinalIgnoreCase))
						{
							return null;
						}
						return text3;
					}
				}
			}
		}
		catch
		{
			return null;
		}
		return null;
	}

	// Token: 0x0600012E RID: 302 RVA: 0x00005918 File Offset: 0x00003B18
	// Note: this type is marked as 'beforefieldinit'.
	static License()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		License.Venkl2k9sk = (byte)(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-626376545 ^ -1191176435 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a47c6b8b4ef4b4fb7822db54ad2e527).Length ^ 42);
		License.kEwkVInWVC = PathHelper.Combine(new string[]
		{
			Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
			yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-34176907 ^ -736792230 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18),
			yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--132453396 ^ 949028947 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410)
		});
		License.h87kD8Li0p = License.dnck7BZqKM();
	}

	// Token: 0x040000CE RID: 206
	private static readonly byte Venkl2k9sk;

	// Token: 0x040000CF RID: 207
	private static readonly string kEwkVInWVC;

	// Token: 0x040000D0 RID: 208
	private static readonly int[] h87kD8Li0p;
}
