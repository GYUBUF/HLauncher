﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x02000033 RID: 51
public class PatchStep
{
	// Token: 0x17000050 RID: 80
	// (get) Token: 0x06000117 RID: 279 RVA: 0x00004F80 File Offset: 0x00003180
	// (set) Token: 0x06000118 RID: 280 RVA: 0x00004F88 File Offset: 0x00003188
	[JsonProperty("from")]
	public int From { get; set; }

	// Token: 0x17000051 RID: 81
	// (get) Token: 0x06000119 RID: 281 RVA: 0x00004F94 File Offset: 0x00003194
	// (set) Token: 0x0600011A RID: 282 RVA: 0x00004F9C File Offset: 0x0000319C
	[JsonProperty("to")]
	public int To { get; set; }

	// Token: 0x17000052 RID: 82
	// (get) Token: 0x0600011B RID: 283 RVA: 0x00004FA8 File Offset: 0x000031A8
	// (set) Token: 0x0600011C RID: 284 RVA: 0x00004FB0 File Offset: 0x000031B0
	[JsonProperty("pwr")]
	public string PwrUrl { get; set; }

	// Token: 0x17000053 RID: 83
	// (get) Token: 0x0600011D RID: 285 RVA: 0x00004FBC File Offset: 0x000031BC
	// (set) Token: 0x0600011E RID: 286 RVA: 0x00004FC4 File Offset: 0x000031C4
	[JsonProperty("sig")]
	public string SigUrl { get; set; }

	// Token: 0x0600011F RID: 287 RVA: 0x00004FD0 File Offset: 0x000031D0
	public PatchStep()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
	}

	// Token: 0x040000C9 RID: 201
	[CompilerGenerated]
	private int QnKk4djuUh;

	// Token: 0x040000CA RID: 202
	[CompilerGenerated]
	private int wnGkG8vDPU;

	// Token: 0x040000CB RID: 203
	[CompilerGenerated]
	private string llrkTtnF7i;

	// Token: 0x040000CC RID: 204
	[CompilerGenerated]
	private string Hq7kBUchWB;
}
