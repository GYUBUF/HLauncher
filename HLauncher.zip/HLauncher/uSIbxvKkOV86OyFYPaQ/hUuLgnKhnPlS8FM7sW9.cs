﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace uSIbxvKkOV86OyFYPaQ
{
	// Token: 0x020000F4 RID: 244
	internal class hUuLgnKhnPlS8FM7sW9
	{
		// Token: 0x060004F8 RID: 1272 RVA: 0x00032778 File Offset: 0x00030978
		private static void y8mKbLfXe2()
		{
			int num = 228;
			for (;;)
			{
				int num2 = num;
				byte[] array;
				int num3;
				int num4;
				byte[] array2;
				int num7;
				int num8;
				byte[] array3;
				uint num10;
				byte[] array4;
				uint num21;
				byte[] array6;
				int num26;
				for (;;)
				{
					int num5;
					int num6;
					uint num9;
					int num11;
					int num12;
					int num13;
					uint num15;
					uint num14;
					int num16;
					int num17;
					int num18;
					uint num19;
					uint num20;
					byte[] array5;
					int num22;
					yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8 jeCFqRmg7B63R4bEDl;
					byte[] array8;
					int num23;
					MemoryStream memoryStream;
					switch (num2)
					{
					case 0:
						goto IL_1213;
					case 1:
						array[4] = (byte)num3;
						num2 = 60;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 4;
							continue;
						}
						continue;
					case 2:
						num3 = 152 - 50;
						num2 = 322;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 208;
							continue;
						}
						continue;
					case 3:
						num4 = 170 - 56;
						num2 = 21;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 4:
						array[0] = 100 + 79;
						num2 = 114;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 270;
							continue;
						}
						continue;
					case 5:
						goto IL_13EF;
					case 6:
						if (num5 <= 0)
						{
							goto IL_2805;
						}
						num2 = 73;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 19;
							continue;
						}
						continue;
					case 7:
						array[14] = 220 - 73;
						num2 = 108;
						continue;
					case 8:
						array[14] = 210 - 70;
						num2 = 7;
						continue;
					case 9:
						num6 = 1;
						num2 = 72;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 113;
							continue;
						}
						continue;
					case 10:
						array[23] = 50 + 16;
						num2 = 261;
						continue;
					case 11:
						num4 = 20 + 103;
						num2 = 83;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 329;
							continue;
						}
						continue;
					case 12:
						array[1] = (byte)num4;
						num2 = 55;
						continue;
					case 13:
						array2[12] = (byte)num7;
						num2 = 269;
						continue;
					case 14:
						array[28] = (byte)num4;
						num2 = 327;
						continue;
					case 15:
						num4 = 182 - 60;
						num2 = 382;
						continue;
					case 16:
						array[11] = 98 + 38;
						num2 = 296;
						continue;
					case 17:
						array[9] = (byte)num3;
						num2 = 167;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 151;
							continue;
						}
						continue;
					case 18:
						goto IL_1DA7;
					case 19:
						array[9] = (byte)num4;
						num2 = 251;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 83;
							continue;
						}
						continue;
					case 20:
						num4 = 195 - 65;
						num2 = 373;
						continue;
					case 21:
						array[31] = (byte)num4;
						num2 = 152;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 178;
							continue;
						}
						continue;
					case 22:
						array2[6] = (byte)num8;
						num2 = 220;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 21;
							continue;
						}
						continue;
					case 23:
						array2[5] = 192 - 64;
						num2 = 26;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 74;
							continue;
						}
						continue;
					case 24:
						array[24] = (byte)num4;
						num2 = 353;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 13;
							continue;
						}
						continue;
					case 25:
						array[26] = (byte)num3;
						num2 = 35;
						continue;
					case 26:
						num8 = 62 - 28;
						num2 = 401;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 308;
							continue;
						}
						continue;
					case 27:
						num3 = 32 + 117;
						num2 = 305;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 294;
							continue;
						}
						continue;
					case 28:
						goto IL_26FA;
					case 29:
						num4 = 56 + 85;
						num2 = 66;
						continue;
					case 30:
						array2 = new byte[16];
						num2 = 121;
						continue;
					case 31:
						array[16] = (byte)num3;
						num2 = 355;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 32;
							continue;
						}
						continue;
					case 32:
						num3 = 19 + 3;
						num2 = 149;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 87;
							continue;
						}
						continue;
					case 33:
						array2[15] = 74 + 61;
						num2 = 157;
						continue;
					case 34:
						array[10] = 254 - 84;
						num2 = 221;
						continue;
					case 35:
						goto IL_1FE6;
					case 36:
						array[15] = 193 - 64;
						num2 = 235;
						continue;
					case 37:
						num3 = 138 - 46;
						num2 = 37;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 90;
							continue;
						}
						continue;
					case 38:
						array[24] = 129 + 122;
						num2 = 376;
						continue;
					case 39:
						array2[12] = 137 - 45;
						num2 = 301;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 157;
							continue;
						}
						continue;
					case 40:
						num9 = (uint)((int)array3[(int)(num10 + 3U)] << 24 | (int)array3[(int)(num10 + 2U)] << 16 | (int)array3[(int)(num10 + 1U)] << 8 | (int)array3[(int)num10]);
						num2 = 245;
						continue;
					case 41:
						array2[1] = (byte)num7;
						num2 = 200;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 142;
							continue;
						}
						continue;
					case 42:
						array[1] = (byte)num4;
						num2 = 213;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 212;
							continue;
						}
						continue;
					case 43:
						if (num11 != num12 - 1)
						{
							goto IL_31E4;
						}
						num2 = 241;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 282;
							continue;
						}
						continue;
					case 44:
						goto IL_2A04;
					case 45:
						num4 = 199 - 66;
						num2 = 5;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 397;
							continue;
						}
						continue;
					case 46:
						num3 = 106 + 113;
						num2 = 23;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 298;
							continue;
						}
						continue;
					case 47:
						array[28] = (byte)num3;
						num2 = 226;
						continue;
					case 48:
						array[8] = (byte)num4;
						num2 = 45;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 10;
							continue;
						}
						continue;
					case 49:
						array[17] = (byte)num4;
						num2 = 208;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 317;
							continue;
						}
						continue;
					case 50:
						num4 = 127 - 42;
						num2 = 278;
						continue;
					case 51:
						goto IL_37B2;
					case 52:
						num4 = 210 - 99;
						num2 = 335;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 344;
							continue;
						}
						continue;
					case 53:
						array2[12] = 121 + 88;
						num2 = 419;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 158;
							continue;
						}
						continue;
					case 54:
						array2[6] = (byte)num7;
						num2 = 394;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 68;
							continue;
						}
						continue;
					case 55:
						num4 = 125 + 105;
						num2 = 42;
						continue;
					case 56:
						if (num5 > 0)
						{
							num2 = 249;
							continue;
						}
						goto IL_BA6;
					case 57:
						array[30] = (byte)num4;
						num2 = 396;
						continue;
					case 58:
						array2[13] = 195 - 65;
						num2 = 44;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 11;
							continue;
						}
						continue;
					case 59:
						goto IL_EA8;
					case 60:
						array[4] = 140 - 46;
						num2 = 375;
						continue;
					case 61:
						array2[10] = (byte)num7;
						num2 = 5;
						continue;
					case 62:
						num3 = 208 - 69;
						num2 = 324;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 288;
							continue;
						}
						continue;
					case 63:
						array[10] = (byte)num4;
						num2 = 127;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 96;
							continue;
						}
						continue;
					case 64:
						array2[7] = (byte)num7;
						num2 = 252;
						continue;
					case 65:
						array[25] = 187 - 62;
						num2 = 268;
						continue;
					case 66:
						array[19] = (byte)num4;
						num2 = 138;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 247;
							continue;
						}
						continue;
					case 67:
						array[27] = (byte)num3;
						num2 = 150;
						continue;
					case 68:
						num7 = 98 - 97;
						num2 = 39;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 41;
							continue;
						}
						continue;
					case 69:
						array[20] = 156 - 52;
						num2 = 224;
						continue;
					case 70:
						num13 += 8;
						num2 = 411;
						continue;
					case 71:
						array[12] = (byte)num3;
						num2 = 99;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 280;
							continue;
						}
						continue;
					case 72:
						num3 = 154 - 51;
						num2 = 149;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 225;
							continue;
						}
						continue;
					case 73:
						num14 = (num15 ^ num9);
						num2 = 146;
						continue;
					case 74:
						array2[5] = 228 - 76;
						num2 = 199;
						continue;
					case 75:
						array[18] = 245 - 81;
						num2 = 138;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 241;
							continue;
						}
						continue;
					case 76:
						array[2] = 233 - 121;
						num2 = 333;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 16;
							continue;
						}
						continue;
					case 77:
						array2[10] = 253 - 84;
						num2 = 365;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 213;
							continue;
						}
						continue;
					case 78:
						array[22] = (byte)num3;
						num2 = 132;
						continue;
					case 79:
						goto IL_3298;
					case 80:
						array[9] = 186 + 25;
						num2 = 34;
						continue;
					case 81:
						goto IL_384D;
					case 82:
						num5 = array3.Length % 4;
						num2 = 139;
						continue;
					case 83:
						num7 = 70 + 59;
						num2 = 54;
						continue;
					case 84:
						return;
					case 85:
						goto IL_2DAF;
					case 86:
						array[15] = (byte)num4;
						num2 = 36;
						continue;
					case 87:
						goto IL_15A4;
					case 88:
						goto IL_23FF;
					case 89:
						array2[1] = (byte)num8;
						num2 = 362;
						continue;
					case 90:
						array[3] = (byte)num3;
						num2 = 46;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 46;
							continue;
						}
						continue;
					case 91:
						goto IL_338A;
					case 92:
						array2[8] = (byte)num7;
						num2 = 26;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 14;
							continue;
						}
						continue;
					case 93:
						num16 = num11 * 4;
						num2 = 135;
						continue;
					case 94:
						array[9] = (byte)num4;
						num2 = 364;
						continue;
					case 95:
						num17++;
						num2 = 216;
						continue;
					case 96:
						array[1] = (byte)num4;
						num2 = 253;
						continue;
					case 97:
						goto IL_3533;
					case 98:
						array[3] = (byte)num3;
						num2 = 37;
						continue;
					case 99:
						array2[3] = (byte)num7;
						num2 = 67;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 176;
							continue;
						}
						continue;
					case 100:
						num8 = 153 - 51;
						num2 = 158;
						continue;
					case 101:
						num4 = 25 - 3;
						num2 = 290;
						continue;
					case 102:
						array[14] = (byte)num3;
						num2 = 321;
						continue;
					case 103:
						goto IL_2805;
					case 104:
						goto IL_152A;
					case 105:
						num11 = 0;
						num2 = 299;
						continue;
					case 106:
						array[16] = 218 - 72;
						num2 = 128;
						continue;
					case 107:
						num3 = 65 + 89;
						num2 = 370;
						continue;
					case 108:
						num3 = 158 + 3;
						num2 = 20;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 102;
							continue;
						}
						continue;
					case 109:
						array2[14] = 119 - 44;
						num2 = 33;
						continue;
					case 110:
						array[31] = (byte)num4;
						num2 = 62;
						continue;
					case 111:
						num8 = 131 - 43;
						num2 = 89;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 58;
							continue;
						}
						continue;
					case 112:
						array2[13] = 159 - 53;
						num2 = 219;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 404;
							continue;
						}
						continue;
					case 113:
						num18 = 0;
						num2 = 97;
						continue;
					case 114:
						array2[0] = 67 + 61;
						num2 = 111;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 98;
							continue;
						}
						continue;
					case 115:
						array[23] = (byte)num4;
						num2 = 371;
						continue;
					case 116:
						array[30] = 44 - 8;
						num2 = 316;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 149;
							continue;
						}
						continue;
					case 117:
						goto IL_CF2;
					case 118:
						num4 = 175 - 58;
						num2 = 194;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 108;
							continue;
						}
						continue;
					case 119:
						array[5] = (byte)num3;
						num2 = 386;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 303;
							continue;
						}
						continue;
					case 120:
						goto IL_E10;
					case 121:
						num7 = 107 + 85;
						num2 = 244;
						continue;
					case 122:
						num7 = 93 + 27;
						num2 = 192;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 131;
							continue;
						}
						continue;
					case 123:
						array2[10] = 219 - 73;
						num2 = 134;
						continue;
					case 124:
						goto IL_BA6;
					case 125:
						hUuLgnKhnPlS8FM7sW9.ICvKXncLcP = true;
						num2 = 4;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 84;
							continue;
						}
						continue;
					case 126:
						array2[13] = 140 - 106;
						num2 = 134;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 256;
							continue;
						}
						continue;
					case 127:
						goto IL_6EC;
					case 128:
						num3 = 166 - 55;
						num2 = 31;
						continue;
					case 129:
						num4 = 0 + 85;
						num2 = 81;
						continue;
					case 130:
						num7 = 21 + 32;
						num2 = 40;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 64;
							continue;
						}
						continue;
					case 131:
						num19 = 255U;
						num2 = 92;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 345;
							continue;
						}
						continue;
					case 132:
						array[22] = 172 - 99;
						num2 = 312;
						continue;
					case 133:
						num4 = 126 - 42;
						num2 = 24;
						continue;
					case 134:
						goto IL_20CE;
					case 135:
						goto IL_10D8;
					case 136:
						array4[num16 + 3] = (byte)((num20 & 4278190080U) >> 24);
						num2 = 47;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 343;
							continue;
						}
						continue;
					case 137:
						num3 = 221 - 73;
						num2 = 205;
						continue;
					case 138:
						array2[7] = 238 - 79;
						num2 = 90;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 300;
							continue;
						}
						continue;
					case 139:
						num12 = array3.Length / 4;
						num2 = 233;
						continue;
					case 140:
						array[25] = (byte)num3;
						num2 = 65;
						continue;
					case 141:
						num3 = 38 - 1;
						num2 = 352;
						continue;
					case 142:
						goto IL_128B;
					case 143:
						num7 = 109 + 24;
						num2 = 402;
						continue;
					case 144:
						array[26] = 35 + 10;
						num2 = 14;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 142;
							continue;
						}
						continue;
					case 145:
						num7 = 143 - 47;
						num2 = 277;
						continue;
					case 146:
						num17 = 0;
						num2 = 87;
						continue;
					case 147:
						array[18] = 108 + 119;
						num2 = 75;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 34;
							continue;
						}
						continue;
					case 148:
						array[5] = 127 - 42;
						num2 = 129;
						continue;
					case 149:
						array[27] = (byte)num3;
						num2 = 416;
						continue;
					case 150:
						num4 = 147 - 121;
						num2 = 177;
						continue;
					case 151:
						num4 = 215 + 7;
						num2 = 330;
						continue;
					case 152:
						num15 += num21;
						num2 = 40;
						continue;
					case 153:
						array2[4] = (byte)num8;
						num2 = 302;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 414;
							continue;
						}
						continue;
					case 154:
						goto IL_D47;
					case 155:
						num9 = 0U;
						num2 = 285;
						continue;
					case 156:
						num3 = 172 - 57;
						num2 = 222;
						continue;
					case 157:
						goto IL_28EC;
					case 158:
						array2[3] = (byte)num8;
						num2 = 236;
						continue;
					case 159:
						array[0] = 123 + 118;
						num2 = 4;
						continue;
					case 160:
						num4 = 109 + 32;
						num2 = 201;
						continue;
					case 161:
						num4 = 200 - 99;
						num2 = 29;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 392;
							continue;
						}
						continue;
					case 162:
						goto IL_EFD;
					case 163:
						num3 = 145 + 96;
						num2 = 189;
						continue;
					case 164:
						num8 = 21 + 93;
						num2 = 94;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 294;
							continue;
						}
						continue;
					case 165:
						num4 = 252 - 84;
						num2 = 14;
						continue;
					case 166:
						array[7] = 166 - 55;
						num2 = 395;
						continue;
					case 167:
						num4 = 23 + 87;
						num2 = 94;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 83;
							continue;
						}
						continue;
					case 168:
						array[20] = 228 - 76;
						num2 = 195;
						continue;
					case 169:
						goto IL_226C;
					case 170:
						array[9] = 112 + 59;
						num2 = 25;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 80;
							continue;
						}
						continue;
					case 171:
						array[29] = 251 - 83;
						num2 = 250;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 351;
							continue;
						}
						continue;
					case 172:
						array[13] = 195 - 65;
						num2 = 101;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 173:
						array[18] = 78 + 58;
						num2 = 191;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 125;
							continue;
						}
						continue;
					case 174:
						num8 = 160 - 53;
						num2 = 223;
						continue;
					case 175:
						goto IL_31A8;
					case 176:
						num8 = 218 - 72;
						num2 = 361;
						continue;
					case 177:
						array[27] = (byte)num4;
						num2 = 98;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 289;
							continue;
						}
						continue;
					case 178:
						num4 = 34 + 115;
						num2 = 110;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 10;
							continue;
						}
						continue;
					case 179:
						array5 = array2;
						num2 = 9;
						continue;
					case 180:
						num7 = 215 - 96;
						num2 = 99;
						continue;
					case 181:
						num9 <<= 8;
						num2 = 186;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 170;
							continue;
						}
						continue;
					case 182:
						num22 = array6.Length / 4;
						num2 = 297;
						continue;
					case 183:
						num4 = 93 + 47;
						num2 = 12;
						continue;
					case 184:
						break;
					case 185:
						goto IL_37B2;
					case 186:
						goto IL_1BD7;
					case 187:
						array[26] = (byte)num4;
						num2 = 311;
						continue;
					case 188:
					{
						byte[] array7 = hUuLgnKhnPlS8FM7sW9.tdKUVyKFpT4Dtc7asqr(jeCFqRmg7B63R4bEDl, (int)hUuLgnKhnPlS8FM7sW9.H96OnSKplVdGSvM0XVc(hUuLgnKhnPlS8FM7sW9.L7wGO7Kv52Y81PXTnP5(jeCFqRmg7B63R4bEDl)));
						num2 = 193;
						continue;
					}
					case 189:
						array[26] = (byte)num3;
						num2 = 32;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 28;
							continue;
						}
						continue;
					case 190:
						array2[13] = (byte)num7;
						num2 = 126;
						continue;
					case 191:
						num4 = 106 + 56;
						num2 = 204;
						continue;
					case 192:
						array2[1] = (byte)num7;
						num2 = 68;
						continue;
					case 193:
						array = new byte[32];
						num2 = 2;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 1;
							continue;
						}
						continue;
					case 194:
						array[17] = (byte)num4;
						num2 = 27;
						continue;
					case 195:
						array[20] = 68 + 67;
						num2 = 89;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 151;
							continue;
						}
						continue;
					case 196:
						array[21] = (byte)num3;
						num2 = 20;
						continue;
					case 197:
						array2[6] = 55 + 36;
						num2 = 206;
						continue;
					case 198:
						array[4] = 97 + 78;
						num2 = 0;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 0;
							continue;
						}
						continue;
					case 199:
						num7 = 162 - 41;
						num2 = 323;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 41;
							continue;
						}
						continue;
					case 200:
						num7 = 84 + 59;
						num2 = 284;
						continue;
					case 201:
						array[21] = (byte)num4;
						num2 = 399;
						continue;
					case 202:
						if (num6 != 0)
						{
							goto IL_23FF;
						}
						num2 = 120;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 27;
							continue;
						}
						continue;
					case 203:
						array2[5] = 159 - 53;
						num2 = 23;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 23;
							continue;
						}
						continue;
					case 204:
						array[19] = (byte)num4;
						num2 = 356;
						continue;
					case 205:
						array[7] = (byte)num3;
						num2 = 313;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 269;
							continue;
						}
						continue;
					case 206:
						num8 = 120 + 63;
						num2 = 72;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 274;
							continue;
						}
						continue;
					case 207:
						array[30] = 192 - 64;
						num2 = 347;
						continue;
					case 208:
						array[0] = 162 - 54;
						num2 = 159;
						continue;
					case 209:
						array[29] = 252 - 84;
						num2 = 398;
						continue;
					case 210:
						goto IL_363D;
					case 211:
						array[7] = (byte)num3;
						num2 = 101;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 306;
							continue;
						}
						continue;
					case 212:
					{
						byte[] array7;
						array3 = array7;
						num2 = 82;
						continue;
					}
					case 213:
						array[2] = 220 - 73;
						num2 = 273;
						continue;
					case 214:
						array[25] = (byte)num3;
						num2 = 144;
						continue;
					case 215:
						goto IL_2C5C;
					case 216:
						goto IL_15A4;
					case 217:
						num3 = 94 + 52;
						num2 = 325;
						continue;
					case 218:
						goto IL_1C3A;
					case 219:
						array2[3] = 82 + 22;
						num2 = 100;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 60;
							continue;
						}
						continue;
					case 220:
						num8 = 252 - 84;
						num2 = 319;
						continue;
					case 221:
						array[10] = 101 + 80;
						num2 = 328;
						continue;
					case 222:
						goto IL_A1B;
					case 223:
						array2[3] = (byte)num8;
						num2 = 180;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 15;
							continue;
						}
						continue;
					case 224:
						num4 = 174 - 58;
						num2 = 281;
						continue;
					case 225:
						array[27] = (byte)num3;
						num2 = 354;
						continue;
					case 226:
						num4 = 219 - 73;
						num2 = 415;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 106;
							continue;
						}
						continue;
					case 227:
						goto IL_254A;
					case 228:
						if (hUuLgnKhnPlS8FM7sW9.ICvKXncLcP)
						{
							num2 = 116;
							if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
							{
								num2 = 227;
								continue;
							}
							continue;
						}
						break;
					case 229:
						num7 = 195 - 65;
						num2 = 92;
						continue;
					case 230:
						array2[10] = (byte)num8;
						num2 = 360;
						continue;
					case 231:
						array[6] = (byte)num4;
						num2 = 262;
						continue;
					case 232:
						array2[7] = 242 - 80;
						num2 = 130;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 40;
							continue;
						}
						continue;
					case 233:
						goto IL_380C;
					case 234:
						goto IL_226C;
					case 235:
						array[15] = 90 + 49;
						num2 = 6;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 106;
							continue;
						}
						continue;
					case 236:
						array2[3] = 69 + 13;
						num2 = 174;
						continue;
					case 237:
						array2[12] = (byte)num7;
						num2 = 53;
						continue;
					case 238:
						num4 = 199 + 1;
						num2 = 1;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 49;
							continue;
						}
						continue;
					case 239:
						array2[7] = 79 + 120;
						num2 = 0;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 145;
							continue;
						}
						continue;
					case 240:
						array2[13] = (byte)num8;
						num2 = 58;
						continue;
					case 241:
						array[18] = 59 + 82;
						num2 = 173;
						continue;
					case 242:
						num3 = 205 - 87;
						num2 = 203;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 214;
							continue;
						}
						continue;
					case 243:
						goto IL_1710;
					case 244:
						array2[0] = (byte)num7;
						num2 = 295;
						continue;
					case 245:
						goto IL_3ADB;
					case 246:
						goto IL_22FA;
					case 247:
						array[20] = 171 - 57;
						num2 = 44;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 69;
							continue;
						}
						continue;
					case 248:
						num21 = 0U;
						num2 = 348;
						continue;
					case 249:
						num12++;
						num2 = 124;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 29;
							continue;
						}
						continue;
					case 250:
						goto IL_3A81;
					case 251:
						num3 = 184 - 61;
						num2 = 17;
						continue;
					case 252:
						num7 = 62 + 95;
						num2 = 410;
						continue;
					case 253:
						array[1] = 3 + 32;
						num2 = 334;
						continue;
					case 254:
						array[13] = 240 - 80;
						num2 = 50;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 32;
							continue;
						}
						continue;
					case 255:
						goto IL_E10;
					case 256:
						array2[14] = 96 + 45;
						num2 = 271;
						continue;
					case 257:
						array2[9] = 79 + 93;
						num2 = 406;
						continue;
					case 258:
						goto IL_26AF;
					case 259:
						goto IL_31E4;
					case 260:
						array[29] = (byte)num3;
						num2 = 171;
						continue;
					case 261:
						array[23] = 192 - 64;
						num2 = 141;
						continue;
					case 262:
						goto IL_B6A;
					case 263:
						goto IL_226C;
					case 264:
						array2[2] = (byte)num7;
						num2 = 408;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 22;
							continue;
						}
						continue;
					case 265:
						goto IL_303A;
					case 266:
						array[18] = (byte)num3;
						num2 = 147;
						continue;
					case 267:
						array2[8] = 54 + 87;
						num2 = 69;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 412;
							continue;
						}
						continue;
					case 268:
						array[25] = 24 + 84;
						num2 = 242;
						continue;
					case 269:
						num7 = 71 + 115;
						num2 = 237;
						continue;
					case 270:
						num4 = 54 + 45;
						num2 = 15;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 96;
							continue;
						}
						continue;
					case 271:
						goto IL_143B;
					case 272:
						hUuLgnKhnPlS8FM7sW9.Y6wsMWKEljXB0lIfPRv(hUuLgnKhnPlS8FM7sW9.L7wGO7Kv52Y81PXTnP5(jeCFqRmg7B63R4bEDl), 0L);
						num2 = 307;
						continue;
					case 273:
						goto IL_24E6;
					case 274:
						array2[6] = (byte)num8;
						num2 = 138;
						continue;
					case 275:
						array[10] = (byte)num4;
						num2 = 175;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 369;
							continue;
						}
						continue;
					case 276:
						array[23] = (byte)num3;
						num2 = 10;
						continue;
					case 277:
						array2[8] = (byte)num7;
						num2 = 78;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 267;
							continue;
						}
						continue;
					case 278:
						array[13] = (byte)num4;
						num2 = 246;
						continue;
					case 279:
						array[28] = (byte)num4;
						num2 = 52;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 37;
							continue;
						}
						continue;
					case 280:
						array[12] = 165 - 55;
						num2 = 337;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 337;
							continue;
						}
						continue;
					case 281:
						array[20] = (byte)num4;
						num2 = 168;
						continue;
					case 282:
						if (num5 <= 0)
						{
							goto IL_31E4;
						}
						num2 = 2;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 155;
							continue;
						}
						continue;
					case 283:
						array[12] = (byte)num4;
						num2 = 104;
						continue;
					case 284:
						array2[2] = (byte)num7;
						num2 = 287;
						continue;
					case 285:
						num15 += num21;
						num2 = 308;
						continue;
					case 286:
						array[7] = (byte)num3;
						num2 = 2;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 15;
							continue;
						}
						continue;
					case 287:
						array2[2] = 143 - 47;
						num2 = 390;
						continue;
					case 288:
						array2[11] = 96 + 54;
						num2 = 357;
						continue;
					case 289:
						array[28] = 74 + 87;
						num2 = 165;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 122;
							continue;
						}
						continue;
					case 290:
						array[13] = (byte)num4;
						num2 = 8;
						continue;
					case 291:
						goto IL_36B7;
					case 292:
						num4 = 171 - 57;
						num2 = 63;
						continue;
					case 293:
						num4 = 10 + 117;
						num2 = 86;
						continue;
					case 294:
						goto IL_1569;
					case 295:
						array2[0] = 142 - 47;
						num2 = 114;
						continue;
					case 296:
						num4 = 143 - 47;
						num2 = 283;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 194;
							continue;
						}
						continue;
					case 297:
						num15 = 0U;
						num2 = 248;
						continue;
					case 298:
						array[3] = (byte)num3;
						num2 = 366;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 43;
							continue;
						}
						continue;
					case 299:
						goto IL_2C5C;
					case 300:
						array2[7] = 182 - 60;
						num2 = 232;
						continue;
					case 301:
						array2[12] = 118 - 17;
						num2 = 112;
						continue;
					case 302:
						array2[9] = 90 + 73;
						num2 = 257;
						continue;
					case 303:
						num7 = 38 + 85;
						num2 = 13;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 12;
							continue;
						}
						continue;
					case 304:
						goto IL_EFD;
					case 305:
						array[17] = (byte)num3;
						num2 = 121;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 238;
							continue;
						}
						continue;
					case 306:
						num4 = 62 + 81;
						num2 = 48;
						continue;
					case 307:
						array8 = new byte[0];
						num2 = 188;
						continue;
					case 308:
						num23 = 0;
						num2 = 304;
						continue;
					case 309:
						array6 = array;
						num2 = 30;
						continue;
					case 310:
						array[1] = (byte)num4;
						num2 = 183;
						continue;
					case 311:
						array[26] = 98 + 68;
						num2 = 336;
						continue;
					case 312:
						array[23] = 86 + 72;
						num2 = 407;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 311;
							continue;
						}
						continue;
					case 313:
						num3 = 127 + 108;
						num2 = 211;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 79;
							continue;
						}
						continue;
					case 314:
						array[27] = 167 - 55;
						num2 = 72;
						continue;
					case 315:
						array4[num16 + 1] = (byte)((num20 & 65280U) >> 8);
						num2 = 385;
						continue;
					case 316:
						array[31] = 11 + 72;
						num2 = 3;
						continue;
					case 317:
						array[18] = 159 - 53;
						num2 = 66;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 346;
							continue;
						}
						continue;
					case 318:
						array2[15] = 176 + 52;
						num2 = 179;
						continue;
					case 319:
						array2[6] = (byte)num8;
						num2 = 374;
						continue;
					case 320:
						goto IL_27E8;
					case 321:
						array[15] = 158 - 52;
						num2 = 117;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 293;
							continue;
						}
						continue;
					case 322:
						array[0] = (byte)num3;
						num2 = 45;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 208;
							continue;
						}
						continue;
					case 323:
						array2[5] = (byte)num7;
						num2 = 83;
						continue;
					case 324:
						array[31] = (byte)num3;
						num2 = 363;
						continue;
					case 325:
						array[22] = (byte)num3;
						num2 = 413;
						continue;
					case 326:
						array[24] = 16 + 26;
						num2 = 38;
						continue;
					case 327:
						num3 = 131 - 43;
						num2 = 47;
						continue;
					case 328:
						num4 = 56 + 3;
						num2 = 116;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 275;
							continue;
						}
						continue;
					case 329:
						array[11] = (byte)num4;
						num2 = 388;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 235;
							continue;
						}
						continue;
					case 330:
						array[20] = (byte)num4;
						num2 = 243;
						continue;
					case 331:
						num4 = 55 + 71;
						num2 = 279;
						continue;
					case 332:
						goto IL_F56;
					case 333:
						num3 = 34 + 95;
						num2 = 17;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 98;
							continue;
						}
						continue;
					case 334:
						num4 = 218 - 72;
						num2 = 250;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 310;
							continue;
						}
						continue;
					case 335:
						array2[9] = (byte)num8;
						num2 = 63;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 77;
							continue;
						}
						continue;
					case 336:
						array[26] = 48 + 83;
						num2 = 163;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 132;
							continue;
						}
						continue;
					case 337:
						array[12] = 139 - 111;
						num2 = 254;
						continue;
					case 338:
						array2[11] = 85 - 10;
						num2 = 303;
						continue;
					case 339:
						goto IL_8B6;
					case 340:
						array[11] = (byte)num4;
						num2 = 265;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 111;
							continue;
						}
						continue;
					case 341:
						num19 <<= 8;
						num2 = 70;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 15;
							continue;
						}
						continue;
					case 342:
						array[13] = (byte)num3;
						num2 = 172;
						continue;
					case 343:
						goto IL_36B7;
					case 344:
						array[28] = (byte)num4;
						num2 = 405;
						continue;
					case 345:
						num13 = 0;
						num2 = 43;
						continue;
					case 346:
						num3 = 0 + 107;
						num2 = 42;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 266;
							continue;
						}
						continue;
					case 347:
						num4 = 197 - 65;
						num2 = 57;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 21;
							continue;
						}
						continue;
					case 348:
						num9 = 0U;
						num2 = 56;
						continue;
					case 349:
						array[24] = (byte)num3;
						num2 = 79;
						continue;
					case 350:
						array4[num16] = (byte)(num20 & 255U);
						num2 = 315;
						continue;
					case 351:
						array[29] = 129 - 52;
						num2 = 207;
						continue;
					case 352:
						array[23] = (byte)num3;
						num2 = 133;
						continue;
					case 353:
						num3 = 12 + 4;
						num2 = 349;
						continue;
					case 354:
						num3 = 233 - 77;
						num2 = 67;
						continue;
					case 355:
						num3 = 131 - 97;
						num2 = 205;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 258;
							continue;
						}
						continue;
					case 356:
						array[19] = 146 - 48;
						num2 = 43;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 218;
							continue;
						}
						continue;
					case 357:
						array2[11] = 237 - 79;
						num2 = 338;
						continue;
					case 358:
						num18++;
						num2 = 372;
						continue;
					case 359:
						array[6] = (byte)num4;
						num2 = 156;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 97;
							continue;
						}
						continue;
					case 360:
						array2[10] = 143 - 32;
						num2 = 62;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 164;
							continue;
						}
						continue;
					case 361:
						array2[4] = (byte)num8;
						num2 = 131;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 383;
							continue;
						}
						continue;
					case 362:
						array2[1] = 155 - 51;
						num2 = 35;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 122;
							continue;
						}
						continue;
					case 363:
						array[31] = 82 - 17;
						num2 = 309;
						continue;
					case 364:
						array[9] = 75 + 100;
						num2 = 170;
						continue;
					case 365:
						num7 = 120 + 58;
						num2 = 61;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 53;
							continue;
						}
						continue;
					case 366:
						num4 = 183 - 61;
						num2 = 249;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 409;
							continue;
						}
						continue;
					case 367:
						goto IL_14C1;
					case 368:
						hUuLgnKhnPlS8FM7sW9.bY1FbLK3ibEVPMAng2V(memoryStream);
						num2 = 263;
						continue;
					case 369:
						array[10] = 118 + 95;
						num2 = 12;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 292;
							continue;
						}
						continue;
					case 370:
						array[2] = (byte)num3;
						num2 = 76;
						continue;
					case 371:
						goto IL_2DCB;
					case 372:
						goto IL_3533;
					case 373:
						array[22] = (byte)num4;
						num2 = 208;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 217;
							continue;
						}
						continue;
					case 374:
						num7 = 108 + 32;
						num2 = 281;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 403;
							continue;
						}
						continue;
					case 375:
						array[4] = 91 + 23;
						num2 = 80;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 117;
							continue;
						}
						continue;
					case 376:
						num3 = 42 + 56;
						num2 = 140;
						continue;
					case 377:
						num4 = 127 - 42;
						num2 = 19;
						continue;
					case 378:
						try
						{
							DeflateStream deflateStream;
							hUuLgnKhnPlS8FM7sW9.DcpJn9KWlCMtiIKaOmk(deflateStream, memoryStream);
							int num24 = 0;
							if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
							{
								num24 = 0;
							}
							switch (num24)
							{
							default:
								goto IL_D47;
							}
						}
						finally
						{
							DeflateStream deflateStream;
							if (deflateStream != null)
							{
								goto IL_9DF;
							}
							int num25 = 2;
							IL_9AA:
							switch (num25)
							{
							case 0:
								goto IL_9DF;
							case 1:
								break;
							case 2:
								break;
							default:
								goto IL_9DF;
							}
							goto EndFinally_177;
							IL_9DF:
							hUuLgnKhnPlS8FM7sW9.qEAAcSKeNNcvWMOnveV(deflateStream);
							num25 = 1;
							if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
							{
								num25 = 1;
								goto IL_9AA;
							}
							goto IL_9AA;
							EndFinally_177:;
						}
						goto IL_A1B;
					case 379:
						array[8] = 200 - 66;
						num2 = 161;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 51;
							continue;
						}
						continue;
					case 380:
						num4 = 154 - 78;
						num2 = 359;
						continue;
					case 381:
						goto IL_3ADB;
					case 382:
						array[7] = (byte)num4;
						num2 = 137;
						continue;
					case 383:
						num8 = 127 - 42;
						num2 = 153;
						continue;
					case 384:
						if (num11 == num12 - 1)
						{
							num2 = 6;
							continue;
						}
						goto IL_2805;
					case 385:
						array4[num16 + 2] = (byte)((num20 & 16711680U) >> 16);
						num2 = 136;
						continue;
					case 386:
						num4 = 43 + 42;
						num2 = 231;
						continue;
					case 387:
						num8 = 204 - 68;
						num2 = 389;
						continue;
					case 388:
						num4 = 8 + 95;
						num2 = 340;
						continue;
					case 389:
						array2[11] = (byte)num8;
						num2 = 288;
						continue;
					case 390:
						array2[2] = 252 - 84;
						num2 = 320;
						continue;
					case 391:
					{
						DeflateStream deflateStream = new DeflateStream(new MemoryStream(array8), CompressionMode.Decompress);
						num2 = 378;
						continue;
					}
					case 392:
						array[8] = (byte)num4;
						num2 = 359;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 377;
							continue;
						}
						continue;
					case 393:
						num23++;
						num2 = 162;
						continue;
					case 394:
						num8 = 97 + 107;
						num2 = 1;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 22;
							continue;
						}
						continue;
					case 395:
						num3 = 49 + 97;
						num2 = 286;
						continue;
					case 396:
						array[30] = 194 - 64;
						num2 = 116;
						continue;
					case 397:
						array[8] = (byte)num4;
						num2 = 332;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 100;
							continue;
						}
						continue;
					case 398:
						num3 = 133 - 44;
						num2 = 260;
						continue;
					case 399:
						num3 = 158 - 43;
						num2 = 196;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 68;
							continue;
						}
						continue;
					case 400:
						array[6] = (byte)num3;
						num2 = 380;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 337;
							continue;
						}
						continue;
					case 401:
						array2[8] = (byte)num8;
						num2 = 7;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 302;
							continue;
						}
						continue;
					case 402:
						array2[14] = (byte)num7;
						num2 = 109;
						continue;
					case 403:
						array2[6] = (byte)num7;
						num2 = 197;
						continue;
					case 404:
						num8 = 45 + 52;
						num2 = 240;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 197;
							continue;
						}
						continue;
					case 405:
						array[29] = 122 + 22;
						num2 = 209;
						continue;
					case 406:
						num8 = 211 + 1;
						num2 = 335;
						continue;
					case 407:
						num4 = 157 - 52;
						num2 = 115;
						continue;
					case 408:
						array2[2] = 203 + 22;
						num2 = 219;
						continue;
					case 409:
						array[4] = (byte)num4;
						num2 = 176;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
						{
							num2 = 198;
							continue;
						}
						continue;
					case 410:
						array2[7] = (byte)num7;
						num2 = 239;
						continue;
					case 411:
						goto IL_293F;
					case 412:
						array2[8] = 116 + 42;
						num2 = 229;
						continue;
					case 413:
						num3 = 58 + 21;
						num2 = 78;
						continue;
					case 414:
						array2[4] = 67 - 20;
						num2 = 250;
						continue;
					case 415:
						array[28] = (byte)num4;
						num2 = 331;
						if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 92;
							continue;
						}
						continue;
					case 416:
						array[27] = 53 + 9;
						num2 = 314;
						continue;
					case 417:
						array8 = array4;
						num2 = 202;
						if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
						{
							num2 = 134;
							continue;
						}
						continue;
					case 418:
						num3 = 79 + 99;
						num2 = 400;
						continue;
					case 419:
						array2[12] = 106 + 46;
						num2 = 30;
						if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
						{
							num2 = 39;
							continue;
						}
						continue;
					default:
						goto IL_1213;
					}
					jeCFqRmg7B63R4bEDl = new yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8(hUuLgnKhnPlS8FM7sW9.bE9oheKuxbhNoLhsCov(hUuLgnKhnPlS8FM7sW9.nfK3kcKUUq1OuFJ9G1s(typeof(yyVBrstaZqxEPNHbn5C).TypeHandle).Assembly, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 2035958866 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a)));
					num2 = 272;
					continue;
					IL_8B6:
					array6[num18] ^= array5[num18];
					num2 = 358;
					continue;
					IL_3533:
					if (num18 < array5.Length)
					{
						goto IL_8B6;
					}
					num2 = 186;
					if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
					{
						num2 = 212;
						continue;
					}
					continue;
					IL_A1B:
					array[7] = (byte)num3;
					num2 = 49;
					if (hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
					{
						num2 = 166;
						continue;
					}
					continue;
					IL_BA6:
					num10 = 0U;
					num2 = 105;
					continue;
					IL_D47:
					hUuLgnKhnPlS8FM7sW9.ChVK0WAWSU = hUuLgnKhnPlS8FM7sW9.eOcsafKdCdwyHyByCNZ(hUuLgnKhnPlS8FM7sW9.Xl0sTIKnUnfYflZOSiC(memoryStream));
					num2 = 368;
					continue;
					IL_E10:
					hUuLgnKhnPlS8FM7sW9.ChVK0WAWSU = hUuLgnKhnPlS8FM7sW9.eOcsafKdCdwyHyByCNZ(array8);
					num2 = 200;
					if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
					{
						num2 = 234;
						continue;
					}
					continue;
					IL_EFD:
					if (num23 < num5)
					{
						goto IL_31A8;
					}
					num2 = 381;
					if (!hUuLgnKhnPlS8FM7sW9.d2DWYMKfjy8qb6dxNZy())
					{
						num2 = 283;
						continue;
					}
					continue;
					IL_1213:
					num3 = 121 + 65;
					num2 = 1;
					if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
					{
						num2 = 1;
						continue;
					}
					continue;
					IL_14C1:
					memoryStream = new MemoryStream();
					num2 = 391;
					continue;
					IL_23FF:
					if (num6 != 1)
					{
						goto Block_94;
					}
					goto IL_14C1;
					IL_1BD7:
					num9 |= (uint)array3[array3.Length - (1 + num23)];
					num2 = 348;
					if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
					{
						num2 = 393;
						continue;
					}
					continue;
					IL_31A8:
					if (num23 > 0)
					{
						num2 = 181;
						continue;
					}
					goto IL_1BD7;
					IL_226C:
					hUuLgnKhnPlS8FM7sW9.fQVK146H5c = hUuLgnKhnPlS8FM7sW9.Vm2hveKI2IF9Kos2Evn((Assembly)hUuLgnKhnPlS8FM7sW9.ChVK0WAWSU);
					num2 = 125;
					continue;
					IL_2805:
					num20 = (num15 ^ num9);
					num2 = 350;
					if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
					{
						num2 = 64;
						continue;
					}
					continue;
					IL_293F:
					array4[num16 + num17] = (byte)((num14 & num19) >> num13);
					num2 = 95;
					continue;
					IL_338A:
					if (num17 > 0)
					{
						num2 = 341;
						continue;
					}
					goto IL_293F;
					IL_15A4:
					if (num17 >= num5)
					{
						goto Block_53;
					}
					goto IL_338A;
					IL_2C5C:
					if (num11 < num12)
					{
						goto IL_363D;
					}
					num2 = 417;
					if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() != null)
					{
						num2 = 203;
						continue;
					}
					continue;
					IL_31E4:
					num10 = (uint)num16;
					num2 = 152;
					continue;
					IL_363D:
					num26 = num11 % num22;
					num2 = 93;
					continue;
					IL_36B7:
					num11++;
					num2 = 38;
					if (hUuLgnKhnPlS8FM7sW9.HfNiaPKit1JilC9SNpj() == null)
					{
						num2 = 215;
						continue;
					}
					continue;
					IL_37B2:
					hUuLgnKhnPlS8FM7sW9.ChVK0WAWSU = hUuLgnKhnPlS8FM7sW9.eOcsafKdCdwyHyByCNZ(hUuLgnKhnPlS8FM7sW9.Hh8yGqKLhj8XRtNDyoV(array8, 0U));
					num2 = 169;
					continue;
					IL_3ADB:
					uint num27 = num15;
					num15 = 255U;
					uint num28 = 431147977U;
					uint num29 = 1554943180U;
					uint num30 = 1900428022U;
					uint num31 = num27;
					num29 = 7336U * (num29 & 32767U) + (num29 >> 15);
					num30 = 116380U * (num30 & 32767U) + (num30 >> 15);
					num28 = 38650U * num28 + num31;
					num29 = 93839U * (num29 & 32767U) + (num29 >> 15);
					num30 = 128385U * (num30 & 32767U) + (num30 >> 15);
					num28 = 8080U * num28 + num31;
					if (num28 == 0U)
					{
						num28 -= 1U;
					}
					uint num32 = num30 / num28 + num28;
					num28 = (num30 - num30 ^ num32) + num30;
					uint num33 = (num29 << 5 | num29 >> 27) ^ num30;
					uint num34 = num33 & 252645135U;
					num33 &= 4042322160U;
					num29 = (num33 >> 4 | num34 << 4);
					uint num35 = num30 - num30 + num30;
					num31 ^= num31 << 26;
					num31 += num28;
					num31 ^= num31 >> 3;
					num31 += num29;
					num31 ^= num31 << 3;
					num31 += num35;
					num31 = ((num28 << 20) + num30 ^ num28) + num31;
					num15 = num27 + (uint)num31;
					num2 = 384;
				}
				IL_6EC:
				array[10] = 80 + 59;
				num = 11;
				continue;
				IL_B6A:
				array[6] = 163 - 54;
				num = 418;
				continue;
				IL_CF2:
				array[4] = 125 + 22;
				num = 148;
				continue;
				IL_EA8:
				num3 = 67 - 14;
				num = 119;
				continue;
				IL_F56:
				num3 = 247 - 82;
				num = 85;
				continue;
				IL_10D8:
				num10 = (uint)(num26 * 4);
				num = 18;
				continue;
				IL_128B:
				num3 = 93 + 56;
				num = 25;
				continue;
				IL_13EF:
				array2[10] = 178 - 59;
				num = 123;
				continue;
				IL_143B:
				array2[14] = 121 + 121;
				num = 143;
				continue;
				IL_152A:
				num3 = 123 + 16;
				num = 71;
				continue;
				IL_1569:
				array2[11] = (byte)num8;
				num = 387;
				continue;
				Block_53:
				num = 291;
				continue;
				IL_1710:
				array[21] = 166 - 55;
				num = 160;
				continue;
				IL_1C3A:
				array[19] = 52 + 59;
				num = 29;
				continue;
				IL_1DA7:
				num21 = (uint)((int)array6[(int)(num10 + 3U)] << 24 | (int)array6[(int)(num10 + 2U)] << 16 | (int)array6[(int)(num10 + 1U)] << 8 | (int)array6[(int)num10]);
				num = 131;
				continue;
				IL_1FE6:
				num4 = 218 - 72;
				num = 187;
				continue;
				IL_20CE:
				num8 = 251 - 83;
				num = 230;
				continue;
				IL_22FA:
				num3 = 160 - 53;
				num = 342;
				continue;
				Block_94:
				num = 51;
				continue;
				IL_24E6:
				array[2] = 2 + 39;
				num = 107;
				continue;
				IL_26AF:
				array[16] = (byte)num3;
				num = 118;
				continue;
				IL_26FA:
				array[24] = 13 + 67;
				num = 326;
				continue;
				IL_27E8:
				num7 = 8 + 25;
				num = 264;
				continue;
				IL_28EC:
				array2[15] = 130 - 43;
				num = 318;
				continue;
				IL_2A04:
				num7 = 225 - 75;
				num = 190;
				continue;
				IL_2DAF:
				array[8] = (byte)num3;
				num = 379;
				continue;
				IL_2DCB:
				num3 = 52 + 107;
				num = 276;
				continue;
				IL_303A:
				array[11] = 218 - 72;
				num = 16;
				continue;
				IL_3298:
				array[24] = 63 + 43;
				num = 28;
				continue;
				IL_380C:
				array4 = new byte[array3.Length];
				num = 182;
				continue;
				IL_384D:
				array[5] = (byte)num4;
				num = 59;
				continue;
				IL_3A81:
				array2[5] = 110 + 47;
				num = 203;
			}
			return;
			IL_254A:;
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x00036478 File Offset: 0x00034678
		internal static string[] p8HKJ0OioB(Assembly \u0020)
		{
			if (\u0020 == typeof(hUuLgnKhnPlS8FM7sW9).Assembly)
			{
				if (!hUuLgnKhnPlS8FM7sW9.ICvKXncLcP)
				{
					hUuLgnKhnPlS8FM7sW9.y8mKbLfXe2();
				}
				List<string> list = new List<string>();
				list.AddRange(\u0020.GetManifestResourceNames());
				list.AddRange(((Assembly)hUuLgnKhnPlS8FM7sW9.ChVK0WAWSU).GetManifestResourceNames());
				return list.ToArray();
			}
			return \u0020.GetManifestResourceNames();
		}

		// Token: 0x060004FA RID: 1274 RVA: 0x000364E0 File Offset: 0x000346E0
		private static Assembly p8KKxWoBbY(object \u0020, ResolveEventArgs \u0020)
		{
			if (!hUuLgnKhnPlS8FM7sW9.ICvKXncLcP)
			{
				hUuLgnKhnPlS8FM7sW9.y8mKbLfXe2();
			}
			string name = \u0020.Name;
			for (int i = 0; i < hUuLgnKhnPlS8FM7sW9.fQVK146H5c.Length; i++)
			{
				if (hUuLgnKhnPlS8FM7sW9.fQVK146H5c[i] == name)
				{
					return (Assembly)hUuLgnKhnPlS8FM7sW9.ChVK0WAWSU;
				}
			}
			return null;
		}

		// Token: 0x060004FB RID: 1275 RVA: 0x0003653C File Offset: 0x0003473C
		public hUuLgnKhnPlS8FM7sW9()
		{
			AppDomain.CurrentDomain.ResourceResolve += hUuLgnKhnPlS8FM7sW9.p8KKxWoBbY;
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x00036560 File Offset: 0x00034760
		internal static void kLjw4iIsCLsZtxc4lksN0j()
		{
			if (!hUuLgnKhnPlS8FM7sW9.n3EKjLB1XB)
			{
				hUuLgnKhnPlS8FM7sW9.n3EKjLB1XB = true;
				new hUuLgnKhnPlS8FM7sW9();
			}
		}

		// Token: 0x060004FE RID: 1278 RVA: 0x00036598 File Offset: 0x00034798
		internal static Type nfK3kcKUUq1OuFJ9G1s(RuntimeTypeHandle A_0)
		{
			return Type.GetTypeFromHandle(A_0);
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x000365A4 File Offset: 0x000347A4
		internal static object bE9oheKuxbhNoLhsCov(object A_0, object A_1)
		{
			return A_0.GetManifestResourceStream(A_1);
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x000365B4 File Offset: 0x000347B4
		internal static object L7wGO7Kv52Y81PXTnP5(object A_0)
		{
			return A_0.vh0ry9Sq2v();
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x000365C0 File Offset: 0x000347C0
		internal static void Y6wsMWKEljXB0lIfPRv(object A_0, long A_1)
		{
			A_0.Position = A_1;
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x000365D0 File Offset: 0x000347D0
		internal static long H96OnSKplVdGSvM0XVc(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x000365DC File Offset: 0x000347DC
		internal static object tdKUVyKFpT4Dtc7asqr(object A_0, int \u0020)
		{
			return A_0.tOsmYdnGw3(\u0020);
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x000365EC File Offset: 0x000347EC
		internal static object eOcsafKdCdwyHyByCNZ(object A_0)
		{
			return hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.lwdK2UoLuO(A_0);
		}

		// Token: 0x06000505 RID: 1285 RVA: 0x000365F8 File Offset: 0x000347F8
		internal static void DcpJn9KWlCMtiIKaOmk(object A_0, object A_1)
		{
			A_0.CopyTo(A_1);
		}

		// Token: 0x06000506 RID: 1286 RVA: 0x00036608 File Offset: 0x00034808
		internal static void qEAAcSKeNNcvWMOnveV(object A_0)
		{
			((IDisposable)A_0).Dispose();
		}

		// Token: 0x06000507 RID: 1287 RVA: 0x00036614 File Offset: 0x00034814
		internal static object Xl0sTIKnUnfYflZOSiC(object A_0)
		{
			return A_0.ToArray();
		}

		// Token: 0x06000508 RID: 1288 RVA: 0x00036620 File Offset: 0x00034820
		internal static void bY1FbLK3ibEVPMAng2V(object A_0)
		{
			A_0.Dispose();
		}

		// Token: 0x06000509 RID: 1289 RVA: 0x0003662C File Offset: 0x0003482C
		internal static object Hh8yGqKLhj8XRtNDyoV(object A_0, uint \u0020)
		{
			return hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.xwkKrlRSRl(A_0, \u0020);
		}

		// Token: 0x0600050A RID: 1290 RVA: 0x0003663C File Offset: 0x0003483C
		internal static object Vm2hveKI2IF9Kos2Evn(object A_0)
		{
			return A_0.GetManifestResourceNames();
		}

		// Token: 0x0600050B RID: 1291 RVA: 0x00036648 File Offset: 0x00034848
		internal static bool d2DWYMKfjy8qb6dxNZy()
		{
			return null == null;
		}

		// Token: 0x0600050C RID: 1292 RVA: 0x00036650 File Offset: 0x00034850
		internal static object HfNiaPKit1JilC9SNpj()
		{
			return null;
		}

		// Token: 0x04000430 RID: 1072
		private static string[] fQVK146H5c = new string[0];

		// Token: 0x04000431 RID: 1073
		private static object ChVK0WAWSU = null;

		// Token: 0x04000432 RID: 1074
		private static bool ICvKXncLcP = false;

		// Token: 0x04000433 RID: 1075
		private static bool n3EKjLB1XB = false;

		// Token: 0x020000F5 RID: 245
		private enum A1CwZyK5j9tqqZgcEwQ
		{

		}

		// Token: 0x020000F6 RID: 246
		internal class JKXIIsKyCcoHwRmXUO1
		{
			// Token: 0x0600050D RID: 1293 RVA: 0x00036654 File Offset: 0x00034854
			private unsafe static uint CfkKZMoLLL(void* \u0020, uint \u0020)
			{
				uint result = 0U;
				if (BitConverter.IsLittleEndian)
				{
					result = *(uint*)\u0020;
				}
				else
				{
					switch (\u0020)
					{
					case 1U:
						result = (uint)(*(byte*)\u0020);
						break;
					case 2U:
						result = (uint)((int)(*(byte*)\u0020) | (int)((byte*)\u0020)[1] << 8);
						break;
					case 3U:
						result = (uint)((int)(*(byte*)\u0020) | (int)((byte*)\u0020)[1] << 8 | (int)((byte*)\u0020)[2] << 16);
						break;
					case 4U:
						result = (uint)((int)(*(byte*)\u0020) | (int)((byte*)\u0020)[1] << 8 | (int)((byte*)\u0020)[2] << 16 | (int)((byte*)\u0020)[3] << 24);
						break;
					}
				}
				return result;
			}

			// Token: 0x0600050E RID: 1294 RVA: 0x000366E0 File Offset: 0x000348E0
			private unsafe static bool PN1KMmedaw(void* \u0020, void* \u0020, uint \u0020)
			{
				bool flag = true;
				uint num = 0U;
				while (flag && num < \u0020)
				{
					flag = (((byte*)\u0020)[num] == ((byte*)\u0020)[num]);
					num += 1U;
				}
				return flag;
			}

			// Token: 0x0600050F RID: 1295 RVA: 0x00036718 File Offset: 0x00034918
			private unsafe static void XFoKCdBVVK(void* \u0020, byte \u0020, uint \u0020)
			{
				for (uint num = 0U; num < \u0020; num += 1U)
				{
					((byte*)\u0020)[num] = \u0020;
				}
			}

			// Token: 0x06000510 RID: 1296 RVA: 0x00036740 File Offset: 0x00034940
			private unsafe static void s5OKS2S2iC(void* \u0020, void* \u0020, uint \u0020)
			{
				for (uint num = 0U; num < \u0020; num += 1U)
				{
					((byte*)\u0020)[num] = ((byte*)\u0020)[num];
				}
			}

			// Token: 0x06000511 RID: 1297 RVA: 0x0003676C File Offset: 0x0003496C
			private unsafe static void S53KtKMymH(byte* \u0020, byte* \u0020, uint \u0020)
			{
				if (BitConverter.IsLittleEndian)
				{
					if (\u0020 < 5U)
					{
						*(int*)\u0020 = (int)(*(uint*)\u0020);
						return;
					}
					byte* ptr = \u0020 + \u0020;
					while (\u0020 < ptr)
					{
						*(int*)\u0020 = (int)(*(uint*)\u0020);
						\u0020 += 4;
						\u0020 += 4;
					}
					return;
				}
				else
				{
					if (\u0020 > 8U && \u0020 + \u0020 < \u0020)
					{
						hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.s5OKS2S2iC((void*)\u0020, (void*)\u0020, \u0020);
						return;
					}
					byte* ptr2 = \u0020 + \u0020;
					while (\u0020 < ptr2)
					{
						*\u0020 = *\u0020;
						\u0020++;
						\u0020++;
					}
					return;
				}
			}

			// Token: 0x06000512 RID: 1298 RVA: 0x000367E8 File Offset: 0x000349E8
			private unsafe static uint M4eKcFGBl9(byte[] \u0020, uint \u0020, hUuLgnKhnPlS8FM7sW9.A1CwZyK5j9tqqZgcEwQ \u0020)
			{
				uint result;
				fixed (byte[] array = \u0020)
				{
					byte* ptr;
					if (\u0020 == null || array.Length == 0)
					{
						ptr = null;
					}
					else
					{
						ptr = &array[0];
					}
					result = *(uint*)(ptr + \u0020 + (IntPtr)\u0020 * 4);
				}
				return result;
			}

			// Token: 0x06000513 RID: 1299 RVA: 0x00036824 File Offset: 0x00034A24
			public static uint mHcKmyqGLB(byte[] \u0020, uint \u0020)
			{
				return hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.M4eKcFGBl9(\u0020, \u0020, (hUuLgnKhnPlS8FM7sW9.A1CwZyK5j9tqqZgcEwQ)3);
			}

			// Token: 0x06000514 RID: 1300 RVA: 0x00036830 File Offset: 0x00034A30
			private unsafe static uint BeYKKlCHZd(byte[] \u0020, uint \u0020, byte[] \u0020)
			{
				byte* ptr;
				if (\u0020 == null || \u0020.Length == 0)
				{
					ptr = null;
				}
				else
				{
					ptr = &\u0020[0];
				}
				byte* ptr2;
				if (\u0020 == null || \u0020.Length == 0)
				{
					ptr2 = null;
				}
				else
				{
					ptr2 = &\u0020[0];
				}
				byte* ptr3 = ptr + \u0020;
				uint num = 32U;
				byte* ptr4 = ptr3 + num;
				byte* ptr5 = ptr2;
				uint* ptr6 = (uint*)ptr3;
				byte* ptr7 = ptr2 + hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.CfkKZMoLLL((void*)(ptr6 + 3), 4U);
				uint num2 = 1U;
				uint[] array = new uint[]
				{
					4U,
					0U,
					1U,
					0U,
					2U,
					0U,
					1U,
					0U,
					3U,
					0U,
					1U,
					0U,
					2U,
					0U,
					1U,
					0U
				};
				byte* ptr8 = ptr7 - 4;
				if (hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.CfkKZMoLLL((void*)(ptr6 + 4), 4U) != 1U)
				{
					hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.s5OKS2S2iC((void*)ptr2, (void*)(ptr3 + num), hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.CfkKZMoLLL((void*)(ptr6 + 3), 4U));
					return hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.CfkKZMoLLL((void*)(ptr6 + 3), 4U);
				}
				if (ptr5 >= ptr8)
				{
					ptr4 += 4;
					while (ptr5 < ptr7)
					{
						*ptr5 = *ptr4;
						ptr5++;
						ptr4++;
					}
					return (uint)((long)(ptr5 - ptr2));
				}
				for (;;)
				{
					if (num2 == 1U)
					{
						num2 = hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.CfkKZMoLLL((void*)ptr4, 4U);
						ptr4 += 4;
					}
					uint num3 = hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.CfkKZMoLLL((void*)ptr4, 4U);
					if ((num2 & 1U) == 1U)
					{
						num2 >>= 1;
						if ((num3 & 3U) == 0U)
						{
							uint num4 = (num3 & 255U) >> 2;
							hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.S53KtKMymH(ptr5, ptr5 - num4, 3U);
							ptr5 += 3;
							ptr4++;
						}
						else if ((num3 & 2U) == 0U)
						{
							uint num4 = (num3 & 65535U) >> 2;
							hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.S53KtKMymH(ptr5, ptr5 - num4, 3U);
							ptr5 += 3;
							ptr4 += 2;
						}
						else if ((num3 & 1U) == 0U)
						{
							uint num4 = (num3 & 65535U) >> 6;
							uint num5 = (num3 >> 2 & 15U) + 3U;
							hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.S53KtKMymH(ptr5, ptr5 - num4, num5);
							ptr5 += num5;
							ptr4 += 2;
						}
						else if ((num3 & 4U) == 0U)
						{
							uint num4 = (num3 & 16777215U) >> 8;
							uint num5 = (num3 >> 3 & 31U) + 3U;
							hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.S53KtKMymH(ptr5, ptr5 - num4, num5);
							ptr5 += num5;
							ptr4 += 3;
						}
						else if ((num3 & 8U) == 0U)
						{
							uint num4 = num3 >> 15;
							uint num5 = (num3 >> 4 & 2047U) + 3U;
							hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.S53KtKMymH(ptr5, ptr5 - num4, num5);
							ptr5 += num5;
							ptr4 += 4;
						}
						else
						{
							byte u = (byte)(num3 >> 16);
							uint num5 = num3 >> 4 & 4095U;
							hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.XFoKCdBVVK((void*)ptr5, u, num5);
							ptr5 += num5;
							ptr4 += 3;
						}
					}
					else
					{
						hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.S53KtKMymH(ptr5, ptr4, 4U);
						ptr5 += array[(int)(num2 & 15U)];
						ptr4 += array[(int)(num2 & 15U)];
						num2 >>= (int)((byte)array[(int)(num2 & 15U)]);
						if (ptr5 >= ptr8)
						{
							break;
						}
					}
				}
				while (ptr5 < ptr7)
				{
					if (num2 == 1U)
					{
						ptr4 += 4;
						num2 = 2147483648U;
					}
					*ptr5 = *ptr4;
					ptr5++;
					ptr4++;
					num2 >>= 1;
				}
				return (uint)((long)(ptr5 - ptr2));
			}

			// Token: 0x06000515 RID: 1301 RVA: 0x00036B50 File Offset: 0x00034D50
			internal static object lwdK2UoLuO(byte[] \u0020)
			{
				return typeof(Assembly).GetMethod(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-583370756 + -1440598365 ^ -1600000766 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3).Trim(), new Type[]
				{
					typeof(byte[])
				}).Invoke(null, new object[]
				{
					\u0020
				});
			}

			// Token: 0x06000516 RID: 1302 RVA: 0x00036BB8 File Offset: 0x00034DB8
			public static byte[] xwkKrlRSRl(byte[] \u0020, uint \u0020)
			{
				uint num = hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.mHcKmyqGLB(\u0020, \u0020);
				byte[] array = null;
				if (num != 0U)
				{
					array = new byte[num];
					hUuLgnKhnPlS8FM7sW9.JKXIIsKyCcoHwRmXUO1.BeYKKlCHZd(\u0020, \u0020, array);
				}
				return array;
			}
		}
	}
}
