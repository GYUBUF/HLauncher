﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x02000064 RID: 100
	public class VersionDataInternal
	{
		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000229 RID: 553 RVA: 0x0000A34C File Offset: 0x0000854C
		// (set) Token: 0x0600022A RID: 554 RVA: 0x0000A354 File Offset: 0x00008554
		public string Version { get; set; }

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x0600022B RID: 555 RVA: 0x0000A360 File Offset: 0x00008560
		// (set) Token: 0x0600022C RID: 556 RVA: 0x0000A368 File Offset: 0x00008568
		public string Name { get; set; }

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600022D RID: 557 RVA: 0x0000A374 File Offset: 0x00008574
		// (set) Token: 0x0600022E RID: 558 RVA: 0x0000A37C File Offset: 0x0000857C
		public string Date { get; set; }

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x0600022F RID: 559 RVA: 0x0000A388 File Offset: 0x00008588
		// (set) Token: 0x06000230 RID: 560 RVA: 0x0000A390 File Offset: 0x00008590
		public string Branch { get; set; }

		// Token: 0x06000231 RID: 561 RVA: 0x0000A39C File Offset: 0x0000859C
		public VersionDataInternal()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x0400018C RID: 396
		[CompilerGenerated]
		private string bp5JXMdyNl;

		// Token: 0x0400018D RID: 397
		[CompilerGenerated]
		private string LNlJjZ4klN;

		// Token: 0x0400018E RID: 398
		[CompilerGenerated]
		private string i7JJ5dYR8b;

		// Token: 0x0400018F RID: 399
		[CompilerGenerated]
		private string Qc4JywUnr8;
	}
}
