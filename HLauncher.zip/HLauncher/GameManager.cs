﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using AGSw7LJMkp5usDW1gK1;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x02000054 RID: 84
	public static class GameManager
	{
		// Token: 0x14000003 RID: 3
		// (add) Token: 0x060001E3 RID: 483 RVA: 0x000093B8 File Offset: 0x000075B8
		// (remove) Token: 0x060001E4 RID: 484 RVA: 0x000093F0 File Offset: 0x000075F0
		public static event Action<string> OnStatusChanged
		{
			[CompilerGenerated]
			add
			{
				Action<string> action = GameManager.UN6bn3GNPW;
				Action<string> action2;
				do
				{
					action2 = action;
					Action<string> value2 = (Action<string>)Delegate.Combine(action2, value);
					action = Interlocked.CompareExchange<Action<string>>(ref GameManager.UN6bn3GNPW, value2, action2);
				}
				while (action != action2);
			}
			[CompilerGenerated]
			remove
			{
				Action<string> action = GameManager.UN6bn3GNPW;
				Action<string> action2;
				do
				{
					action2 = action;
					Action<string> value2 = (Action<string>)Delegate.Remove(action2, value);
					action = Interlocked.CompareExchange<Action<string>>(ref GameManager.UN6bn3GNPW, value2, action2);
				}
				while (action != action2);
			}
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x060001E5 RID: 485 RVA: 0x00009428 File Offset: 0x00007628
		// (remove) Token: 0x060001E6 RID: 486 RVA: 0x00009460 File Offset: 0x00007660
		public static event Action OnGameStopped
		{
			[CompilerGenerated]
			add
			{
				Action action = GameManager.M2lb3Itusx;
				Action action2;
				do
				{
					action2 = action;
					Action value2 = (Action)Delegate.Combine(action2, value);
					action = Interlocked.CompareExchange<Action>(ref GameManager.M2lb3Itusx, value2, action2);
				}
				while (action != action2);
			}
			[CompilerGenerated]
			remove
			{
				Action action = GameManager.M2lb3Itusx;
				Action action2;
				do
				{
					action2 = action;
					Action value2 = (Action)Delegate.Remove(action2, value);
					action = Interlocked.CompareExchange<Action>(ref GameManager.M2lb3Itusx, value2, action2);
				}
				while (action != action2);
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060001E7 RID: 487 RVA: 0x00009498 File Offset: 0x00007698
		// (set) Token: 0x060001E8 RID: 488 RVA: 0x000094A0 File Offset: 0x000076A0
		public static bool LaunchedFromTray { get; private set; }

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060001E9 RID: 489 RVA: 0x000094A8 File Offset: 0x000076A8
		// (set) Token: 0x060001EA RID: 490 RVA: 0x000094B0 File Offset: 0x000076B0
		public static bool IsCleaningUp { get; private set; }

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060001EB RID: 491 RVA: 0x000094B8 File Offset: 0x000076B8
		public static bool IsGameRunning
		{
			get
			{
				return GameManager.YbRb6Xb6CX();
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060001EC RID: 492 RVA: 0x000094C0 File Offset: 0x000076C0
		public static bool IsBusy
		{
			get
			{
				return GameManager.IsGameRunning || GameManager.IsCleaningUp;
			}
		}

		// Token: 0x060001ED RID: 493 RVA: 0x000094D4 File Offset: 0x000076D4
		static GameManager()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			GameManager.nhBbuTD3VE = RJG3u8JZLa1autEARgF.METJ4myejd;
			AppDomain.CurrentDomain.ProcessExit += GameManager.<>c.DZ75umm6GV.fGh5fScpAl;
		}

		// Token: 0x060001EE RID: 494 RVA: 0x00009504 File Offset: 0x00007704
		public static void Initialize()
		{
			DriveHelper.CleanupOrphanedDrives(GameManager.nhBbuTD3VE);
			GameManager.PwRbVyOS68();
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00009518 File Offset: 0x00007718
		public static void LaunchGame(string username, string uuid, string sessionToken, string identityToken, bool isLicense, bool virtualization, bool injectPatch, string branch, int port, bool fromTray = false)
		{
			GameManager.<LaunchGame>d__28 <LaunchGame>d__;
			<LaunchGame>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<LaunchGame>d__.username = username;
			<LaunchGame>d__.uuid = uuid;
			<LaunchGame>d__.sessionToken = sessionToken;
			<LaunchGame>d__.identityToken = identityToken;
			<LaunchGame>d__.isLicense = isLicense;
			<LaunchGame>d__.virtualization = virtualization;
			<LaunchGame>d__.injectPatch = injectPatch;
			<LaunchGame>d__.branch = branch;
			<LaunchGame>d__.port = port;
			<LaunchGame>d__.fromTray = fromTray;
			<LaunchGame>d__.<>1__state = -1;
			<LaunchGame>d__.<>t__builder.Start<GameManager.<LaunchGame>d__28>(ref <LaunchGame>d__);
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x000095A0 File Offset: 0x000077A0
		public static Task StopGame()
		{
			GameManager.<StopGame>d__29 <StopGame>d__;
			<StopGame>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<StopGame>d__.<>1__state = -1;
			<StopGame>d__.<>t__builder.Start<GameManager.<StopGame>d__29>(ref <StopGame>d__);
			return <StopGame>d__.<>t__builder.Task;
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x000095DC File Offset: 0x000077DC
		private static void licbY2oJSA()
		{
			if (GameManager.U1cbvlLm1j == null)
			{
				return;
			}
			int num = -1;
			try
			{
				num = GameManager.U1cbvlLm1j.ExitCode;
			}
			catch
			{
			}
			GameManager.aZ4bfA4EEo(GameManager.BkfbW7RAhk ? i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1951063772 ^ -443816341 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c)) : ((num != 0) ? i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-800407371 ^ -1764537154 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed)).Replace(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -231992671 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770), num.ToString()) : i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1101117538 + -804724488 ^ 2109240933 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264))), false);
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x000096D0 File Offset: 0x000078D0
		private static Task AYZblhqRIm(bool \u0020)
		{
			GameManager.<Cleanup>d__31 <Cleanup>d__;
			<Cleanup>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<Cleanup>d__.wait = \u0020;
			<Cleanup>d__.<>1__state = -1;
			<Cleanup>d__.<>t__builder.Start<GameManager.<Cleanup>d__31>(ref <Cleanup>d__);
			return <Cleanup>d__.<>t__builder.Task;
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x00009714 File Offset: 0x00007914
		public static void ForceCleanupSync()
		{
			try
			{
				GameManager.kfvbOa86Ht();
				if (GameManager.D3bbEyMswY != null)
				{
					DriveHelper.RunSubst(GameManager.D3bbEyMswY.Value, null, false);
				}
				if (!string.IsNullOrEmpty(GameManager.nAxbdsXtsb))
				{
					try
					{
						PathHelper.DeleteFile(GameManager.nAxbdsXtsb);
					}
					catch
					{
					}
				}
				DriveHelper.CleanupOrphanedDrives(GameManager.nhBbuTD3VE);
			}
			catch
			{
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000979C File Offset: 0x0000799C
		private static Task PwRbVyOS68()
		{
			GameManager.<CleanupStaticLegacy>d__33 <CleanupStaticLegacy>d__;
			<CleanupStaticLegacy>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CleanupStaticLegacy>d__.<>1__state = -1;
			<CleanupStaticLegacy>d__.<>t__builder.Start<GameManager.<CleanupStaticLegacy>d__33>(ref <CleanupStaticLegacy>d__);
			return <CleanupStaticLegacy>d__.<>t__builder.Task;
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x000097D8 File Offset: 0x000079D8
		private static bool slIbDgGOpQ(Process \u0020)
		{
			bool result;
			try
			{
				result = !\u0020.HasExited;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x00009810 File Offset: 0x00007A10
		private static bool YbRb6Xb6CX()
		{
			if (GameManager.U1cbvlLm1j != null && GameManager.slIbDgGOpQ(GameManager.U1cbvlLm1j))
			{
				return true;
			}
			Process[] processesByName = Process.GetProcessesByName(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-316901148 - -1443672473 ^ 1024929539 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25));
			if (processesByName.Length == 0)
			{
				return false;
			}
			foreach (Process process in processesByName)
			{
				try
				{
					if (!process.HasExited)
					{
						return true;
					}
				}
				catch
				{
				}
				finally
				{
					process.Dispose();
				}
			}
			return false;
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x000098C8 File Offset: 0x00007AC8
		private static void kfvbOa86Ht()
		{
			foreach (Process process in Process.GetProcessesByName(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -1394094148 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091)))
			{
				try
				{
					if (!process.HasExited)
					{
						process.Kill();
					}
				}
				catch
				{
				}
				finally
				{
					process.Dispose();
				}
			}
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x00009954 File Offset: 0x00007B54
		private static void aZ4bfA4EEo(string \u0020, bool \u0020 = false)
		{
			CancellationTokenSource qfwbefVGxB = GameManager.QFwbefVGxB;
			if (qfwbefVGxB != null)
			{
				qfwbefVGxB.Cancel();
			}
			CancellationTokenSource qfwbefVGxB2 = GameManager.QFwbefVGxB;
			if (qfwbefVGxB2 != null)
			{
				qfwbefVGxB2.Dispose();
			}
			Action<string> un6bn3GNPW = GameManager.UN6bn3GNPW;
			if (un6bn3GNPW != null)
			{
				un6bn3GNPW(\u0020);
			}
			if (!\u0020 && !string.IsNullOrEmpty(\u0020))
			{
				GameManager.<>c__DisplayClass37_0 CS$<>8__locals1 = new GameManager.<>c__DisplayClass37_0();
				if (\u0020.Contains(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1812406875 << 5 ^ -319380303 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264))))
				{
					return;
				}
				GameManager.QFwbefVGxB = new CancellationTokenSource();
				CS$<>8__locals1.GdK5n7SG1L = GameManager.QFwbefVGxB.Token;
				Task.Run(new Func<Task>(CS$<>8__locals1.wPT5ewXl6q), CS$<>8__locals1.GdK5n7SG1L);
			}
		}

		// Token: 0x04000140 RID: 320
		private static readonly string nhBbuTD3VE;

		// Token: 0x04000141 RID: 321
		private static readonly Process U1cbvlLm1j;

		// Token: 0x04000142 RID: 322
		private static char? D3bbEyMswY;

		// Token: 0x04000143 RID: 323
		private static string FntbpLWTdZ;

		// Token: 0x04000144 RID: 324
		private static string yOdbF4hkZ4;

		// Token: 0x04000145 RID: 325
		private static string nAxbdsXtsb;

		// Token: 0x04000146 RID: 326
		private static bool BkfbW7RAhk;

		// Token: 0x04000147 RID: 327
		private static CancellationTokenSource QFwbefVGxB;

		// Token: 0x04000148 RID: 328
		[CompilerGenerated]
		private static Action<string> UN6bn3GNPW;

		// Token: 0x04000149 RID: 329
		[CompilerGenerated]
		private static Action M2lb3Itusx;

		// Token: 0x0400014A RID: 330
		[CompilerGenerated]
		private static bool CoAbLSUgfZ;

		// Token: 0x0400014B RID: 331
		[CompilerGenerated]
		private static bool aJLbIaZiyP;
	}
}
