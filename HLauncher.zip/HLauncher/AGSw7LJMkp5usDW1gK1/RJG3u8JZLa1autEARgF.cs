﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using gt2OLuXUIOYbfABBoJo;
using HLauncher;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

namespace AGSw7LJMkp5usDW1gK1
{
	// Token: 0x02000065 RID: 101
	internal class RJG3u8JZLa1autEARgF
	{
		// Token: 0x06000232 RID: 562 RVA: 0x0000A3B0 File Offset: 0x000085B0
		private static string bdgJCK18pp(string \u0020)
		{
			return PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.METJ4myejd,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1163144385 ^ 762391906 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f),
				\u0020,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1815417748 >> 5 ^ 538216321 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-654387379 >> 4 ^ -1787071483 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc)
			});
		}

		// Token: 0x06000233 RID: 563 RVA: 0x0000A43C File Offset: 0x0000863C
		private static string y4qJSYYT0X(string \u0020)
		{
			return PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.METJ4myejd,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -1723415767 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7),
				\u0020,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1955617249 >> 6 ^ 1777811770 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1921488460 ^ -1142393383 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0)
			});
		}

		// Token: 0x06000234 RID: 564 RVA: 0x0000A4C4 File Offset: 0x000086C4
		public static Task<Dictionary<string, VersionInfo>> DbYJt0iDIO()
		{
			RJG3u8JZLa1autEARgF.<GetManifest>d__9 <GetManifest>d__;
			<GetManifest>d__.<>t__builder = AsyncTaskMethodBuilder<Dictionary<string, VersionInfo>>.Create();
			<GetManifest>d__.<>1__state = -1;
			<GetManifest>d__.<>t__builder.Start<RJG3u8JZLa1autEARgF.<GetManifest>d__9>(ref <GetManifest>d__);
			return <GetManifest>d__.<>t__builder.Task;
		}

		// Token: 0x06000235 RID: 565 RVA: 0x0000A500 File Offset: 0x00008700
		public static Dictionary<string, VersionInfo> zu6JcfJnhU()
		{
			if (RJG3u8JZLa1autEARgF.rOLJAqNOyo != null)
			{
				return RJG3u8JZLa1autEARgF.rOLJAqNOyo;
			}
			Dictionary<string, VersionInfo> result;
			try
			{
				if (!PathHelper.FileExists(RJG3u8JZLa1autEARgF.bn9J7p6Wcf))
				{
					result = null;
				}
				else
				{
					result = (RJG3u8JZLa1autEARgF.rOLJAqNOyo = JsonConvert.DeserializeObject<Dictionary<string, VersionInfo>>(PathHelper.ReadAllText(RJG3u8JZLa1autEARgF.bn9J7p6Wcf)));
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000236 RID: 566 RVA: 0x0000A568 File Offset: 0x00008768
		public static Task<bool> Start(Label statusLabel, IProgress<int> progress, string nickname, bool isLicense, string version, string branch, bool russianPatch, bool onlinePatch, bool virtualization, int port, HytaleAccountManager accountManager = null, bool fromTray = false)
		{
			RJG3u8JZLa1autEARgF.<Start>d__11 <Start>d__;
			<Start>d__.<>t__builder = AsyncTaskMethodBuilder<bool>.Create();
			<Start>d__.statusLabel = statusLabel;
			<Start>d__.progress = progress;
			<Start>d__.nickname = nickname;
			<Start>d__.isLicense = isLicense;
			<Start>d__.version = version;
			<Start>d__.branch = branch;
			<Start>d__.russianPatch = russianPatch;
			<Start>d__.onlinePatch = onlinePatch;
			<Start>d__.virtualization = virtualization;
			<Start>d__.port = port;
			<Start>d__.accountManager = accountManager;
			<Start>d__.fromTray = fromTray;
			<Start>d__.<>1__state = -1;
			<Start>d__.<>t__builder.Start<RJG3u8JZLa1autEARgF.<Start>d__11>(ref <Start>d__);
			return <Start>d__.<>t__builder.Task;
		}

		// Token: 0x06000237 RID: 567 RVA: 0x0000A60C File Offset: 0x0000880C
		private static Task drJJml2Usn(Label \u0020, IProgress<int> \u0020, bool \u0020)
		{
			RJG3u8JZLa1autEARgF.<CheckAndDownloadTools>d__12 <CheckAndDownloadTools>d__;
			<CheckAndDownloadTools>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CheckAndDownloadTools>d__.statusLabel = \u0020;
			<CheckAndDownloadTools>d__.progress = \u0020;
			<CheckAndDownloadTools>d__.isLicense = \u0020;
			<CheckAndDownloadTools>d__.<>1__state = -1;
			<CheckAndDownloadTools>d__.<>t__builder.Start<RJG3u8JZLa1autEARgF.<CheckAndDownloadTools>d__12>(ref <CheckAndDownloadTools>d__);
			return <CheckAndDownloadTools>d__.<>t__builder.Task;
		}

		// Token: 0x06000238 RID: 568 RVA: 0x0000A660 File Offset: 0x00008860
		public static Task sJ6JKh43Ev(Label \u0020, IProgress<int> \u0020, string \u0020, string \u0020, bool \u0020, bool \u0020 = false)
		{
			RJG3u8JZLa1autEARgF.<CheckAndDownloadGame>d__13 <CheckAndDownloadGame>d__;
			<CheckAndDownloadGame>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CheckAndDownloadGame>d__.statusLabel = \u0020;
			<CheckAndDownloadGame>d__.progress = \u0020;
			<CheckAndDownloadGame>d__.version = \u0020;
			<CheckAndDownloadGame>d__.branch = \u0020;
			<CheckAndDownloadGame>d__.isLicense = \u0020;
			<CheckAndDownloadGame>d__.repair = \u0020;
			<CheckAndDownloadGame>d__.<>1__state = -1;
			<CheckAndDownloadGame>d__.<>t__builder.Start<RJG3u8JZLa1autEARgF.<CheckAndDownloadGame>d__13>(ref <CheckAndDownloadGame>d__);
			return <CheckAndDownloadGame>d__.<>t__builder.Task;
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0000A6D0 File Offset: 0x000088D0
		private static Task Ts1J2tsE4g(Label \u0020, IProgress<int> \u0020, string \u0020, bool \u0020)
		{
			RJG3u8JZLa1autEARgF.<CheckAndDownloadJava>d__14 <CheckAndDownloadJava>d__;
			<CheckAndDownloadJava>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CheckAndDownloadJava>d__.statusLabel = \u0020;
			<CheckAndDownloadJava>d__.progress = \u0020;
			<CheckAndDownloadJava>d__.branch = \u0020;
			<CheckAndDownloadJava>d__.isLicense = \u0020;
			<CheckAndDownloadJava>d__.<>1__state = -1;
			<CheckAndDownloadJava>d__.<>t__builder.Start<RJG3u8JZLa1autEARgF.<CheckAndDownloadJava>d__14>(ref <CheckAndDownloadJava>d__);
			return <CheckAndDownloadJava>d__.<>t__builder.Task;
		}

		// Token: 0x0600023A RID: 570 RVA: 0x0000A72C File Offset: 0x0000892C
		public static Task mBVJrxNkmZ()
		{
			RJG3u8JZLa1autEARgF.<CheckAndDownloadGameResources>d__18 <CheckAndDownloadGameResources>d__;
			<CheckAndDownloadGameResources>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CheckAndDownloadGameResources>d__.<>1__state = -1;
			<CheckAndDownloadGameResources>d__.<>t__builder.Start<RJG3u8JZLa1autEARgF.<CheckAndDownloadGameResources>d__18>(ref <CheckAndDownloadGameResources>d__);
			return <CheckAndDownloadGameResources>d__.<>t__builder.Task;
		}

		// Token: 0x0600023B RID: 571 RVA: 0x0000A768 File Offset: 0x00008968
		private static Task nqKJNo5rtW(Label \u0020, IProgress<int> \u0020, string \u0020, bool \u0020)
		{
			RJG3u8JZLa1autEARgF.<CheckAndDownloadGameLocalization>d__19 <CheckAndDownloadGameLocalization>d__;
			<CheckAndDownloadGameLocalization>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
			<CheckAndDownloadGameLocalization>d__.statusLabel = \u0020;
			<CheckAndDownloadGameLocalization>d__.progress = \u0020;
			<CheckAndDownloadGameLocalization>d__.branch = \u0020;
			<CheckAndDownloadGameLocalization>d__.install = \u0020;
			<CheckAndDownloadGameLocalization>d__.<>1__state = -1;
			<CheckAndDownloadGameLocalization>d__.<>t__builder.Start<RJG3u8JZLa1autEARgF.<CheckAndDownloadGameLocalization>d__19>(ref <CheckAndDownloadGameLocalization>d__);
			return <CheckAndDownloadGameLocalization>d__.<>t__builder.Task;
		}

		// Token: 0x0600023C RID: 572 RVA: 0x0000A7C4 File Offset: 0x000089C4
		private static void vQbJsQamgi(Label \u0020, IProgress<int> \u0020, int \u0020, string \u0020)
		{
			RJG3u8JZLa1autEARgF.<>c__DisplayClass20_0 CS$<>8__locals1 = new RJG3u8JZLa1autEARgF.<>c__DisplayClass20_0();
			CS$<>8__locals1.P3oZbSLR31 = \u0020;
			CS$<>8__locals1.KDVZJptdW2 = \u0020;
			try
			{
				if (\u0020 != null)
				{
					\u0020.Report(\u0020);
				}
			}
			catch
			{
			}
			if (CS$<>8__locals1.P3oZbSLR31 == null || CS$<>8__locals1.P3oZbSLR31.IsDisposed || !CS$<>8__locals1.P3oZbSLR31.IsHandleCreated)
			{
				return;
			}
			try
			{
				if (CS$<>8__locals1.P3oZbSLR31.InvokeRequired)
				{
					CS$<>8__locals1.P3oZbSLR31.BeginInvoke(new Action(CS$<>8__locals1.nUkZwXvfcE));
				}
				else
				{
					CS$<>8__locals1.P3oZbSLR31.Text = CS$<>8__locals1.KDVZJptdW2;
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600023D RID: 573 RVA: 0x0000A890 File Offset: 0x00008A90
		public RJG3u8JZLa1autEARgF()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x0600023E RID: 574 RVA: 0x0000A8A4 File Offset: 0x00008AA4
		// Note: this type is marked as 'beforefieldinit'.
		static RJG3u8JZLa1autEARgF()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			RJG3u8JZLa1autEARgF.METJ4myejd = (yNhAJGXiuLnPpwrVl1j.g8fXe2k6p6() ? PathHelper.Combine(new string[]
			{
				AppDomain.CurrentDomain.BaseDirectory,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1812406875 << 5 ^ -1081061881 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410)
			}) : PathHelper.Combine(new string[]
			{
				Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -1626152944 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0)
			}));
			RJG3u8JZLa1autEARgF.Qc8JGaHDEn = new HttpClient
			{
				Timeout = TimeSpan.FromSeconds(10.0)
			};
			RJG3u8JZLa1autEARgF.uemJT3Rkpy = PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.METJ4myejd,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--1651549092 ^ 978391371 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a)
			});
			RJG3u8JZLa1autEARgF.FWXJBRjPfp = PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.METJ4myejd,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(819711667 ^ 142288860 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7)
			});
			RJG3u8JZLa1autEARgF.wxPJqM0Vod = PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.FWXJBRjPfp,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-696204499 - -557025 ^ -299259277 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7)
			});
			RJG3u8JZLa1autEARgF.bn9J7p6Wcf = PathHelper.Combine(new string[]
			{
				RJG3u8JZLa1autEARgF.FWXJBRjPfp,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -921576689 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b)
			});
		}

		// Token: 0x0600023F RID: 575 RVA: 0x0000AA44 File Offset: 0x00008C44
		[CompilerGenerated]
		internal static void FgJJH73yQS(string \u0020, string \u0020)
		{
			PathHelper.CreateDirectory(\u0020);
			foreach (string text in PathHelper.GetFiles(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(743695506 ^ 1517318450 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215), SearchOption.TopDirectoryOnly))
			{
				string text2 = PathHelper.Combine(new string[]
				{
					\u0020,
					Path.GetFileName(text)
				});
				if (PathHelper.FileExists(text2))
				{
					PathHelper.DeleteFile(text2);
				}
				PathHelper.MoveFile(text, text2);
			}
			foreach (string text3 in PathHelper.GetDirectories(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1424072547 ^ 2006232738 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62), SearchOption.TopDirectoryOnly))
			{
				RJG3u8JZLa1autEARgF.FgJJH73yQS(text3, PathHelper.Combine(new string[]
				{
					\u0020,
					Path.GetFileName(text3)
				}));
			}
		}

		// Token: 0x04000190 RID: 400
		public static readonly string METJ4myejd;

		// Token: 0x04000191 RID: 401
		private static readonly HttpClient Qc8JGaHDEn;

		// Token: 0x04000192 RID: 402
		public static readonly string uemJT3Rkpy;

		// Token: 0x04000193 RID: 403
		private static readonly string FWXJBRjPfp;

		// Token: 0x04000194 RID: 404
		public static readonly string wxPJqM0Vod;

		// Token: 0x04000195 RID: 405
		private static readonly string bn9J7p6Wcf;

		// Token: 0x04000196 RID: 406
		private static Dictionary<string, VersionInfo> rOLJAqNOyo;

		// Token: 0x02000066 RID: 102
		public class KpEjspyJ9CKC8imGvFf
		{
			// Token: 0x06000240 RID: 576 RVA: 0x00020F68 File Offset: 0x0001F168
			public KpEjspyJ9CKC8imGvFf()
			{
				yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
				this.UwTyxLlDec = new List<RJG3u8JZLa1autEARgF.zhOFghy1IEu0KK4Z1Ff>();
				base..ctor();
			}

			// Token: 0x04000197 RID: 407
			[JsonProperty("SavedServers")]
			public List<RJG3u8JZLa1autEARgF.zhOFghy1IEu0KK4Z1Ff> UwTyxLlDec;
		}

		// Token: 0x02000067 RID: 103
		public class zhOFghy1IEu0KK4Z1Ff
		{
			// Token: 0x06000241 RID: 577 RVA: 0x00020F88 File Offset: 0x0001F188
			public zhOFghy1IEu0KK4Z1Ff()
			{
				yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
				base..ctor();
			}

			// Token: 0x04000198 RID: 408
			[JsonProperty("Id")]
			public string hO8y0YdPJO;

			// Token: 0x04000199 RID: 409
			[JsonProperty("Name")]
			public string Mv6yXqXyNo;

			// Token: 0x0400019A RID: 410
			[JsonProperty("Address")]
			public string lQyyjyZKCe;

			// Token: 0x0400019B RID: 411
			[JsonProperty("DateSaved")]
			public string bjQy5D8Cbc;
		}

		// Token: 0x02000068 RID: 104
		public class KSUrtFyygQ7ONkCGLOJ : RJG3u8JZLa1autEARgF.zhOFghy1IEu0KK4Z1Ff
		{
			// Token: 0x06000242 RID: 578 RVA: 0x00020F9C File Offset: 0x0001F19C
			public KSUrtFyygQ7ONkCGLOJ()
			{
				yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
				base..ctor();
			}

			// Token: 0x0400019C RID: 412
			[JsonProperty("Days")]
			public string dToyZ6bNfG;
		}
	}
}
