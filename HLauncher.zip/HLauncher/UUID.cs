﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace HLauncher
{
	// Token: 0x02000062 RID: 98
	public static class UUID
	{
		// Token: 0x06000221 RID: 545 RVA: 0x0000A27C File Offset: 0x0000847C
		public static string Generate(string nickname)
		{
			string result;
			using (MD5 md = MD5.Create())
			{
				byte[] bytes = Encoding.UTF8.GetBytes(nickname);
				byte[] array = md.ComputeHash(bytes);
				array[6] = ((array[6] & 15) | 48);
				array[8] = ((array[8] & 63) | 128);
				result = new Guid(array).ToString();
			}
			return result;
		}
	}
}
