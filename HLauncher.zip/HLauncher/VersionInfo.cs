﻿using System;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x02000063 RID: 99
	public class VersionInfo
	{
		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000222 RID: 546 RVA: 0x0000A2FC File Offset: 0x000084FC
		// (set) Token: 0x06000223 RID: 547 RVA: 0x0000A304 File Offset: 0x00008504
		[JsonProperty("version")]
		public string Version { get; set; }

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000224 RID: 548 RVA: 0x0000A310 File Offset: 0x00008510
		// (set) Token: 0x06000225 RID: 549 RVA: 0x0000A318 File Offset: 0x00008518
		[JsonProperty("name")]
		public string Name { get; set; }

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000226 RID: 550 RVA: 0x0000A324 File Offset: 0x00008524
		// (set) Token: 0x06000227 RID: 551 RVA: 0x0000A32C File Offset: 0x0000852C
		[JsonProperty("date")]
		public string Date { get; set; }

		// Token: 0x06000228 RID: 552 RVA: 0x0000A338 File Offset: 0x00008538
		public VersionInfo()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x04000189 RID: 393
		[CompilerGenerated]
		private string sdjJxy5SAa;

		// Token: 0x0400018A RID: 394
		[CompilerGenerated]
		private string HJuJ1MMSJ1;

		// Token: 0x0400018B RID: 395
		[CompilerGenerated]
		private string pgoJ0jkE9n;
	}
}
