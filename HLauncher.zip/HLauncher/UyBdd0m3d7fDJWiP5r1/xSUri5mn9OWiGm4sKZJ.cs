﻿using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace UyBdd0m3d7fDJWiP5r1
{
	// Token: 0x020000F3 RID: 243
	internal class xSUri5mn9OWiGm4sKZJ
	{
		// Token: 0x060004F3 RID: 1267 RVA: 0x00032360 File Offset: 0x00030560
		internal static void lLHifFIsCLsZtjvFfN0i()
		{
			if (!xSUri5mn9OWiGm4sKZJ.QfIK8swt4a)
			{
				int num = 74565;
				xSUri5mn9OWiGm4sKZJ.QfIK8swt4a = true;
				AppDomain currentDomain = AppDomain.CurrentDomain;
				xSUri5mn9OWiGm4sKZJ.GmlmzrAeOE = (num == 1193046);
				currentDomain.AssemblyResolve += xSUri5mn9OWiGm4sKZJ.GlqmLB8Pta;
				NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			}
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x000323AC File Offset: 0x000305AC
		private static Assembly GlqmLB8Pta(object \u0020, ResolveEventArgs \u0020)
		{
			Hashtable qbqmRTCATN = xSUri5mn9OWiGm4sKZJ.QBQmRTCATN;
			Assembly result;
			lock (qbqmRTCATN)
			{
				string text = \u0020.Name.Trim();
				object obj = xSUri5mn9OWiGm4sKZJ.QBQmRTCATN[text];
				if (obj == null)
				{
					try
					{
						string text2 = xSUri5mn9OWiGm4sKZJ.P7RmIl3seF(text);
						foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
						{
							if (assembly.GetName().Name.ToUpper() == text2.ToUpper())
							{
								if (!xSUri5mn9OWiGm4sKZJ.GmlmzrAeOE)
								{
									return assembly;
								}
								if (text.Contains(assembly.GetName().Version.ToString()))
								{
									return assembly;
								}
							}
						}
					}
					catch
					{
					}
				}
				if (obj == null)
				{
					try
					{
						RSACryptoServiceProvider.UseMachineKeyStore = true;
						string text3 = xSUri5mn9OWiGm4sKZJ.P7RmIl3seF(text);
						byte[] bytes = Encoding.Unicode.GetBytes(text3);
						string text4 = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(796731446 >> 3 ^ 1810104210 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156) + Convert.ToBase64String(yyVBrstaZqxEPNHbn5C.wwccjpAgAx(bytes));
						Stream manifestResourceStream = typeof(xSUri5mn9OWiGm4sKZJ).Assembly.GetManifestResourceStream(text4);
						if (manifestResourceStream != null)
						{
							try
							{
								yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8 jeCFqRmg7B63R4bEDl = new yyVBrstaZqxEPNHbn5C.JeCFqRmg7B63R4bEDl8(manifestResourceStream);
								jeCFqRmg7B63R4bEDl.vh0ry9Sq2v().Position = 0L;
								byte[] array = new byte[manifestResourceStream.Length];
								jeCFqRmg7B63R4bEDl.xWxml0H3GI(array, 0, array.Length);
								jeCFqRmg7B63R4bEDl.eBCmDZug2e();
								bool flag2 = false;
								Assembly assembly2 = null;
								try
								{
									assembly2 = Assembly.Load(array);
								}
								catch (FileLoadException)
								{
									flag2 = true;
								}
								catch (BadImageFormatException)
								{
									flag2 = true;
								}
								if (flag2)
								{
									string text5 = Path.Combine(Path.Combine(Path.GetTempPath(), text4), text3 + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2094095138 ^ -511497377 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4));
									if (!File.Exists(text5) || !xSUri5mn9OWiGm4sKZJ.ukDmaJ9ea1.ContainsKey(text5))
									{
										try
										{
											xSUri5mn9OWiGm4sKZJ.ukDmaJ9ea1[text5] = null;
											if (!Directory.Exists(Path.GetDirectoryName(text5)))
											{
												Directory.CreateDirectory(Path.GetDirectoryName(text5));
											}
											FileStream fileStream = new FileStream(text5, FileMode.Create, FileAccess.Write);
											fileStream.Write(array, 0, array.Length);
											fileStream.Close();
										}
										catch (Exception)
										{
										}
									}
									assembly2 = Assembly.LoadFile(text5);
									xSUri5mn9OWiGm4sKZJ.QBQmRTCATN.Add(text, assembly2);
								}
								else
								{
									xSUri5mn9OWiGm4sKZJ.QBQmRTCATN.Add(text, assembly2);
								}
								return assembly2;
							}
							catch (Exception)
							{
							}
						}
						goto IL_292;
					}
					catch (Exception)
					{
						goto IL_292;
					}
					goto IL_285;
					IL_292:
					return null;
				}
				IL_285:
				result = (Assembly)obj;
			}
			return result;
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x00032710 File Offset: 0x00030910
		private static string P7RmIl3seF(string \u0020)
		{
			string text = \u0020.Trim();
			int num = text.IndexOf(',');
			if (num >= 0)
			{
				text = text.Substring(0, num);
			}
			return text;
		}

		// Token: 0x060004F6 RID: 1270 RVA: 0x00032740 File Offset: 0x00030940
		public xSUri5mn9OWiGm4sKZJ()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			base..ctor();
		}

		// Token: 0x060004F7 RID: 1271 RVA: 0x00032750 File Offset: 0x00030950
		// Note: this type is marked as 'beforefieldinit'.
		static xSUri5mn9OWiGm4sKZJ()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			xSUri5mn9OWiGm4sKZJ.QBQmRTCATN = new Hashtable();
			xSUri5mn9OWiGm4sKZJ.ukDmaJ9ea1 = new Hashtable();
			xSUri5mn9OWiGm4sKZJ.GmlmzrAeOE = false;
			xSUri5mn9OWiGm4sKZJ.QfIK8swt4a = false;
		}

		// Token: 0x0400042C RID: 1068
		private static Hashtable QBQmRTCATN;

		// Token: 0x0400042D RID: 1069
		private static Hashtable ukDmaJ9ea1;

		// Token: 0x0400042E RID: 1070
		private static bool GmlmzrAeOE;

		// Token: 0x0400042F RID: 1071
		private static bool QfIK8swt4a;
	}
}
