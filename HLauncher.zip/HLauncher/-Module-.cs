﻿using System;
using ro2IpYtzntGHp8CGrmT;
using UyBdd0m3d7fDJWiP5r1;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002048 File Offset: 0x00000248
	static <Module>()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		<Module>.m8DE6EE6D147CC88();
		xSUri5mn9OWiGm4sKZJ.lLHifFIsCLsZtjvFfN0i();
	}

	// Token: 0x06000002 RID: 2 RVA: 0x0000205C File Offset: 0x0000025C
	internal static void m8DE6EE6D147CC88()
	{
	}
}
