﻿namespace HLauncher
{
	// Token: 0x020000C6 RID: 198
	public partial class SplashForm : global::System.Windows.Forms.Form
	{
		// Token: 0x0600040B RID: 1035 RVA: 0x00019A40 File Offset: 0x00017C40
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				global::System.Windows.Forms.Timer timer = this.oMYXAJgB9s;
				if (timer != null)
				{
					timer.Dispose();
				}
				global::System.Drawing.Bitmap rfuXBxnXs = this.RfuXBxnXs1;
				if (rfuXBxnXs != null)
				{
					rfuXBxnXs.Dispose();
				}
				global::System.Drawing.Font font = this.jx9XgXxmO7;
				if (font != null)
				{
					font.Dispose();
				}
				global::System.Drawing.Font font2 = this.kKJXYLypBU;
				if (font2 != null)
				{
					font2.Dispose();
				}
				global::System.Drawing.SolidBrush gppXlL93XA = this.GPpXlL93XA;
				if (gppXlL93XA != null)
				{
					gppXlL93XA.Dispose();
				}
				global::System.Drawing.SolidBrush solidBrush = this.vBjXVInxLR;
				if (solidBrush != null)
				{
					solidBrush.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		// Token: 0x04000381 RID: 897
		private global::System.Drawing.Bitmap RfuXBxnXs1;

		// Token: 0x04000384 RID: 900
		private readonly global::System.Windows.Forms.Timer oMYXAJgB9s;

		// Token: 0x04000389 RID: 905
		private readonly global::System.Drawing.Font jx9XgXxmO7;

		// Token: 0x0400038A RID: 906
		private readonly global::System.Drawing.Font kKJXYLypBU;

		// Token: 0x0400038B RID: 907
		private readonly global::System.Drawing.SolidBrush GPpXlL93XA;

		// Token: 0x0400038C RID: 908
		private readonly global::System.Drawing.SolidBrush vBjXVInxLR;
	}
}
