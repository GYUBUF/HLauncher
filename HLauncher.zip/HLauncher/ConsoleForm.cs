﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using AGSw7LJMkp5usDW1gK1;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;
using y0ve6F17gu3T12r7mYI;

namespace HLauncher
{
	// Token: 0x0200003E RID: 62
	public partial class ConsoleForm : RoundedForm
	{
		// Token: 0x0600015A RID: 346 RVA: 0x00006158 File Offset: 0x00004358
		public ConsoleForm()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.Mb8womlpJs = new List<string>();
			this.lbDw9JhnsO = new Timer
			{
				Interval = 10000
			};
			base..ctor();
			this.KlOwTSFdXK();
			bpJXyX1qocPR5dVW9GD.Q40191tEbG(this.ifFwYttQ9o.Handle, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1877665038 - 1504633712 ^ 2016471832 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156), null);
			this.X18wZG3i32();
			ServerManager.OnLogReceived += this.wB7wC7OAYj;
			ServerManager.OnStatusChanged += this.BNYwSplpve;
			this.SOtwcAfEFD(ServerManager.IsRunning);
			if (this.NF0wVj94vA != null)
			{
				this.NF0wVj94vA.ColorScheme = CustomTextBoxColorScheme.Dark;
			}
			if (this.PVNwfZXRJL != null)
			{
				this.PVNwfZXRJL.ColorScheme = CustomTextBoxColorScheme.Dark;
			}
			this.bLpwQ2rk2x = new FormDrags(this);
			if (this.YFLw6PDKpe != null)
			{
				this.bLpwQ2rk2x.AttachToControl(this.YFLw6PDKpe);
			}
		}

		// Token: 0x0600015B RID: 347 RVA: 0x00006260 File Offset: 0x00004460
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			this.jHEwMhV2cJ();
		}

		// Token: 0x0600015C RID: 348 RVA: 0x00006270 File Offset: 0x00004470
		private void X18wZG3i32()
		{
			this.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(607992573 ^ 122162360 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62);
			this.YFLw6PDKpe.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-374163162 ^ -1887765595 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22);
			PropertyInfo property = typeof(CustomTextBox).GetProperty(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1565264222 ^ -972139451 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d), BindingFlags.Instance | BindingFlags.NonPublic);
			if (property != null)
			{
				property.SetValue(this.ifFwYttQ9o, true);
			}
			this.PVNwfZXRJL.KeyDown += this.v6owB874VW;
			this.IvKwi9jx1Q.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1699465266 ^ -594760641 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70);
			this.IvKwi9jx1Q.Click += this.NFmwtcA95P;
			this.NF0wVj94vA.KeyDown += this.ILWwq3y6pF;
			this.ccmwDXWObR.Click += this.HKRw7Y32s4;
			this.lbDw9JhnsO.Tick += this.iE5wApZwO9;
			this.ifFwYttQ9o.MouseWheel += new MouseEventHandler(this.K8awN4Bvrd);
		}

		// Token: 0x0600015D RID: 349 RVA: 0x000063C0 File Offset: 0x000045C0
		private void jHEwMhV2cJ()
		{
			this.Mb8womlpJs.Clear();
			foreach (string text in ServerManager.LogHistory.ToList<string>())
			{
				if (!string.IsNullOrWhiteSpace(text))
				{
					string input = Regex.Replace(text, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2069130535 + -961544443 ^ 900669052 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0), "");
					string pattern = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1292352855 ^ -634209498 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091);
					string text2 = Regex.Replace(input, pattern, "").TrimStart(Array.Empty<char>());
					if (!string.IsNullOrWhiteSpace(text2))
					{
						this.Mb8womlpJs.Add(text2);
					}
				}
			}
			this.ifFwYttQ9o.Text = string.Join(Environment.NewLine, this.Mb8womlpJs);
			base.BeginInvoke(new Action(this.YMiwrXZVVc));
		}

		// Token: 0x0600015E RID: 350 RVA: 0x000064D4 File Offset: 0x000046D4
		private void wB7wC7OAYj(string \u0020)
		{
			ConsoleForm.<>c__DisplayClass7_0 CS$<>8__locals1 = new ConsoleForm.<>c__DisplayClass7_0();
			CS$<>8__locals1.jRO5XLOWck = this;
			CS$<>8__locals1.qju5jsVVEr = \u0020;
			if (base.IsDisposed)
			{
				return;
			}
			base.BeginInvoke(new Action(CS$<>8__locals1.P0a503ce84));
		}

		// Token: 0x0600015F RID: 351 RVA: 0x00006514 File Offset: 0x00004714
		private void BNYwSplpve(string \u0020)
		{
			ConsoleForm.<>c__DisplayClass8_0 CS$<>8__locals1 = new ConsoleForm.<>c__DisplayClass8_0();
			CS$<>8__locals1.CF85y3SccO = this;
			CS$<>8__locals1.R3w5ZoJKaj = \u0020;
			if (base.IsDisposed)
			{
				return;
			}
			base.BeginInvoke(new Action(CS$<>8__locals1.jXe55dWRae));
		}

		// Token: 0x06000160 RID: 352 RVA: 0x00006554 File Offset: 0x00004754
		private void NFmwtcA95P(object \u0020, EventArgs \u0020)
		{
			ConsoleForm.<BtnToggle_Click>d__9 <BtnToggle_Click>d__;
			<BtnToggle_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<BtnToggle_Click>d__.<>4__this = this;
			<BtnToggle_Click>d__.<>1__state = -1;
			<BtnToggle_Click>d__.<>t__builder.Start<ConsoleForm.<BtnToggle_Click>d__9>(ref <BtnToggle_Click>d__);
		}

		// Token: 0x06000161 RID: 353 RVA: 0x0000658C File Offset: 0x0000478C
		private void SOtwcAfEFD(bool \u0020)
		{
			this.IvKwi9jx1Q.Text = (\u0020 ? yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1968780863 ^ -458612161 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156) : yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-696204499 - -557025 ^ -1199199976 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156));
		}

		// Token: 0x06000162 RID: 354 RVA: 0x000065EC File Offset: 0x000047EC
		public void AppendLog(string log)
		{
			if (string.IsNullOrWhiteSpace(log))
			{
				return;
			}
			string input = Regex.Replace(log, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~234019875 ^ -1799003665 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22), "");
			string pattern = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1815417748 >> 5 ^ 1902422114 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0);
			string text = Regex.Replace(input, pattern, "").TrimStart(Array.Empty<char>());
			if (string.IsNullOrWhiteSpace(text))
			{
				return;
			}
			this.Mb8womlpJs.Add(text);
			if (!this.t73wPy6O3O)
			{
				bool flag = this.uCDw2arKDv();
				this.ifFwYttQ9o.AppendText(text + Environment.NewLine);
				if (flag)
				{
					this.YMiwrXZVVc();
				}
			}
		}

		// Token: 0x06000163 RID: 355 RVA: 0x000066B0 File Offset: 0x000048B0
		private void RNbwmCOCq3()
		{
			string text = this.NF0wVj94vA.Text;
			if (string.IsNullOrEmpty(text))
			{
				this.n40wKXQooP();
				return;
			}
			try
			{
				ConsoleForm.<>c__DisplayClass12_0 CS$<>8__locals1 = new ConsoleForm.<>c__DisplayClass12_0();
				CS$<>8__locals1.yYf51X3XAH = new Regex(text, RegexOptions.IgnoreCase);
				List<string> values = this.Mb8womlpJs.Where(new Func<string, bool>(CS$<>8__locals1.nsN5xfT7DW)).ToList<string>();
				this.t73wPy6O3O = true;
				this.ifFwYttQ9o.Text = string.Join(Environment.NewLine, values);
				this.lbDw9JhnsO.Stop();
				this.lbDw9JhnsO.Start();
			}
			catch
			{
				this.AppendLog(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1812406875 << 5 ^ -154675126 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215));
			}
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00006784 File Offset: 0x00004984
		private void n40wKXQooP()
		{
			this.lbDw9JhnsO.Stop();
			this.t73wPy6O3O = false;
			this.ifFwYttQ9o.Text = string.Join(Environment.NewLine, this.Mb8womlpJs);
			this.YMiwrXZVVc();
		}

		// Token: 0x06000165 RID: 357 RVA: 0x000067BC File Offset: 0x000049BC
		private bool uCDw2arKDv()
		{
			if (this.ifFwYttQ9o.TextLength == 0)
			{
				return true;
			}
			if (this.ifFwYttQ9o.TextLength != 0)
			{
				int selectionStart = this.ifFwYttQ9o.SelectionStart;
				int textLength = this.ifFwYttQ9o.TextLength;
				string text = this.ifFwYttQ9o.Lines.LastOrDefault<string>();
				int? num = (text != null) ? new int?(text.Length) : null;
				int? num2 = (num != null) ? new int?(textLength - num.GetValueOrDefault() - 1) : null;
				return selectionStart >= num2.GetValueOrDefault() & num2 != null;
			}
			return true;
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00006874 File Offset: 0x00004A74
		private void YMiwrXZVVc()
		{
			this.ifFwYttQ9o.SelectionStart = this.ifFwYttQ9o.TextLength;
			this.ifFwYttQ9o.SelectionLength = 0;
			this.ifFwYttQ9o.ScrollToCaret();
		}

		// Token: 0x06000167 RID: 359 RVA: 0x000068A4 File Offset: 0x00004AA4
		private void K8awN4Bvrd(object \u0020, EventArgs \u0020)
		{
			if (this.t73wPy6O3O)
			{
				this.lbDw9JhnsO.Stop();
				this.lbDw9JhnsO.Start();
			}
		}

		// Token: 0x06000168 RID: 360 RVA: 0x000068C8 File Offset: 0x00004AC8
		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			ServerManager.OnLogReceived -= this.wB7wC7OAYj;
			ServerManager.OnStatusChanged -= this.BNYwSplpve;
			if (this.lbDw9JhnsO != null)
			{
				this.lbDw9JhnsO.Stop();
				this.lbDw9JhnsO.Dispose();
			}
			base.OnFormClosing(e);
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00006920 File Offset: 0x00004B20
		private void T5Sws4u5KH(object \u0020, EventArgs \u0020)
		{
			base.Close();
		}

		// Token: 0x0600016A RID: 362 RVA: 0x00006928 File Offset: 0x00004B28
		private void ws5wHUc5U9(object \u0020, EventArgs \u0020)
		{
			base.TopMost = !base.TopMost;
			this.V6XwlxMVHq.BackColor = (base.TopMost ? Color.FromArgb(80, 80, 80) : Color.Transparent);
		}

		// Token: 0x0600016B RID: 363 RVA: 0x00006964 File Offset: 0x00004B64
		private void Qfuw4jcVXE(object \u0020, EventArgs \u0020)
		{
			this.RNbwmCOCq3();
		}

		// Token: 0x0600016C RID: 364 RVA: 0x0000696C File Offset: 0x00004B6C
		private void BoewGrOKgY(object \u0020, EventArgs \u0020)
		{
			try
			{
				string text = PathHelper.Combine(new string[]
				{
					RJG3u8JZLa1autEARgF.METJ4myejd,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-704542734 ^ -922067211 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3)
				});
				if (!PathHelper.DirectoryExists(text))
				{
					this.AppendLog(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1577388857 >> 1 ^ -1207305306 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc));
				}
				else
				{
					Process.Start(text);
				}
			}
			catch (Exception arg)
			{
				this.AppendLog(string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(198208080 ^ 1978559622 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25), arg));
			}
		}

		// Token: 0x0600016E RID: 366 RVA: 0x00006A54 File Offset: 0x00004C54
		private void KlOwTSFdXK()
		{
			CustomTextBoxColorScheme customTextBoxColorScheme = new CustomTextBoxColorScheme();
			CustomTextBoxColorScheme customTextBoxColorScheme2 = new CustomTextBoxColorScheme();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ConsoleForm));
			this.ifFwYttQ9o = new TextBox();
			this.V6XwlxMVHq = new CustomButton();
			this.NF0wVj94vA = new CustomTextBox();
			this.ccmwDXWObR = new CustomButton();
			this.YFLw6PDKpe = new Label();
			this.dTtwOULjUr = new CustomButton();
			this.PVNwfZXRJL = new CustomTextBox();
			this.IvKwi9jx1Q = new CustomButton();
			this.GmowUUns1q = new CustomButton();
			base.SuspendLayout();
			this.ifFwYttQ9o.BackColor = Color.Black;
			this.ifFwYttQ9o.BorderStyle = BorderStyle.None;
			this.ifFwYttQ9o.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -821561319 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e), 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ifFwYttQ9o.ForeColor = Color.White;
			this.ifFwYttQ9o.Location = new Point(0, 30);
			this.ifFwYttQ9o.Multiline = true;
			this.ifFwYttQ9o.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1479692193 ^ 1056574237 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22);
			this.ifFwYttQ9o.ReadOnly = true;
			this.ifFwYttQ9o.ScrollBars = ScrollBars.Both;
			this.ifFwYttQ9o.Size = new Size(800, 420);
			this.ifFwYttQ9o.TabIndex = 15;
			this.ifFwYttQ9o.WordWrap = false;
			this.V6XwlxMVHq.BackColor = Color.FromArgb(18, 18, 18);
			this.V6XwlxMVHq.FlatAppearance.BorderSize = 0;
			this.V6XwlxMVHq.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.V6XwlxMVHq.FlatStyle = FlatStyle.Flat;
			this.V6XwlxMVHq.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1921488460 ^ -986420989 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.V6XwlxMVHq.ForeColor = Color.Transparent;
			this.V6XwlxMVHq.Location = new Point(0, 0);
			this.V6XwlxMVHq.Margin = new Padding(0);
			this.V6XwlxMVHq.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-2068305038 ^ 1998504228 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1);
			this.V6XwlxMVHq.Size = new Size(30, 30);
			this.V6XwlxMVHq.TabIndex = 19;
			this.V6XwlxMVHq.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1346391437 ^ 377200461 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e);
			this.V6XwlxMVHq.UseVisualStyleBackColor = false;
			this.V6XwlxMVHq.Click += this.ws5wHUc5U9;
			customTextBoxColorScheme.BorderColor = Color.FromArgb(140, 185, 209, 234);
			customTextBoxColorScheme.CursorColor = Color.FromArgb(255, 255, 255);
			customTextBoxColorScheme.ForeColor = Color.FromArgb(255, 255, 255);
			customTextBoxColorScheme.BackColor = Color.FromArgb(153, 180, 209);
			customTextBoxColorScheme.SelectionColor = Color.FromArgb(100, 255, 255, 255);
			this.NF0wVj94vA.ColorScheme = customTextBoxColorScheme;
			this.NF0wVj94vA.Cursor = Cursors.IBeam;
			this.NF0wVj94vA.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1477603883 ^ -1121278395 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), 10f);
			this.NF0wVj94vA.ForeColor = Color.White;
			this.NF0wVj94vA.Location = new Point(562, 3);
			this.NF0wVj94vA.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--132453396 ^ 1336480865 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3);
			this.NF0wVj94vA.PasswordChar = '\0';
			this.NF0wVj94vA.Size = new Size(175, 25);
			this.NF0wVj94vA.TabIndex = 18;
			this.ccmwDXWObR.BackColor = Color.FromArgb(18, 18, 18);
			this.ccmwDXWObR.FlatAppearance.BorderSize = 0;
			this.ccmwDXWObR.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.ccmwDXWObR.FlatStyle = FlatStyle.Flat;
			this.ccmwDXWObR.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1674539608 ^ 1005510531 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.ccmwDXWObR.ForeColor = Color.Transparent;
			this.ccmwDXWObR.Location = new Point(740, 0);
			this.ccmwDXWObR.Margin = new Padding(0);
			this.ccmwDXWObR.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1812406875 << 5 ^ -1611688627 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3);
			this.ccmwDXWObR.Size = new Size(30, 30);
			this.ccmwDXWObR.TabIndex = 17;
			this.ccmwDXWObR.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1084619761 ^ -1766199294 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18);
			this.ccmwDXWObR.UseVisualStyleBackColor = false;
			this.ccmwDXWObR.Click += this.Qfuw4jcVXE;
			this.YFLw6PDKpe.Anchor = AnchorStyles.Left;
			this.YFLw6PDKpe.AutoSize = true;
			this.YFLw6PDKpe.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--238918963 ^ 1068041012 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20), 9.75f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.YFLw6PDKpe.ForeColor = SystemColors.Control;
			this.YFLw6PDKpe.Location = new Point(33, 7);
			this.YFLw6PDKpe.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1814540806 ^ 484706355 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a);
			this.YFLw6PDKpe.Size = new Size(70, 18);
			this.YFLw6PDKpe.TabIndex = 16;
			this.YFLw6PDKpe.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1067281372 ^ -1740425057 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6505fc2fa90b42148a1f8a1944a2f09a);
			this.dTtwOULjUr.BackColor = Color.DarkRed;
			this.dTtwOULjUr.FlatAppearance.BorderSize = 0;
			this.dTtwOULjUr.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.dTtwOULjUr.FlatStyle = FlatStyle.Flat;
			this.dTtwOULjUr.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-571302991 + -886974362 ^ -1618708680 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.dTtwOULjUr.ForeColor = Color.Transparent;
			this.dTtwOULjUr.Location = new Point(770, 0);
			this.dTtwOULjUr.Margin = new Padding(0);
			this.dTtwOULjUr.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(723568593 ^ 837280805 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142);
			this.dTtwOULjUr.Size = new Size(30, 30);
			this.dTtwOULjUr.TabIndex = 14;
			this.dTtwOULjUr.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1283755699 ^ -1387260400 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562);
			this.dTtwOULjUr.UseVisualStyleBackColor = false;
			this.dTtwOULjUr.Click += this.T5Sws4u5KH;
			this.PVNwfZXRJL.BackColor = SystemColors.ActiveCaptionText;
			customTextBoxColorScheme2.BorderColor = Color.FromArgb(140, 185, 209, 234);
			customTextBoxColorScheme2.CursorColor = Color.FromArgb(255, 255, 255);
			customTextBoxColorScheme2.ForeColor = Color.FromArgb(255, 255, 255);
			customTextBoxColorScheme2.BackColor = Color.FromArgb(153, 180, 209);
			customTextBoxColorScheme2.SelectionColor = Color.FromArgb(100, 255, 255, 255);
			this.PVNwfZXRJL.ColorScheme = customTextBoxColorScheme2;
			this.PVNwfZXRJL.Cursor = Cursors.IBeam;
			this.PVNwfZXRJL.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-316901148 - -1443672473 ^ 1453357459 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a), 10f);
			this.PVNwfZXRJL.ForeColor = Color.FromArgb(200, 255, 255, 255);
			this.PVNwfZXRJL.Location = new Point(176, 450);
			this.PVNwfZXRJL.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2091326168 ^ -1717582090 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142);
			this.PVNwfZXRJL.PasswordChar = '\0';
			this.PVNwfZXRJL.Size = new Size(470, 26);
			this.PVNwfZXRJL.TabIndex = 20;
			this.IvKwi9jx1Q.BackColor = Color.FromArgb(18, 18, 18);
			this.IvKwi9jx1Q.FlatAppearance.BorderSize = 0;
			this.IvKwi9jx1Q.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.IvKwi9jx1Q.FlatStyle = FlatStyle.Flat;
			this.IvKwi9jx1Q.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1292352855 ^ -871576665 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.IvKwi9jx1Q.ForeColor = Color.Transparent;
			this.IvKwi9jx1Q.Location = new Point(740, 450);
			this.IvKwi9jx1Q.Margin = new Padding(0);
			this.IvKwi9jx1Q.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(494588051 << 1 ^ 1246484679 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add);
			this.IvKwi9jx1Q.Size = new Size(60, 30);
			this.IvKwi9jx1Q.TabIndex = 21;
			this.IvKwi9jx1Q.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -521852445 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_bcad499d901540f895e61fc7be5dbf2b);
			this.IvKwi9jx1Q.UseVisualStyleBackColor = false;
			this.GmowUUns1q.BackColor = Color.FromArgb(18, 18, 18);
			this.GmowUUns1q.FlatAppearance.BorderSize = 0;
			this.GmowUUns1q.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.GmowUUns1q.FlatStyle = FlatStyle.Flat;
			this.GmowUUns1q.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1067281372 ^ -626674008 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.GmowUUns1q.ForeColor = Color.Transparent;
			this.GmowUUns1q.Location = new Point(0, 450);
			this.GmowUUns1q.Margin = new Padding(0);
			this.GmowUUns1q.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1006549809 >> 1 ^ -1673615917 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25);
			this.GmowUUns1q.Size = new Size(110, 30);
			this.GmowUUns1q.TabIndex = 22;
			this.GmowUUns1q.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1674539608 ^ 1555786123 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410);
			this.GmowUUns1q.UseVisualStyleBackColor = false;
			this.GmowUUns1q.Click += this.BoewGrOKgY;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Black;
			base.ClientSize = new Size(800, 480);
			base.Controls.Add(this.GmowUUns1q);
			base.Controls.Add(this.IvKwi9jx1Q);
			base.Controls.Add(this.PVNwfZXRJL);
			base.Controls.Add(this.ifFwYttQ9o);
			base.Controls.Add(this.V6XwlxMVHq);
			base.Controls.Add(this.NF0wVj94vA);
			base.Controls.Add(this.ccmwDXWObR);
			base.Controls.Add(this.YFLw6PDKpe);
			base.Controls.Add(this.dTtwOULjUr);
			this.ForeColor = Color.White;
			base.Icon = (Icon)componentResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1815417748 >> 5 ^ 1477301438 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967));
			base.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1512690999 ^ -1653161770 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7);
			this.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-693780468 ^ -1020486880 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a);
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000773C File Offset: 0x0000593C
		[CompilerGenerated]
		private void v6owB874VW(object \u0020, KeyEventArgs \u0020)
		{
			if (\u0020.KeyCode == Keys.Return && !string.IsNullOrWhiteSpace(this.PVNwfZXRJL.Text))
			{
				ServerManager.SendCommand(this.PVNwfZXRJL.Text);
				this.PVNwfZXRJL.Text = "";
				\u0020.SuppressKeyPress = true;
			}
		}

		// Token: 0x06000170 RID: 368 RVA: 0x00007794 File Offset: 0x00005994
		[CompilerGenerated]
		private void ILWwq3y6pF(object \u0020, KeyEventArgs \u0020)
		{
			if (\u0020.KeyCode == Keys.Return)
			{
				this.RNbwmCOCq3();
				\u0020.SuppressKeyPress = true;
			}
		}

		// Token: 0x06000171 RID: 369 RVA: 0x000077B0 File Offset: 0x000059B0
		[CompilerGenerated]
		private void HKRw7Y32s4(object \u0020, EventArgs \u0020)
		{
			this.RNbwmCOCq3();
		}

		// Token: 0x06000172 RID: 370 RVA: 0x000077B8 File Offset: 0x000059B8
		[CompilerGenerated]
		private void iE5wApZwO9(object \u0020, EventArgs \u0020)
		{
			this.n40wKXQooP();
		}

		// Token: 0x040000E3 RID: 227
		private bool t73wPy6O3O;

		// Token: 0x040000E4 RID: 228
		private readonly List<string> Mb8womlpJs;

		// Token: 0x040000E5 RID: 229
		private readonly Timer lbDw9JhnsO;

		// Token: 0x040000E6 RID: 230
		private readonly FormDrags bLpwQ2rk2x;

		// Token: 0x040000E8 RID: 232
		private TextBox ifFwYttQ9o;

		// Token: 0x040000E9 RID: 233
		private CustomButton V6XwlxMVHq;

		// Token: 0x040000EA RID: 234
		private CustomTextBox NF0wVj94vA;

		// Token: 0x040000EB RID: 235
		private CustomButton ccmwDXWObR;

		// Token: 0x040000EC RID: 236
		private Label YFLw6PDKpe;

		// Token: 0x040000ED RID: 237
		private CustomButton dTtwOULjUr;

		// Token: 0x040000EE RID: 238
		private CustomTextBox PVNwfZXRJL;

		// Token: 0x040000EF RID: 239
		private CustomButton IvKwi9jx1Q;

		// Token: 0x040000F0 RID: 240
		private CustomButton GmowUUns1q;
	}
}
