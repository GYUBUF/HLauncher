﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;
using uSIbxvKkOV86OyFYPaQ;

namespace HLauncher.Properties
{
	// Token: 0x020000D7 RID: 215
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	internal class Resources
	{
		// Token: 0x0600044E RID: 1102 RVA: 0x0001A868 File Offset: 0x00018A68
		internal Resources()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x0600044F RID: 1103 RVA: 0x0001A87C File Offset: 0x00018A7C
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.RDTj8AiMPG == null)
				{
					Resources.RDTj8AiMPG = new ResourceManager("HLauncher.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.RDTj8AiMPG;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000450 RID: 1104 RVA: 0x0001A8AC File Offset: 0x00018AAC
		// (set) Token: 0x06000451 RID: 1105 RVA: 0x0001A8B4 File Offset: 0x00018AB4
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.vkEjh8l0OS;
			}
			set
			{
				Resources.vkEjh8l0OS = value;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000452 RID: 1106 RVA: 0x0001A8BC File Offset: 0x00018ABC
		internal static Bitmap background
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-146310919 ^ -2021348802 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a), Resources.vkEjh8l0OS);
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000453 RID: 1107 RVA: 0x0001A8F0 File Offset: 0x00018AF0
		internal static Bitmap clear_background
		{
			get
			{
				return (Bitmap)Resources.ResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 307818977 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b), Resources.vkEjh8l0OS);
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000454 RID: 1108 RVA: 0x0001A928 File Offset: 0x00018B28
		internal static byte[] hytale_auth_patch_1_0_SNAPSHOT
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-971337223 << 2 ^ 704557379 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20), Resources.vkEjh8l0OS);
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000455 RID: 1109 RVA: 0x0001A960 File Offset: 0x00018B60
		internal static Icon logo
		{
			get
			{
				return (Icon)Resources.ResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1006549809 >> 1 ^ -2136095638 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4), Resources.vkEjh8l0OS);
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000456 RID: 1110 RVA: 0x0001A998 File Offset: 0x00018B98
		internal static byte[] minecraft
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1822672301 ^ -391258863 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0), Resources.vkEjh8l0OS);
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000457 RID: 1111 RVA: 0x0001A9CC File Offset: 0x00018BCC
		internal static byte[] version
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~515955376 ^ -1047685193 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_52dac0565f7f422e80cc0f27df2b90e5), Resources.vkEjh8l0OS);
			}
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0001AA00 File Offset: 0x00018C00
		// Note: this type is marked as 'beforefieldinit'.
		static Resources()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			hUuLgnKhnPlS8FM7sW9.kLjw4iIsCLsZtxc4lksN0j();
		}

		// Token: 0x040003DF RID: 991
		private static ResourceManager RDTj8AiMPG;

		// Token: 0x040003E0 RID: 992
		private static CultureInfo vkEjh8l0OS;
	}
}
