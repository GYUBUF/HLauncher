﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.5.5.0")]
[assembly: NeutralResourcesLanguage("en")]
[assembly: AssemblyFileVersion("1.5.5.0")]
[assembly: Guid("846f9f5a-8a77-4642-a29a-b5b234ac1057")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("HLauncher ©  2026")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("Unofficial launcher for free play in Hytale")]
[assembly: AssemblyTitle("HLauncher")]
[assembly: AssemblyProduct("HLauncher")]
