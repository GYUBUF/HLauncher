﻿namespace HLauncher.Forms
{
	// Token: 0x020000D9 RID: 217
	public partial class AccountManager : global::RoundedForm
	{
		// Token: 0x06000468 RID: 1128 RVA: 0x0001B0E4 File Offset: 0x000192E4
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.xiDjtGcE8i != null)
			{
				this.xiDjtGcE8i.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x040003E6 RID: 998
		private global::System.ComponentModel.IContainer xiDjtGcE8i;
	}
}
