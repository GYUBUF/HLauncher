﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher.Forms
{
	// Token: 0x020000D9 RID: 217
	public partial class AccountManager : RoundedForm
	{
		// Token: 0x0600045C RID: 1116 RVA: 0x0001AA48 File Offset: 0x00018C48
		public AccountManager()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			AccountManager.<>c__DisplayClass4_0 CS$<>8__locals1 = new AccountManager.<>c__DisplayClass4_0();
			base..ctor();
			CS$<>8__locals1.MFqSaKAXTy = this;
			this.CMVjydHEgr();
			this.RAfjCn5ZXR = new FormDrags(this);
			this.RAfjCn5ZXR.AttachToControl(this.QtVjsUi0Wa);
			CS$<>8__locals1.n5DSzvcy4l = SettingsManager.Settings;
			this.lDDjZpc6Yy = (CS$<>8__locals1.n5DSzvcy4l.TransparencyEnabled ? 0.95 : 1.0);
			base.Shown += CS$<>8__locals1.KIbSRBuK8P;
			this.TbcjSIQ0mk = new HytaleAccountManager();
			this.OeCjcZC9ih.SelectedIndexChanged += this.sM6jwrtFi6;
			this.d8RjreT8o4.SelectedIndexChanged += this.V2Bjbeqcfc;
			this.lnyjk3Js91();
		}

		// Token: 0x0600045D RID: 1117 RVA: 0x0001AB20 File Offset: 0x00018D20
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			FormAnimations.StopAnimation(this.S4UjMhO66K);
			FormDrags rafjCn5ZXR = this.RAfjCn5ZXR;
			if (rafjCn5ZXR != null)
			{
				rafjCn5ZXR.DetachFromControl(this.QtVjsUi0Wa);
			}
			base.OnFormClosed(e);
		}

		// Token: 0x0600045E RID: 1118 RVA: 0x0001AB54 File Offset: 0x00018D54
		private void lnyjk3Js91()
		{
			this.OeCjcZC9ih.Items.Clear();
			List<HytaleAccount> list = this.TbcjSIQ0mk.Accounts.OrderBy(new Func<HytaleAccount, string>(AccountManager.<>c.Ex4SLTmTjN.KVZS32pyTi)).ToList<HytaleAccount>();
			if (list.Count > 0)
			{
				ComboBox.ObjectCollection items = this.OeCjcZC9ih.Items;
				object[] items2 = list.ToArray();
				items.AddRange(items2);
				this.OeCjcZC9ih.SelectedIndex = 0;
			}
			else
			{
				this.tssjxK24Ok();
			}
			this.lSvj547b7h();
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0001ABEC File Offset: 0x00018DEC
		private void sM6jwrtFi6(object \u0020, EventArgs \u0020)
		{
			AccountManager.<>c__DisplayClass7_0 CS$<>8__locals1 = new AccountManager.<>c__DisplayClass7_0();
			this.d8RjreT8o4.Items.Clear();
			object selectedItem = this.OeCjcZC9ih.SelectedItem;
			CS$<>8__locals1.M0KthBFhiK = (selectedItem as HytaleAccount);
			if (CS$<>8__locals1.M0KthBFhiK != null && CS$<>8__locals1.M0KthBFhiK.Profiles != null && CS$<>8__locals1.M0KthBFhiK.Profiles.Count > 0)
			{
				ComboBox.ObjectCollection items = this.d8RjreT8o4.Items;
				object[] items2 = CS$<>8__locals1.M0KthBFhiK.Profiles.ToArray();
				items.AddRange(items2);
				int num = CS$<>8__locals1.M0KthBFhiK.Profiles.FindIndex(new Predicate<HytaleProfile>(CS$<>8__locals1.QiWt8BUGwa));
				this.d8RjreT8o4.SelectedIndex = ((num != -1) ? num : 0);
			}
			this.BNCjJE2TCQ();
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0001ACB8 File Offset: 0x00018EB8
		private void V2Bjbeqcfc(object \u0020, EventArgs \u0020)
		{
			HytaleAccount hytaleAccount = this.OeCjcZC9ih.SelectedItem as HytaleAccount;
			if (hytaleAccount != null)
			{
				HytaleProfile hytaleProfile = this.d8RjreT8o4.SelectedItem as HytaleProfile;
				if (hytaleProfile != null)
				{
					hytaleAccount.SelectedProfileId = hytaleProfile.Id;
				}
			}
			this.BNCjJE2TCQ();
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0001AD08 File Offset: 0x00018F08
		private void BNCjJE2TCQ()
		{
			HytaleAccount hytaleAccount = this.OeCjcZC9ih.SelectedItem as HytaleAccount;
			if (hytaleAccount != null)
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.AppendLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2011196192 ^ 1401121947 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8));
				stringBuilder.AppendLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-582625272 ^ 588537169 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b) + hytaleAccount.Email);
				stringBuilder.AppendLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1366522423 ^ -1270100017 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142) + hytaleAccount.IdentityId);
				stringBuilder.AppendLine(string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2132757131 ^ -958906172 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70), hytaleAccount.ExpiresAt.ToLocalTime()));
				HytaleProfile hytaleProfile = this.d8RjreT8o4.SelectedItem as HytaleProfile;
				if (hytaleProfile != null)
				{
					stringBuilder.AppendLine();
					stringBuilder.AppendLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(533655012 ^ 549101225 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410));
					stringBuilder.AppendLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(582215781 ^ 1383087082 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a) + hytaleProfile.Name);
					stringBuilder.AppendLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1292352855 ^ -1529230599 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8) + hytaleProfile.Id);
					stringBuilder.AppendLine(string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1577388857 >> 1 ^ -396494668 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7), hytaleProfile.CreatedAt));
				}
				else
				{
					stringBuilder.AppendLine(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1812406875 << 5 ^ -498525387 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4));
				}
				this.wSajNu1oe2.Text = stringBuilder.ToString();
				return;
			}
			this.tssjxK24Ok();
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x0001AF04 File Offset: 0x00019104
		private void tssjxK24Ok()
		{
			this.wSajNu1oe2.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-269698511 ^ -2016817954 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f);
			this.d8RjreT8o4.Items.Clear();
		}

		// Token: 0x06000463 RID: 1123 RVA: 0x0001AF3C File Offset: 0x0001913C
		private void JeQj1AJBOn(object \u0020, EventArgs \u0020)
		{
			AccountManager.<btnAddAccount_Click>d__11 <btnAddAccount_Click>d__;
			<btnAddAccount_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<btnAddAccount_Click>d__.<>4__this = this;
			<btnAddAccount_Click>d__.<>1__state = -1;
			<btnAddAccount_Click>d__.<>t__builder.Start<AccountManager.<btnAddAccount_Click>d__11>(ref <btnAddAccount_Click>d__);
		}

		// Token: 0x06000464 RID: 1124 RVA: 0x0001AF74 File Offset: 0x00019174
		private void APVj0QRYtM(object \u0020, EventArgs \u0020)
		{
			AccountManager.<btnPlay_Click>d__12 <btnPlay_Click>d__;
			<btnPlay_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<btnPlay_Click>d__.<>4__this = this;
			<btnPlay_Click>d__.<>1__state = -1;
			<btnPlay_Click>d__.<>t__builder.Start<AccountManager.<btnPlay_Click>d__12>(ref <btnPlay_Click>d__);
		}

		// Token: 0x06000465 RID: 1125 RVA: 0x0001AFAC File Offset: 0x000191AC
		private void u8pjXresPN(object \u0020, EventArgs \u0020)
		{
			HytaleAccount hytaleAccount = this.OeCjcZC9ih.SelectedItem as HytaleAccount;
			if (hytaleAccount != null && MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-2068305038 ^ 391467360 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264) + hytaleAccount.Email + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -1394110318 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578000518 << 2 ^ -270333773 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f), MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				this.TbcjSIQ0mk.Logout(hytaleAccount);
				this.lnyjk3Js91();
			}
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x0001B05C File Offset: 0x0001925C
		private void Pl0jjrkJwY(bool \u0020)
		{
			this.ig3jmZDVVi.Enabled = \u0020;
			this.OeCjcZC9ih.Enabled = \u0020;
			this.d8RjreT8o4.Enabled = \u0020;
			this.lSvj547b7h();
			this.Cursor = (\u0020 ? Cursors.Default : Cursors.WaitCursor);
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x0001B0B0 File Offset: 0x000192B0
		private void lSvj547b7h()
		{
			bool enabled = this.OeCjcZC9ih.SelectedItem != null;
			this.fIbjKB43I1.Enabled = enabled;
			this.tIkj2HCGBG.Enabled = enabled;
		}

		// Token: 0x06000469 RID: 1129 RVA: 0x0001B10C File Offset: 0x0001930C
		private void CMVjydHEgr()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(AccountManager));
			this.OeCjcZC9ih = new ComboBox();
			this.ig3jmZDVVi = new Button();
			this.fIbjKB43I1 = new Button();
			this.tIkj2HCGBG = new Button();
			this.d8RjreT8o4 = new ComboBox();
			this.wSajNu1oe2 = new Label();
			this.QtVjsUi0Wa = new Panel();
			this.a4EjH6HLXa = new Label();
			this.lTKj4ESkl8 = new CustomButton();
			this.QtVjsUi0Wa.SuspendLayout();
			base.SuspendLayout();
			this.OeCjcZC9ih.FormattingEnabled = true;
			this.OeCjcZC9ih.Location = new Point(375, 55);
			this.OeCjcZC9ih.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1283755699 ^ -1998037912 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790);
			this.OeCjcZC9ih.Size = new Size(121, 21);
			this.OeCjcZC9ih.TabIndex = 0;
			this.ig3jmZDVVi.Location = new Point(375, 119);
			this.ig3jmZDVVi.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2107463719 ^ 1122576454 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410);
			this.ig3jmZDVVi.Size = new Size(123, 43);
			this.ig3jmZDVVi.TabIndex = 1;
			this.ig3jmZDVVi.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1279801375 ^ -388241851 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967);
			this.ig3jmZDVVi.UseVisualStyleBackColor = true;
			this.ig3jmZDVVi.Click += this.JeQj1AJBOn;
			this.fIbjKB43I1.Location = new Point(375, 168);
			this.fIbjKB43I1.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 217923394 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3);
			this.fIbjKB43I1.Size = new Size(75, 23);
			this.fIbjKB43I1.TabIndex = 2;
			this.fIbjKB43I1.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-374163162 ^ -2122830809 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091);
			this.fIbjKB43I1.UseVisualStyleBackColor = true;
			this.fIbjKB43I1.Click += this.APVj0QRYtM;
			this.tIkj2HCGBG.Location = new Point(421, 197);
			this.tIkj2HCGBG.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763766170 >> 6 ^ -599999218 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62);
			this.tIkj2HCGBG.Size = new Size(75, 23);
			this.tIkj2HCGBG.TabIndex = 3;
			this.tIkj2HCGBG.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(494588051 << 1 ^ 2093831909 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70);
			this.tIkj2HCGBG.UseVisualStyleBackColor = true;
			this.tIkj2HCGBG.Click += this.u8pjXresPN;
			this.d8RjreT8o4.FormattingEnabled = true;
			this.d8RjreT8o4.Location = new Point(377, 82);
			this.d8RjreT8o4.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(180183806 - -2122237815 ^ -506935672 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc);
			this.d8RjreT8o4.Size = new Size(121, 21);
			this.d8RjreT8o4.TabIndex = 4;
			this.wSajNu1oe2.AutoSize = true;
			this.wSajNu1oe2.Location = new Point(12, 119);
			this.wSajNu1oe2.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-352509668 ^ -900755006 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_52dac0565f7f422e80cc0f27df2b90e5);
			this.wSajNu1oe2.Size = new Size(35, 13);
			this.wSajNu1oe2.TabIndex = 5;
			this.wSajNu1oe2.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2039334965 ^ -736974041 ^ -1349694217 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb);
			this.QtVjsUi0Wa.BackColor = Color.FromArgb(26, 37, 53);
			this.QtVjsUi0Wa.Controls.Add(this.a4EjH6HLXa);
			this.QtVjsUi0Wa.Controls.Add(this.lTKj4ESkl8);
			this.QtVjsUi0Wa.ForeColor = Color.Transparent;
			this.QtVjsUi0Wa.Location = new Point(0, 0);
			this.QtVjsUi0Wa.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1441071425 ^ -1349547593 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a1f1dffb08f44e581e0c0e6fac695b4);
			this.QtVjsUi0Wa.Size = new Size(550, 30);
			this.QtVjsUi0Wa.TabIndex = 24;
			this.a4EjH6HLXa.AutoSize = true;
			this.a4EjH6HLXa.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1876786663 ^ -1911977358 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.a4EjH6HLXa.Location = new Point(9, 7);
			this.a4EjH6HLXa.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~433653721 ^ -1898807621 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_86a3fa751a9d4d26a64cf822ebe25bdc);
			this.a4EjH6HLXa.Size = new Size(30, 17);
			this.a4EjH6HLXa.TabIndex = 3;
			this.a4EjH6HLXa.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1876786663 ^ -1047601498 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1d30fd1b0072480a959ab725d2c0b406);
			this.lTKj4ESkl8.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.lTKj4ESkl8.BackColor = Color.Transparent;
			this.lTKj4ESkl8.DisabledForeColor = Color.FromArgb(100, 120, 150);
			this.lTKj4ESkl8.FlatAppearance.BorderSize = 0;
			this.lTKj4ESkl8.FlatAppearance.MouseDownBackColor = Color.Transparent;
			this.lTKj4ESkl8.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.lTKj4ESkl8.FlatStyle = FlatStyle.Flat;
			this.lTKj4ESkl8.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(796731446 >> 3 ^ 1754694452 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b), 12f, FontStyle.Bold);
			this.lTKj4ESkl8.ForeColor = SystemColors.ButtonShadow;
			this.lTKj4ESkl8.Location = new Point(517, 0);
			this.lTKj4ESkl8.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -1752755194 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df);
			this.lTKj4ESkl8.Size = new Size(30, 30);
			this.lTKj4ESkl8.TabIndex = 2;
			this.lTKj4ESkl8.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1867100645 ^ -816469422 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e);
			this.lTKj4ESkl8.UseVisualStyleBackColor = false;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(550, 330);
			base.ControlBox = false;
			base.Controls.Add(this.QtVjsUi0Wa);
			base.Controls.Add(this.wSajNu1oe2);
			base.Controls.Add(this.d8RjreT8o4);
			base.Controls.Add(this.tIkj2HCGBG);
			base.Controls.Add(this.fIbjKB43I1);
			base.Controls.Add(this.ig3jmZDVVi);
			base.Controls.Add(this.OeCjcZC9ih);
			base.Icon = (Icon)componentResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2132757131 ^ -399881296 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091));
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763766170 >> 6 ^ -659261274 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3);
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			this.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1512690999 ^ -874861435 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156);
			base.TopMost = true;
			this.QtVjsUi0Wa.ResumeLayout(false);
			this.QtVjsUi0Wa.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040003E2 RID: 994
		private readonly double lDDjZpc6Yy;

		// Token: 0x040003E3 RID: 995
		private Timer S4UjMhO66K;

		// Token: 0x040003E4 RID: 996
		private readonly FormDrags RAfjCn5ZXR;

		// Token: 0x040003E5 RID: 997
		private readonly HytaleAccountManager TbcjSIQ0mk;

		// Token: 0x040003E7 RID: 999
		private ComboBox OeCjcZC9ih;

		// Token: 0x040003E8 RID: 1000
		private Button ig3jmZDVVi;

		// Token: 0x040003E9 RID: 1001
		private Button fIbjKB43I1;

		// Token: 0x040003EA RID: 1002
		private Button tIkj2HCGBG;

		// Token: 0x040003EB RID: 1003
		private ComboBox d8RjreT8o4;

		// Token: 0x040003EC RID: 1004
		private Label wSajNu1oe2;

		// Token: 0x040003ED RID: 1005
		private Panel QtVjsUi0Wa;

		// Token: 0x040003EE RID: 1006
		private Label a4EjH6HLXa;

		// Token: 0x040003EF RID: 1007
		private CustomButton lTKj4ESkl8;
	}
}
