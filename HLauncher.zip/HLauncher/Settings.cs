﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using AGSw7LJMkp5usDW1gK1;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace HLauncher
{
	// Token: 0x020000BE RID: 190
	public partial class Settings : RoundedForm
	{
		// Token: 0x060003A9 RID: 937 RVA: 0x000169C4 File Offset: 0x00014BC4
		public Settings(Main mainForm)
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			this.adQ07JT5Tx = Color.FromArgb(20, 30, 42);
			this.otM0AtKc6w = Color.FromArgb(26, 37, 53);
			this.lKS0P6oTWU = Color.FromArgb(255, 194, 102);
			this.w6F0oP8iW2 = Color.FromArgb(45, 60, 80);
			this.vnC09eHaoT = Color.FromArgb(120, 40, 40);
			this.o3E0IoFs2p = PathHelper.Combine(new string[]
			{
				Settings.dXV0qRKIh0,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--132453396 ^ 2002482167 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_db1d01cfe4ae42d8a73bf1d218ca1add)
			});
			this.IvS0R2IZvi = PathHelper.Combine(new string[]
			{
				Settings.dXV0qRKIh0,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1699465266 ^ -594740003 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70)
			});
			Settings.<>c__DisplayClass29_0 CS$<>8__locals1 = new Settings.<>c__DisplayClass29_0();
			base..ctor();
			CS$<>8__locals1.gSySwtIE2T = this;
			this.c9B0BAkkKL = mainForm;
			this.uMr0GhLHiB();
			base.Opacity = 0.0;
			base.SuspendLayout();
			this.tvk03vuw7r = new FormDrags(this);
			this.tvk03vuw7r.AttachToControl(this.iJ9X8o7ueg);
			this.hHe0xiwfSg();
			base.ResumeLayout(false);
			base.PerformLayout();
			i18n.LanguageChanged += this.o8y0wOLwN4;
			CS$<>8__locals1.G3MSbWG7UI = SettingsManager.Settings;
			this.vY30LQIGrP = (CS$<>8__locals1.G3MSbWG7UI.TransparencyEnabled ? 0.95 : 1.0);
			base.Shown += CS$<>8__locals1.Py9Sk1O3YF;
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00016B68 File Offset: 0x00014D68
		private void o8y0wOLwN4(string \u0020)
		{
			if (base.InvokeRequired)
			{
				base.Invoke(new Action(this.m6M0TkIpiO));
				return;
			}
			this.HMA0bR9OmR();
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00016B90 File Offset: 0x00014D90
		private void HMA0bR9OmR()
		{
			this.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1037188186 + 1115589290 ^ -392554251 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091));
			if (this.tcNXhVjlMS != null)
			{
				this.tcNXhVjlMS.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1487851180 ^ -1317998450 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8));
			}
			if (this.OsD0FESp0b != null)
			{
				this.OsD0FESp0b.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1193207239 - -1972173397 ^ 249360380 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_52dac0565f7f422e80cc0f27df2b90e5));
			}
			if (this.t7g0dKl15K != null)
			{
				this.t7g0dKl15K.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-316901148 - -1443672473 ^ 1037927029 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0));
			}
			if (this.Gfu0Qy1OjS != null)
			{
				this.Gfu0Qy1OjS.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1487526596 - 1491293507 ^ -917068608 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0));
			}
			if (this.bXF0g05n14 != null)
			{
				this.bXF0g05n14.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-269698511 ^ -823221507 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8fc27a48c0ce461586dd8068b3daaced));
			}
			if (this.sqL0YVrec3 != null)
			{
				this.sqL0YVrec3.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(372928822 + -1261521798 ^ -1190387880 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fa6eced63f384885a5a1a780fe6de0e0));
			}
			if (this.PrK0ltlN90 != null)
			{
				this.PrK0ltlN90.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -1211632230 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a8a877498a714633a4b303885fe885f8));
			}
			if (this.wOW0VpZXYd != null)
			{
				this.wOW0VpZXYd.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-626376545 ^ -1668173363 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e));
			}
			if (this.qAf0DJfnUg != null)
			{
				this.qAf0DJfnUg.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1577388857 >> 1 ^ -2125396628 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1d30fd1b0072480a959ab725d2c0b406));
			}
			if (this.iYX06cdQiq != null)
			{
				this.iYX06cdQiq.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-704542734 ^ -859405104 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142));
			}
			if (this.h3l0OMfVG7 != null)
			{
				this.h3l0OMfVG7.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1067281372 ^ -1237245442 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215));
			}
			if (this.yja0f7b7hw != null)
			{
				this.yja0f7b7hw.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(219099983 << 4 ^ -1375229674 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0));
			}
			if (this.Ff40UL9v2m != null)
			{
				this.Ff40UL9v2m.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-203770899 ^ -1645980588 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c));
			}
			if (this.Q1Z0usJO8I != null)
			{
				this.Q1Z0usJO8I.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1006549809 >> 1 ^ -2119511427 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7a47c6b8b4ef4b4fb7822db54ad2e527));
			}
			if (this.WuL0vmER29 != null)
			{
				this.WuL0vmER29.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1046294268 ^ -117302951 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7));
			}
			if (this.hWc0EGtlsI != null)
			{
				this.hWc0EGtlsI.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1876786663 ^ -1270755042 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8));
			}
			if (this.XL70pQmJ5F != null)
			{
				this.XL70pQmJ5F.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 217934204 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3));
			}
			if (this.oQ70iMdjyN != null)
			{
				this.oQ70iMdjyN.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1169289335 ^ -825238433 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a));
			}
		}

		// Token: 0x060003AC RID: 940 RVA: 0x00016FC8 File Offset: 0x000151C8
		protected override void OnFormClosed(FormClosedEventArgs e)
		{
			i18n.LanguageChanged -= this.o8y0wOLwN4;
			FormAnimations.StopAnimation(this.kSk0WuTOK8);
			FormAnimations.StopAnimation(this.xKf0e8aWhS);
			FormAnimations.StopAnimation(this.WhK0n3aMHO);
			FormDrags formDrags = this.tvk03vuw7r;
			if (formDrags != null)
			{
				formDrags.DetachFromControl(this.iJ9X8o7ueg);
			}
			base.OnFormClosed(e);
		}

		// Token: 0x060003AD RID: 941 RVA: 0x0001702C File Offset: 0x0001522C
		private void UXO0JdJrkG(object \u0020, EventArgs \u0020)
		{
			base.Close();
		}

		// Token: 0x060003AE RID: 942 RVA: 0x00017034 File Offset: 0x00015234
		private void hHe0xiwfSg()
		{
			Settings.<>c__DisplayClass34_0 CS$<>8__locals1 = new Settings.<>c__DisplayClass34_0();
			CS$<>8__locals1.g5ISCCEE5F = this;
			this.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2041937264 ^ -1581820119 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3));
			this.tcNXhVjlMS.Text = i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1046294268 ^ -1559246795 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4));
			this.tcNXhVjlMS.Font = StyleManager.GetMainFont(10f);
			FlowLayoutPanel flowLayoutPanel = new FlowLayoutPanel
			{
				Dock = DockStyle.Fill,
				Padding = new Padding(20, 40, 20, 20),
				FlowDirection = FlowDirection.TopDown,
				WrapContents = false,
				AutoScroll = true,
				BackColor = this.adQ07JT5Tx
			};
			flowLayoutPanel.SuspendLayout();
			base.Controls.Add(flowLayoutPanel);
			base.Controls.SetChildIndex(this.iJ9X8o7ueg, 0);
			this.OsD0FESp0b = this.u2l0575nN6(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -404846035 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70)));
			flowLayoutPanel.Controls.Add(this.OsD0FESp0b);
			Panel panel = this.tay0yhyCGw(110);
			CS$<>8__locals1.OCeSmZeqfS = SettingsManager.Settings;
			this.Gfu0Qy1OjS = this.rd50MnTQXR(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--1651549092 ^ 1090892219 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62)), 240, 10, 8f);
			panel.Controls.Add(this.Gfu0Qy1OjS);
			CS$<>8__locals1.enYSMhWtNb = this.Bcm0CgZhox(240, 30, 200, 20);
			CS$<>8__locals1.enYSMhWtNb.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2069130535 + -961544443 ^ 764642127 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_170332aaa4cc40c89ac900dbc270ce22) + DateTime.Now.ToString(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(372928822 + -1261521798 ^ -1700450427 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1d30fd1b0072480a959ab725d2c0b406));
			panel.Controls.Add(CS$<>8__locals1.enYSMhWtNb);
			this.bXF0g05n14 = this.rd50MnTQXR(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(931021470 ^ 1336280699 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770)), 450, 10, 8f);
			panel.Controls.Add(this.bXF0g05n14);
			CS$<>8__locals1.UPXSS2kg3e = this.g4R0SeFqCa(450, 30, 200);
			CS$<>8__locals1.UPXSS2kg3e.Items.Add(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1951063772 ^ -180253972 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0)));
			CS$<>8__locals1.UPXSS2kg3e.SelectedIndex = 0;
			panel.Controls.Add(CS$<>8__locals1.UPXSS2kg3e);
			this.PrK0ltlN90 = this.Knd0tlekla(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1101117538 + -804724488 ^ 245458201 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3)), 240, 60, 200, false, null);
			panel.Controls.Add(this.PrK0ltlN90);
			this.wOW0VpZXYd = this.Knd0tlekla(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1921488460 ^ -1823265579 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562)), 450, 60, 150, false, null);
			panel.Controls.Add(this.wOW0VpZXYd);
			this.qAf0DJfnUg = this.Knd0tlekla(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(372928822 + -1261521798 ^ -40303171 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0)), 610, 60, 120, false, null);
			panel.Controls.Add(this.qAf0DJfnUg);
			this.iYX06cdQiq = this.Knd0tlekla(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1522779722 - -1882031954 ^ 788178939 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c8eed1a4adab4c178b239d8755225790)), 15, 22, 200, false, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1193207239 - -1972173397 ^ 419316041 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0));
			this.iYX06cdQiq.Click += this.xsA01nStZv;
			panel.Controls.Add(this.iYX06cdQiq);
			this.h3l0OMfVG7 = this.Knd0tlekla(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1822672301 ^ -1944463291 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7)), 15, 60, 200, true, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(2011196192 ^ 1099004364 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a356800ac1f14fe2bf063193c97a63df));
			this.h3l0OMfVG7.Click += this.iXp00GMI4W;
			panel.Controls.Add(this.h3l0OMfVG7);
			this.qPD0NVTOLL(CS$<>8__locals1.UPXSS2kg3e);
			this.PrK0ltlN90.Click += CS$<>8__locals1.RNHSJpW0dt;
			this.wOW0VpZXYd.Click += CS$<>8__locals1.vpOSxlJpAJ;
			this.qAf0DJfnUg.Click += CS$<>8__locals1.YylS14AEMD;
			flowLayoutPanel.Controls.Add(panel);
			flowLayoutPanel.Controls.Add(new Panel
			{
				Height = 20,
				BackColor = Color.Transparent
			});
			this.t7g0dKl15K = this.u2l0575nN6(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(494588051 << 1 ^ 427864145 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62)));
			flowLayoutPanel.Controls.Add(this.t7g0dKl15K);
			Panel panel2 = this.tay0yhyCGw(110);
			this.sqL0YVrec3 = this.rd50MnTQXR(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1053457955 ^ -1587643253 ^ 219330734 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b)), 500, 15, 8f);
			panel2.Controls.Add(this.sqL0YVrec3);
			CS$<>8__locals1.IMBStB8CYS = this.g4R0SeFqCa(500, 35, 200);
			CS$<>8__locals1.Tq1ScIHtBV = new Dictionary<string, string>
			{
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1951784774 - -1203722840 ^ -411495796 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967),
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-382924511 ^ -150572858 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562)
				},
				{
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763020866 ^ -302942899 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410),
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1512690999 ^ -2111061916 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_17bd98c4add64ea5886d3e42fa13d3d3)
				}
			};
			foreach (string item in CS$<>8__locals1.Tq1ScIHtBV.Keys)
			{
				CS$<>8__locals1.IMBStB8CYS.Items.Add(item);
			}
			string b = CS$<>8__locals1.OCeSmZeqfS.Language ?? yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1279801375 ^ -574933809 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156);
			foreach (KeyValuePair<string, string> keyValuePair in CS$<>8__locals1.Tq1ScIHtBV)
			{
				if (keyValuePair.Value == b)
				{
					CS$<>8__locals1.IMBStB8CYS.SelectedItem = keyValuePair.Key;
					break;
				}
			}
			CS$<>8__locals1.IMBStB8CYS.SelectedIndexChanged += CS$<>8__locals1.oAJS0tK1q0;
			panel2.Controls.Add(CS$<>8__locals1.IMBStB8CYS);
			this.Ff40UL9v2m = this.CXJ0ZFebPM(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1556297093 ^ 1590776772 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb)), CS$<>8__locals1.OCeSmZeqfS.AnimationsEnabled);
			this.Ff40UL9v2m.Location = new Point(15, 10);
			this.Ff40UL9v2m.CheckedChanged += CS$<>8__locals1.I6bSXFMNAF;
			panel2.Controls.Add(this.Ff40UL9v2m);
			this.Q1Z0usJO8I = this.CXJ0ZFebPM(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(749656669 + -1305576789 ^ -1295017301 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264)), CS$<>8__locals1.OCeSmZeqfS.TransparencyEnabled);
			this.Q1Z0usJO8I.Location = new Point(15, 42);
			this.Q1Z0usJO8I.CheckedChanged += CS$<>8__locals1.Y7ESjH1gtk;
			panel2.Controls.Add(this.Q1Z0usJO8I);
			this.WuL0vmER29 = this.CXJ0ZFebPM(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~1397486621 ^ -627590034 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215)), CS$<>8__locals1.OCeSmZeqfS.CheckUpdates);
			this.WuL0vmER29.Location = new Point(15, 75);
			this.WuL0vmER29.CheckedChanged += CS$<>8__locals1.fVDS5scgPy;
			panel2.Controls.Add(this.WuL0vmER29);
			this.hWc0EGtlsI = this.CXJ0ZFebPM(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-696204499 - -557025 ^ -728024529 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f33c5a4f1ded4abe9e1d234232b576cb)), CS$<>8__locals1.OCeSmZeqfS.RecommendedServers);
			this.hWc0EGtlsI.Location = new Point(245, 10);
			this.hWc0EGtlsI.CheckedChanged += CS$<>8__locals1.KF0SywPI4T;
			panel2.Controls.Add(this.hWc0EGtlsI);
			this.XL70pQmJ5F = this.CXJ0ZFebPM(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(582215781 ^ 1319188506 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264)), CS$<>8__locals1.OCeSmZeqfS.CleanPatchCache);
			this.XL70pQmJ5F.Location = new Point(245, 42);
			this.XL70pQmJ5F.CheckedChanged += CS$<>8__locals1.hpySZTEUoC;
			panel2.Controls.Add(this.XL70pQmJ5F);
			this.yja0f7b7hw = this.Knd0tlekla(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763020866 ^ -1799422100 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e)), 500, 72, 165, false, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-800407371 ^ -1770961827 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e));
			this.yja0f7b7hw.Click += this.eAb0X4ZyMl;
			panel2.Controls.Add(this.yja0f7b7hw);
			this.oQ70iMdjyN = this.Knd0tlekla(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1084619761 ^ -914772785 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215)), 245, 72, 220, false, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(401291062 ^ 1640560126 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215));
			this.oQ70iMdjyN.Click += this.wsn0j6Qa3N;
			panel2.Controls.Add(this.oQ70iMdjyN);
			this.oQ70iMdjyN.Enabled = !SettingsManager.Settings.IgnoreAVFolder;
			flowLayoutPanel.Controls.Add(panel2);
			flowLayoutPanel.ResumeLayout(false);
		}

		// Token: 0x060003AF RID: 943 RVA: 0x00017B34 File Offset: 0x00015D34
		private void xsA01nStZv(object \u0020, EventArgs \u0020)
		{
			string p = PathHelper.Combine(new string[]
			{
				Settings.dXV0qRKIh0,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1955617249 >> 6 ^ 1968419059 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1751905627 ^ -1099435002 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1437861049 - 796136520 ^ 1150473888 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--238918963 ^ 56171934 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3423fe0bd378445e9a426e728c08b0d3),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1538648569 ^ -553401836 ^ -360138270 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-926951919 ^ -1814823613 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c06f4971d65e44bfac5e65bcb1371967)
			});
			string p2 = PathHelper.Combine(new string[]
			{
				Settings.dXV0qRKIh0,
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-1397297908 ^ 1815942738 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3bb6d573c80f4dc1ae2f7ab6074c7410),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-382924511 ^ -2059403642 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9354792ccb6c485298135adc40907264),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(326126308 >> 6 ^ 510048334 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-571302991 + -886974362 ^ -775156304 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1512690999 ^ -567807031 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0),
				yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1921488460 ^ -478882870 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156)
			});
			if (!PathHelper.DirectoryExists(p) && !PathHelper.DirectoryExists(p2))
			{
				MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1307286652 - 1848242595 ^ -206479265 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~234019875 ^ -1677617102 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			this.c9B0BAkkKL.RepairGame();
			base.DialogResult = DialogResult.OK;
			base.Close();
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x00017D70 File Offset: 0x00015F70
		private void iXp00GMI4W(object \u0020, EventArgs \u0020)
		{
			if (MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-169174967 ^ -1948988941 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1437861049 - 796136520 ^ 1022919351 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				string p = Settings.dXV0qRKIh0;
				PathHelper.KillProcessFromPath(Settings.dXV0qRKIh0);
				try
				{
					if (!PathHelper.DirectoryExists(p))
					{
						MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(830079956 + -1833750625 ^ -1680943104 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-626376545 ^ -1299247170 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						long num = 0L;
						foreach (string path in PathHelper.GetFiles(p, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1046294268 ^ -555281560 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7), SearchOption.AllDirectories))
						{
							try
							{
								FileInfo fileInfo = new FileInfo(Path.GetFullPath(path));
								num += fileInfo.Length;
							}
							catch
							{
							}
						}
						PathHelper.DeleteDirectory(p, true);
						MessageBox.Show(string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(401291062 ^ 1935066067 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_7e27f114b2e149c3a37b81ef10eee89d), (double)num / 1048576.0), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-626376545 ^ -974138471 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(198208080 ^ 664839912 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94) + ex.Message, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1556297093 ^ 452507435 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00017F78 File Offset: 0x00016178
		private void eAb0X4ZyMl(object \u0020, EventArgs \u0020)
		{
			if (MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1424072547 ^ 1977873631 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8fc27a48c0ce461586dd8068b3daaced), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-169174967 ^ -1856748385 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_1c66e07149574924b7cd3da5aa89d5a4), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				string p = PathHelper.Combine(new string[]
				{
					Settings.dXV0qRKIh0,
					yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1921488460 ^ -1823273709 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562)
				});
				try
				{
					if (!PathHelper.DirectoryExists(p))
					{
						MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763020866 ^ -1451956316 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_4386be51806e40708c69a73f8cb08ef0), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1366522423 ^ -1913002966 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					else
					{
						long num = 0L;
						foreach (string path in PathHelper.GetFiles(p, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(198208080 ^ 1722356354 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b), SearchOption.AllDirectories))
						{
							try
							{
								FileInfo fileInfo = new FileInfo(Path.GetFullPath(path));
								num += fileInfo.Length;
							}
							catch
							{
							}
						}
						PathHelper.DeleteDirectory(p, true);
						MessageBox.Show(string.Format(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -786047967 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_668f68fec9c54cf78e3a724f76d0645a), (double)num / 1048576.0), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1674539608 ^ 636992775 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_0f3c75b241f74f818bb379de347bcf70), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-225059726 ^ -1263640848 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_142f514e0bed40879f739569b55f8f5e) + ex.Message, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1556297093 ^ 1047420076 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_3466dae46b0a4657b76e42995abecbf4), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x00018198 File Offset: 0x00016398
		private void wsn0j6Qa3N(object \u0020, EventArgs \u0020)
		{
			Settings.<BtnAV_ClickAsync>d__38 <BtnAV_ClickAsync>d__;
			<BtnAV_ClickAsync>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<BtnAV_ClickAsync>d__.<>1__state = -1;
			<BtnAV_ClickAsync>d__.<>t__builder.Start<Settings.<BtnAV_ClickAsync>d__38>(ref <BtnAV_ClickAsync>d__);
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x000181C8 File Offset: 0x000163C8
		private Label u2l0575nN6(string \u0020)
		{
			return new Label
			{
				Text = \u0020,
				Font = StyleManager.GetMainFont(10f),
				ForeColor = this.lKS0P6oTWU,
				AutoSize = true,
				Margin = new Padding(5, 0, 0, 10)
			};
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x00018214 File Offset: 0x00016414
		private Panel tay0yhyCGw(int \u0020)
		{
			return new Panel
			{
				Size = new Size(750, \u0020),
				BackColor = this.otM0AtKc6w,
				Margin = new Padding(0, 0, 0, 0)
			};
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00018248 File Offset: 0x00016448
		private CustomCheckBox CXJ0ZFebPM(string \u0020, bool \u0020)
		{
			return new CustomCheckBox
			{
				Text = \u0020,
				Checked = \u0020,
				Font = StyleManager.GetMainFont(9f),
				ForeColor = Color.Gainsboro,
				Size = new Size(220, 24)
			};
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00018298 File Offset: 0x00016498
		private Label rd50MnTQXR(string \u0020, int \u0020, int \u0020, float \u0020 = 8f)
		{
			return new Label
			{
				Text = \u0020,
				Location = new Point(\u0020, \u0020),
				Font = StyleManager.GetMainFont(\u0020),
				ForeColor = Color.WhiteSmoke,
				AutoSize = true
			};
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x000182D4 File Offset: 0x000164D4
		private CustomTextBox Bcm0CgZhox(int \u0020, int \u0020, int \u0020, int \u0020)
		{
			return new CustomTextBox
			{
				Location = new Point(\u0020, \u0020),
				Width = \u0020,
				Height = \u0020,
				Font = StyleManager.GetMainFont(9f),
				BackColor = Color.FromArgb(50, 110, 160),
				ForeColor = Color.White
			};
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x00018334 File Offset: 0x00016534
		private CustomComboBox g4R0SeFqCa(int \u0020, int \u0020, int \u0020)
		{
			return new CustomComboBox
			{
				Location = new Point(\u0020, \u0020),
				Width = \u0020,
				Font = StyleManager.GetMainFont(9f),
				FlatStyle = FlatStyle.Flat
			};
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x00018368 File Offset: 0x00016568
		private CustomButton Knd0tlekla(string \u0020, int \u0020, int \u0020, int \u0020, bool \u0020 = false, string \u0020 = null)
		{
			Settings.<>c__DisplayClass45_0 CS$<>8__locals1 = new Settings.<>c__DisplayClass45_0();
			CS$<>8__locals1.qwcSNHxRM6 = \u0020;
			CS$<>8__locals1.weYSsf7ZJZ = this;
			CS$<>8__locals1.wUtSrDtXAH = new CustomButton
			{
				Text = \u0020,
				Location = new Point(\u0020, \u0020),
				Size = new Size(\u0020, 28),
				BackColor = (CS$<>8__locals1.qwcSNHxRM6 ? this.vnC09eHaoT : this.w6F0oP8iW2),
				ForeColor = Color.White,
				FlatStyle = FlatStyle.Flat,
				Font = StyleManager.GetMainFont(9f),
				Cursor = Cursors.Hand,
				FlatAppearance = 
				{
					BorderSize = 0
				}
			};
			CS$<>8__locals1.wUtSrDtXAH.MouseEnter += CS$<>8__locals1.QHjSKUTyQX;
			CS$<>8__locals1.wUtSrDtXAH.MouseLeave += CS$<>8__locals1.FshS2bF30r;
			if (!string.IsNullOrEmpty(\u0020))
			{
				StyleManager.SetIcon(CS$<>8__locals1.wUtSrDtXAH, \u0020, 12f, null);
				CS$<>8__locals1.wUtSrDtXAH.TextImageRelation = TextImageRelation.ImageBeforeText;
				CS$<>8__locals1.wUtSrDtXAH.TextAlign = ContentAlignment.MiddleCenter;
			}
			return CS$<>8__locals1.wUtSrDtXAH;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x00018488 File Offset: 0x00016688
		private void h6w0clLwQu(bool \u0020)
		{
			foreach (object obj in Application.OpenForms)
			{
				Form form = (Form)obj;
				Settings.<>c__DisplayClass46_0 CS$<>8__locals1 = new Settings.<>c__DisplayClass46_0();
				CS$<>8__locals1.qgbSTyiZCe = this;
				CS$<>8__locals1.G0YS4eZSjx = (form as Main);
				if (CS$<>8__locals1.G0YS4eZSjx != null)
				{
					CS$<>8__locals1.Bt8SGgowKl = (\u0020 ? 0.9 : 1.0);
					if (CS$<>8__locals1.G0YS4eZSjx.InvokeRequired)
					{
						CS$<>8__locals1.G0YS4eZSjx.Invoke(new Action(CS$<>8__locals1.hDoSHnrV8I));
						break;
					}
					this.w9K0mqP5Qq(CS$<>8__locals1.G0YS4eZSjx, CS$<>8__locals1.Bt8SGgowKl);
					break;
				}
			}
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00018570 File Offset: 0x00016770
		private void w9K0mqP5Qq(Main \u0020, double \u0020)
		{
			FormAnimations.StopAnimation(this.xKf0e8aWhS);
			this.xKf0e8aWhS = null;
			AppSettings settings = SettingsManager.Settings;
			this.xKf0e8aWhS = FormAnimations.AnimateOpacityChange(\u0020, \u0020, settings.AnimationsEnabled, null);
		}

		// Token: 0x060003BC RID: 956 RVA: 0x000185AC File Offset: 0x000167AC
		private void TGX0K6YqvS(bool \u0020)
		{
			if (!\u0020)
			{
				FormAnimations.StopAnimation(this.WhK0n3aMHO);
				this.WhK0n3aMHO = null;
			}
		}

		// Token: 0x060003BD RID: 957 RVA: 0x000185C8 File Offset: 0x000167C8
		private void Q9v02afs0p(bool \u0020)
		{
			double targetOpacity = \u0020 ? 0.95 : 1.0;
			AppSettings settings = SettingsManager.Settings;
			FormAnimations.StopAnimation(this.kSk0WuTOK8);
			this.kSk0WuTOK8 = null;
			this.kSk0WuTOK8 = FormAnimations.AnimateOpacityChange(this, targetOpacity, settings.AnimationsEnabled, null);
		}

		// Token: 0x060003BE RID: 958 RVA: 0x00018620 File Offset: 0x00016820
		private void sHa0rE1BLR(string \u0020, string \u0020)
		{
			if (\u0020.StartsWith(\u0020, StringComparison.OrdinalIgnoreCase))
			{
				return;
			}
			PathHelper.CreateDirectory(\u0020);
			foreach (string text in PathHelper.GetFiles(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--238918963 ^ 1665459681 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e86f17a3a47d4c72aef8cd7143ef2d9b), SearchOption.TopDirectoryOnly))
			{
				try
				{
					string fileName = Path.GetFileName(text);
					string d = PathHelper.Combine(new string[]
					{
						\u0020,
						fileName
					});
					PathHelper.CopyFile(text, d, true);
				}
				catch (Exception)
				{
				}
			}
			foreach (string text2 in PathHelper.GetDirectories(\u0020, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2132757131 ^ -1933991550 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1), SearchOption.TopDirectoryOnly))
			{
				string fileName2 = Path.GetFileName(text2);
				this.sHa0rE1BLR(text2, PathHelper.Combine(new string[]
				{
					\u0020,
					fileName2
				}));
			}
		}

		// Token: 0x060003BF RID: 959 RVA: 0x00018720 File Offset: 0x00016920
		private void qPD0NVTOLL(CustomComboBox \u0020)
		{
			\u0020.Items.Clear();
			if (PathHelper.DirectoryExists(this.IvS0R2IZvi))
			{
				foreach (string path in PathHelper.GetDirectories(this.IvS0R2IZvi, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1256492628 << 2 ^ -1432793586 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0), SearchOption.TopDirectoryOnly))
				{
					\u0020.Items.Add(Path.GetFileName(path));
				}
			}
			if (\u0020.Items.Count == 0)
			{
				\u0020.Items.Add(i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1477603883 ^ -1121284705 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142)));
				\u0020.SelectedIndex = 0;
				return;
			}
			\u0020.SelectedIndex = 0;
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x000187EC File Offset: 0x000169EC
		private void yJr0sn7vlp(string \u0020)
		{
			try
			{
				if (!PathHelper.DirectoryExists(this.o3E0IoFs2p))
				{
					MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -1599489828 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_63317b19592040989f1b836b90b41752), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1968780863 ^ -458608471 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_c66eb1c050014e04a20fcb03203b5156), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
				else
				{
					string text = string.Join(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1406576133 >> 4 ^ -559831016 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b86ecd0d2f2f4561b1b5e12a02f45df8), \u0020.Split(Path.GetInvalidFileNameChars()));
					string text2 = PathHelper.Combine(new string[]
					{
						this.IvS0R2IZvi,
						text
					});
					if (PathHelper.DirectoryExists(text2))
					{
						if (MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-225059726 ^ -1006269021 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1968780863 ^ -1802634066 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562), MessageBoxButtons.YesNo) != DialogResult.Yes)
						{
							return;
						}
						PathHelper.DeleteDirectory(text2, true);
					}
					this.sHa0rE1BLR(this.o3E0IoFs2p, text2);
					MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-763020866 ^ -485362609 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20) + text + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-800407371 ^ -773553677 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_10763dbdcf934133a4cba698ac25318b), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(--132453396 ^ 1476852859 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_283eed1dfe9c48ab826a2f0f4676438e), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1163144385 ^ 836079809 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f01f4ce0831f41b1a59c282f4f57954a) + ex.Message, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-696204499 - -557025 ^ -1464381412 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25), MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x000189D8 File Offset: 0x00016BD8
		private void PFg0Hf5ePW(string \u0020)
		{
			if (\u0020 == i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-529730567 ^ -517796399 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_63317b19592040989f1b836b90b41752)) || string.IsNullOrEmpty(\u0020))
			{
				return;
			}
			if (MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~-2068305038 ^ 328038516 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_9a33eee6de6c4c40bee22da981528091) + \u0020 + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1414349225 >> 4 ^ 869565629 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_61c6e41f989348cfaa576bf74c56ebf0), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1487851180 ^ -1611548989 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_fbe8f3c3a897411a8b29da13ba5515d7), MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
			{
				try
				{
					string u = PathHelper.Combine(new string[]
					{
						this.IvS0R2IZvi,
						\u0020
					});
					if (PathHelper.DirectoryExists(this.o3E0IoFs2p))
					{
						PathHelper.DeleteDirectory(this.o3E0IoFs2p, true);
					}
					this.sHa0rE1BLR(u, this.o3E0IoFs2p);
					MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-511847524 ^ -71656154 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1406576133 >> 4 ^ -642255138 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_72e77f37856744ab963c7fb1a4615a62), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				}
				catch (Exception ex)
				{
					MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1512690999 ^ -586276636 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770) + ex.Message, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1006549809 >> 1 ^ -1809636393 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x00018B7C File Offset: 0x00016D7C
		private void m8a04beVFF(string \u0020, CustomComboBox \u0020)
		{
			if (\u0020 == i18n.T(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-752914475 ^ -9449197 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94)) || string.IsNullOrEmpty(\u0020))
			{
				return;
			}
			if (MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(339415119 ^ 251420269 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142) + \u0020 + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(619804230 ^ 1510314524 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_cdfc86a5fdd04ae4922810a0263319f0), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(232463700 ^ 2079908948 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_048e5db71a8f4342b5755f11b5a32215), MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) == DialogResult.Yes)
			{
				try
				{
					string p = PathHelper.Combine(new string[]
					{
						this.IvS0R2IZvi,
						\u0020
					});
					if (PathHelper.DirectoryExists(p))
					{
						PathHelper.DeleteDirectory(p, true);
						MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-917748829 ^ -1586950176 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_f67ec84a3697425da1446942d05f4d2f) + \u0020 + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1556297093 ^ 1122516556 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8450f496329d4e5cbf096a4fe014b562), yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1339698719 >> 2 ^ 1798225518 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
						this.qPD0NVTOLL(\u0020);
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(401291062 ^ 1040756319 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b620a18874214e8db109e10f34deac18) + ex.Message, yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1578748294 ^ -374725779 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_8d84c3108cd1450f870d446be1a755f3), MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x00018D4C File Offset: 0x00016F4C
		private void uMr0GhLHiB()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Settings));
			this.Lmf0zpMgFA = new CustomButton();
			this.iJ9X8o7ueg = new Panel();
			this.tcNXhVjlMS = new Label();
			this.iJ9X8o7ueg.SuspendLayout();
			base.SuspendLayout();
			this.Lmf0zpMgFA.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			this.Lmf0zpMgFA.BackColor = Color.Transparent;
			this.Lmf0zpMgFA.FlatAppearance.BorderSize = 0;
			this.Lmf0zpMgFA.FlatAppearance.MouseDownBackColor = Color.Transparent;
			this.Lmf0zpMgFA.FlatAppearance.MouseOverBackColor = Color.Transparent;
			this.Lmf0zpMgFA.FlatStyle = FlatStyle.Flat;
			this.Lmf0zpMgFA.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1414349225 >> 4 ^ 281924024 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_b3371e30a68f4b82947bd06a7dd9fd2a), 12f, FontStyle.Bold);
			this.Lmf0zpMgFA.ForeColor = SystemColors.ButtonShadow;
			this.Lmf0zpMgFA.Location = new Point(767, 0);
			this.Lmf0zpMgFA.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -283442176 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed);
			this.Lmf0zpMgFA.Size = new Size(30, 30);
			this.Lmf0zpMgFA.TabIndex = 2;
			this.Lmf0zpMgFA.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1867100645 ^ -701522384 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_379a68bb87b1431984c97fa0115ddeed);
			this.Lmf0zpMgFA.UseVisualStyleBackColor = false;
			this.Lmf0zpMgFA.Click += this.UXO0JdJrkG;
			this.iJ9X8o7ueg.BackColor = Color.FromArgb(26, 37, 53);
			this.iJ9X8o7ueg.Controls.Add(this.tcNXhVjlMS);
			this.iJ9X8o7ueg.Controls.Add(this.Lmf0zpMgFA);
			this.iJ9X8o7ueg.ForeColor = Color.Transparent;
			this.iJ9X8o7ueg.Location = new Point(0, 0);
			this.iJ9X8o7ueg.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1320911165 + 1523017060 ^ -2047728281 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_75d363ddadd841189363ba12ad75ab94);
			this.iJ9X8o7ueg.Size = new Size(800, 30);
			this.iJ9X8o7ueg.TabIndex = 23;
			this.tcNXhVjlMS.AutoSize = true;
			this.tcNXhVjlMS.Font = new Font(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-529730567 ^ -89407721 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142), 11.25f, FontStyle.Regular, GraphicsUnit.Point, 0);
			this.tcNXhVjlMS.Location = new Point(9, 7);
			this.tcNXhVjlMS.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1538648569 ^ -553401836 ^ -360124458 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_210a49f07f9640d088cc40fc8283341c);
			this.tcNXhVjlMS.Size = new Size(30, 17);
			this.tcNXhVjlMS.TabIndex = 3;
			this.tcNXhVjlMS.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-43305569 ^ 2006926075 ^ -1875683974 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_a2f730936f5a4e5ebb5faa9d06886142);
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.FromArgb(20, 30, 42);
			base.ClientSize = new Size(800, 480);
			base.ControlBox = false;
			base.Controls.Add(this.iJ9X8o7ueg);
			base.Icon = (Icon)componentResourceManager.GetObject(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(~1397486621 ^ -762704746 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_29d07f40a86642f48346d6857b83ce25));
			base.Name = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1279801375 ^ -881857802 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6ed60bdf9ac1443f8449d48ebb6da770);
			this.Text = yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-1006549809 >> 1 ^ -49596580 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e37af238d1974db7b9ec33f301e72ce3);
			this.iJ9X8o7ueg.ResumeLayout(false);
			this.iJ9X8o7ueg.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0001915C File Offset: 0x0001735C
		// Note: this type is marked as 'beforefieldinit'.
		static Settings()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			Settings.dXV0qRKIh0 = RJG3u8JZLa1autEARgF.METJ4myejd;
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x00019174 File Offset: 0x00017374
		[CompilerGenerated]
		private void m6M0TkIpiO()
		{
			this.HMA0bR9OmR();
		}

		// Token: 0x04000336 RID: 822
		private readonly Main c9B0BAkkKL;

		// Token: 0x04000337 RID: 823
		private static readonly string dXV0qRKIh0;

		// Token: 0x04000338 RID: 824
		private readonly Color adQ07JT5Tx;

		// Token: 0x04000339 RID: 825
		private readonly Color otM0AtKc6w;

		// Token: 0x0400033A RID: 826
		private readonly Color lKS0P6oTWU;

		// Token: 0x0400033B RID: 827
		private readonly Color w6F0oP8iW2;

		// Token: 0x0400033C RID: 828
		private readonly Color vnC09eHaoT;

		// Token: 0x0400033D RID: 829
		private Label Gfu0Qy1OjS;

		// Token: 0x0400033E RID: 830
		private Label bXF0g05n14;

		// Token: 0x0400033F RID: 831
		private Label sqL0YVrec3;

		// Token: 0x04000340 RID: 832
		private CustomButton PrK0ltlN90;

		// Token: 0x04000341 RID: 833
		private CustomButton wOW0VpZXYd;

		// Token: 0x04000342 RID: 834
		private CustomButton qAf0DJfnUg;

		// Token: 0x04000343 RID: 835
		private CustomButton iYX06cdQiq;

		// Token: 0x04000344 RID: 836
		private CustomButton h3l0OMfVG7;

		// Token: 0x04000345 RID: 837
		private CustomButton yja0f7b7hw;

		// Token: 0x04000346 RID: 838
		private CustomButton oQ70iMdjyN;

		// Token: 0x04000347 RID: 839
		private CustomCheckBox Ff40UL9v2m;

		// Token: 0x04000348 RID: 840
		private CustomCheckBox Q1Z0usJO8I;

		// Token: 0x04000349 RID: 841
		private CustomCheckBox WuL0vmER29;

		// Token: 0x0400034A RID: 842
		private CustomCheckBox hWc0EGtlsI;

		// Token: 0x0400034B RID: 843
		private CustomCheckBox XL70pQmJ5F;

		// Token: 0x0400034C RID: 844
		private Label OsD0FESp0b;

		// Token: 0x0400034D RID: 845
		private Label t7g0dKl15K;

		// Token: 0x0400034E RID: 846
		private Timer kSk0WuTOK8;

		// Token: 0x0400034F RID: 847
		private Timer xKf0e8aWhS;

		// Token: 0x04000350 RID: 848
		private Timer WhK0n3aMHO;

		// Token: 0x04000351 RID: 849
		private readonly FormDrags tvk03vuw7r;

		// Token: 0x04000352 RID: 850
		private readonly double vY30LQIGrP;

		// Token: 0x04000353 RID: 851
		private readonly string o3E0IoFs2p;

		// Token: 0x04000354 RID: 852
		private readonly string IvS0R2IZvi;

		// Token: 0x04000356 RID: 854
		private CustomButton Lmf0zpMgFA;

		// Token: 0x04000357 RID: 855
		private Panel iJ9X8o7ueg;

		// Token: 0x04000358 RID: 856
		private Label tcNXhVjlMS;
	}
}
