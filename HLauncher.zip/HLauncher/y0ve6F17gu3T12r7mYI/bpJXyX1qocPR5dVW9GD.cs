﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace y0ve6F17gu3T12r7mYI
{
	// Token: 0x020000AD RID: 173
	internal static class bpJXyX1qocPR5dVW9GD
	{
		// Token: 0x06000346 RID: 838
		[DllImport("user32.dll", CharSet = CharSet.Unicode, EntryPoint = "RegisterWindowMessage")]
		public static extern int MgZ1ALAMZC(string \u0020);

		// Token: 0x06000347 RID: 839
		[DllImport("user32.dll", EntryPoint = "PostMessage")]
		public static extern bool IGX1PKQ3r2(IntPtr \u0020, int \u0020, IntPtr \u0020, IntPtr \u0020);

		// Token: 0x06000348 RID: 840
		[DllImport("user32.dll", EntryPoint = "SetForegroundWindow")]
		public static extern bool N9k1olbldd(IntPtr \u0020);

		// Token: 0x06000349 RID: 841
		[DllImport("uxtheme.dll", CharSet = CharSet.Unicode, EntryPoint = "SetWindowTheme")]
		public static extern int Q40191tEbG(IntPtr \u0020, string \u0020, string \u0020);

		// Token: 0x0600034A RID: 842
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, EntryPoint = "QueryDosDevice")]
		public static extern uint bdI1Qn0Pf5(string \u0020, StringBuilder \u0020, int \u0020);

		// Token: 0x0600034B RID: 843
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, EntryPoint = "GetShortPathName", SetLastError = true)]
		public static extern int zfs1gmaJNV(string \u0020, StringBuilder \u0020, int \u0020);

		// Token: 0x0600034C RID: 844
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, EntryPoint = "CreateSymbolicLink", SetLastError = true)]
		public static extern bool OZM1YPbi0w(string \u0020, string \u0020, uint \u0020);

		// Token: 0x0600034D RID: 845
		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, EntryPoint = "CreateHardLink", SetLastError = true)]
		public static extern bool VM51lDdAHG(string \u0020, string \u0020, IntPtr \u0020);

		// Token: 0x0600034E RID: 846 RVA: 0x000153B8 File Offset: 0x000135B8
		// Note: this type is marked as 'beforefieldinit'.
		static bpJXyX1qocPR5dVW9GD()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			bpJXyX1qocPR5dVW9GD.b841VILlRi = bpJXyX1qocPR5dVW9GD.MgZ1ALAMZC(yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(1955617249 >> 6 ^ 809927848 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_42bf02a3a5394b59ac63cef131c68e20));
		}

		// Token: 0x040002F7 RID: 759
		public static readonly int b841VILlRi;
	}
}
