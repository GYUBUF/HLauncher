﻿using System;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x0200001C RID: 28
public class ButlerHandler
{
	// Token: 0x0600009A RID: 154 RVA: 0x00004464 File Offset: 0x00002664
	public ButlerHandler(string executablePath)
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		base..ctor();
		this.dI7h5aIneH = executablePath;
	}

	// Token: 0x0600009B RID: 155 RVA: 0x00004480 File Offset: 0x00002680
	public Task ApplyPatchDirect(string pwrPath, string gameDir, string stagingDir, IProgress<int> progress, Action<double, double> statsCallback)
	{
		ButlerHandler.<ApplyPatchDirect>d__3 <ApplyPatchDirect>d__;
		<ApplyPatchDirect>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
		<ApplyPatchDirect>d__.<>4__this = this;
		<ApplyPatchDirect>d__.pwrPath = pwrPath;
		<ApplyPatchDirect>d__.gameDir = gameDir;
		<ApplyPatchDirect>d__.stagingDir = stagingDir;
		<ApplyPatchDirect>d__.progress = progress;
		<ApplyPatchDirect>d__.statsCallback = statsCallback;
		<ApplyPatchDirect>d__.<>1__state = -1;
		<ApplyPatchDirect>d__.<>t__builder.Start<ButlerHandler.<ApplyPatchDirect>d__3>(ref <ApplyPatchDirect>d__);
		return <ApplyPatchDirect>d__.<>t__builder.Task;
	}

	// Token: 0x04000052 RID: 82
	private readonly string dI7h5aIneH;

	// Token: 0x0200001D RID: 29
	private class YKLOEFjQn1cxCvnEWOR
	{
		// Token: 0x1700002F RID: 47
		// (get) Token: 0x0600009C RID: 156 RVA: 0x0001C39C File Offset: 0x0001A59C
		// (set) Token: 0x0600009D RID: 157 RVA: 0x0001C3A4 File Offset: 0x0001A5A4
		[JsonProperty("type")]
		public string B10jOqnINv { get; set; }

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x0600009E RID: 158 RVA: 0x0001C3B0 File Offset: 0x0001A5B0
		// (set) Token: 0x0600009F RID: 159 RVA: 0x0001C3B8 File Offset: 0x0001A5B8
		[JsonProperty("progress")]
		public double TqqjubEDtO { get; set; }

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x060000A0 RID: 160 RVA: 0x0001C3C4 File Offset: 0x0001A5C4
		// (set) Token: 0x060000A1 RID: 161 RVA: 0x0001C3CC File Offset: 0x0001A5CC
		[JsonProperty("bps")]
		public double PHNjF6n0sG { get; set; }

		// Token: 0x060000A2 RID: 162 RVA: 0x0001C3D8 File Offset: 0x0001A5D8
		public YKLOEFjQn1cxCvnEWOR()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x04000053 RID: 83
		[CompilerGenerated]
		private string UtGjdmgryG;

		// Token: 0x04000054 RID: 84
		[CompilerGenerated]
		private double pNZjWV7Aik;

		// Token: 0x04000055 RID: 85
		[CompilerGenerated]
		private double neejeYrNa7;
	}
}
