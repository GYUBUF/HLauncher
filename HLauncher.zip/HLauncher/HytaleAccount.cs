﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using kX9YDxmFanSa8qobU7Z;
using Newtonsoft.Json;
using ro2IpYtzntGHp8CGrmT;

// Token: 0x0200002F RID: 47
public class HytaleAccount
{
	// Token: 0x1700003C RID: 60
	// (get) Token: 0x060000E4 RID: 228 RVA: 0x00004CC8 File Offset: 0x00002EC8
	// (set) Token: 0x060000E5 RID: 229 RVA: 0x00004CD0 File Offset: 0x00002ED0
	[JsonProperty("identityId")]
	public string IdentityId { get; set; }

	// Token: 0x1700003D RID: 61
	// (get) Token: 0x060000E6 RID: 230 RVA: 0x00004CDC File Offset: 0x00002EDC
	// (set) Token: 0x060000E7 RID: 231 RVA: 0x00004CE4 File Offset: 0x00002EE4
	[JsonProperty("email")]
	public string Email { get; set; }

	// Token: 0x1700003E RID: 62
	// (get) Token: 0x060000E8 RID: 232 RVA: 0x00004CF0 File Offset: 0x00002EF0
	// (set) Token: 0x060000E9 RID: 233 RVA: 0x00004CF8 File Offset: 0x00002EF8
	[JsonProperty("accessToken")]
	public string AccessToken { get; set; }

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x060000EA RID: 234 RVA: 0x00004D04 File Offset: 0x00002F04
	// (set) Token: 0x060000EB RID: 235 RVA: 0x00004D0C File Offset: 0x00002F0C
	[JsonProperty("refreshToken")]
	public string RefreshToken { get; set; }

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x060000EC RID: 236 RVA: 0x00004D18 File Offset: 0x00002F18
	// (set) Token: 0x060000ED RID: 237 RVA: 0x00004D20 File Offset: 0x00002F20
	[JsonProperty("expiresAt")]
	public DateTime ExpiresAt { get; set; }

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x060000EE RID: 238 RVA: 0x00004D2C File Offset: 0x00002F2C
	// (set) Token: 0x060000EF RID: 239 RVA: 0x00004D34 File Offset: 0x00002F34
	[JsonProperty("ownerId")]
	public string OwnerId { get; set; }

	// Token: 0x17000042 RID: 66
	// (get) Token: 0x060000F0 RID: 240 RVA: 0x00004D40 File Offset: 0x00002F40
	// (set) Token: 0x060000F1 RID: 241 RVA: 0x00004D48 File Offset: 0x00002F48
	[JsonProperty("eulaAcceptedAt")]
	public DateTime? EulaAcceptedAt { get; set; }

	// Token: 0x17000043 RID: 67
	// (get) Token: 0x060000F2 RID: 242 RVA: 0x00004D54 File Offset: 0x00002F54
	// (set) Token: 0x060000F3 RID: 243 RVA: 0x00004D5C File Offset: 0x00002F5C
	[JsonProperty("patchlines")]
	public Dictionary<string, PatchlineInfo> Patchlines { get; set; }

	// Token: 0x17000044 RID: 68
	// (get) Token: 0x060000F4 RID: 244 RVA: 0x00004D68 File Offset: 0x00002F68
	// (set) Token: 0x060000F5 RID: 245 RVA: 0x00004D70 File Offset: 0x00002F70
	[JsonProperty("profiles")]
	public List<HytaleProfile> Profiles { get; set; }

	// Token: 0x17000045 RID: 69
	// (get) Token: 0x060000F6 RID: 246 RVA: 0x00004D7C File Offset: 0x00002F7C
	// (set) Token: 0x060000F7 RID: 247 RVA: 0x00004D84 File Offset: 0x00002F84
	[JsonProperty("selectedProfileId")]
	public string SelectedProfileId { get; set; }

	// Token: 0x17000046 RID: 70
	// (get) Token: 0x060000F8 RID: 248 RVA: 0x00004D90 File Offset: 0x00002F90
	[JsonIgnore]
	public HytaleProfile SelectedProfile
	{
		get
		{
			return this.Profiles.FirstOrDefault(new Func<HytaleProfile, bool>(this.d30hlP4JcY));
		}
	}

	// Token: 0x060000F9 RID: 249 RVA: 0x00004DAC File Offset: 0x00002FAC
	public override string ToString()
	{
		if (this.SelectedProfile == null)
		{
			return this.Email;
		}
		return this.SelectedProfile.Name + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-2069130535 + -961544443 ^ 1191350067 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_e4c5636c22764a069117711639b617f1) + this.Email + yyVBrstaZqxEPNHbn5C.nEjcKVF6rd(-704542734 ^ -918270052 ^ <Module>{8db40a55-f937-41c7-8463-26a9c184cc87}.m_00ca883dabc144a5aed99293a99102a9.m_6422861e5d6045a0ac91611f03b92aa7);
	}

	// Token: 0x060000FA RID: 250 RVA: 0x00004E20 File Offset: 0x00003020
	public HytaleAccount()
	{
		yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
		NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
		this.Profiles = new List<HytaleProfile>();
		base..ctor();
	}

	// Token: 0x060000FB RID: 251 RVA: 0x00004E40 File Offset: 0x00003040
	[CompilerGenerated]
	private bool d30hlP4JcY(HytaleProfile YJ113lhVKHwEd1W7lK9)
	{
		return YJ113lhVKHwEd1W7lK9.Id == this.SelectedProfileId;
	}

	// Token: 0x040000B3 RID: 179
	[CompilerGenerated]
	private string kPMhDWr65r;

	// Token: 0x040000B4 RID: 180
	[CompilerGenerated]
	private string mqFh6Vx3Yq;

	// Token: 0x040000B5 RID: 181
	[CompilerGenerated]
	private string l1XhOai2Sq;

	// Token: 0x040000B6 RID: 182
	[CompilerGenerated]
	private string fnPhfx2Ne2;

	// Token: 0x040000B7 RID: 183
	[CompilerGenerated]
	private DateTime WIihiPLcvE;

	// Token: 0x040000B8 RID: 184
	[CompilerGenerated]
	private string EYWhUXxZHW;

	// Token: 0x040000B9 RID: 185
	[CompilerGenerated]
	private DateTime? Xa7huDWvtM;

	// Token: 0x040000BA RID: 186
	[CompilerGenerated]
	private Dictionary<string, PatchlineInfo> YlfhvLhAXb;

	// Token: 0x040000BB RID: 187
	[CompilerGenerated]
	private List<HytaleProfile> PGYhE7B0Se;

	// Token: 0x040000BC RID: 188
	[CompilerGenerated]
	private string ktXhpaQK8W;
}
