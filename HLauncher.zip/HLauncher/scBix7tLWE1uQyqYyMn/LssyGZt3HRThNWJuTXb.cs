﻿using System;
using System.Reflection;
using kX9YDxmFanSa8qobU7Z;
using ro2IpYtzntGHp8CGrmT;

namespace scBix7tLWE1uQyqYyMn
{
	// Token: 0x020000E0 RID: 224
	internal class LssyGZt3HRThNWJuTXb
	{
		// Token: 0x06000475 RID: 1141 RVA: 0x0002D694 File Offset: 0x0002B894
		internal static void lMk2t5oAAo(int typemdt)
		{
			Type type = LssyGZt3HRThNWJuTXb.kq6tI3u8IO.ResolveType(33554432 + typemdt);
			foreach (FieldInfo fieldInfo in type.GetFields())
			{
				MethodInfo method = (MethodInfo)LssyGZt3HRThNWJuTXb.kq6tI3u8IO.ResolveMethod(fieldInfo.MetadataToken + 100663296);
				fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, method));
			}
		}

		// Token: 0x06000476 RID: 1142 RVA: 0x0002D704 File Offset: 0x0002B904
		public LssyGZt3HRThNWJuTXb()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			base..ctor();
		}

		// Token: 0x06000477 RID: 1143 RVA: 0x0002D718 File Offset: 0x0002B918
		// Note: this type is marked as 'beforefieldinit'.
		static LssyGZt3HRThNWJuTXb()
		{
			yyVBrstaZqxEPNHbn5C.yebcc3PSyG();
			NKhODwmprpMr8iKsnkE.tWt2mJv6ED();
			LssyGZt3HRThNWJuTXb.kq6tI3u8IO = typeof(LssyGZt3HRThNWJuTXb).Assembly.ManifestModule;
		}

		// Token: 0x040003FE RID: 1022
		internal static Module kq6tI3u8IO;

		// Token: 0x020000E1 RID: 225
		// (Invoke) Token: 0x06000479 RID: 1145
		internal delegate void tN9jCXtReDpdIXZWBnk(object o);
	}
}
